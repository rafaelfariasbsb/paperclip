# Condomínio – Gestão com IA (template Paperclip) · v1.1.0

Uma empresa pronta de agentes de IA para apoiar o síndico de condomínio residencial, seja morador ou profissional. Os agentes fazem o trabalho de planilha, calendário e rascunho que hoje toma as noites do síndico. **Quem decide é sempre um humano.**

## O que vem no pacote
- **8 agentes:**
  - gerente-geral;
  - implantação;
  - conformidade (documentos, laudos, seguro, obrigações, LGPD);
  - financeiro;
  - cobrança;
  - manutenção predial;
  - assembleias e comunicação;
  - atendimento aos moradores.
- **19 skills** com as regras do setor (Código Civil, Lei 14.905/2024, Lei 14.309/2022, NBR 5674/16280/16747, LGPD, eSocial/EFD-Reinf) e **13 scripts** (11 de cálculo e 2 conversores de exportação) em Python, sem dependências externas.
- **18 rotinas** (diárias, semanais, mensais, semestrais e anuais) e 2 tarefas iniciais.
- **Dados de exemplo fictícios** (`assets/dados-exemplo/`) de um condomínio de 40 unidades.

## Instalação
1. Paperclip instalado (no Windows, pelo roteiro de instalação no WSL2).
2. No Paperclip, abra **Configurações da empresa → Import** e envie o `.zip` deste pacote.
   - Deixe marcado **"Start imported agents and routines paused"**.
   - O pacote vem com o adapter `claude_local`.
3. Preencha `CONDOMINIO_DADOS` com a pasta de dados do condomínio. Ela deve ter as subpastas `entrada` e `saida`.
4. Ative só o agente **Implantação** e a tarefa "Implantação: configurar o condomínio". Ele entrevista o síndico, descobre qual sistema e qual banco o condomínio usa, monta a conversão das exportações (Superlógica, Condomínio21, uCondo, TownSq, extrato OFX de qualquer banco), valida os dados e monta as planilhas de documentos e de manutenção.
5. Com a implantação concluída, ative os demais agentes e rotinas. Comece por gerente-geral, conformidade, financeiro e manutenção.

> **Importe pela tela, enviando o `.zip`.** A importação pela linha de comando (`paperclipai company import`) só leva arquivos `.md` e descarta os scripts `.py` das skills (testado na versão 2026.1117.0).

## Dados
O síndico, o zelador ou a administradora exportam as planilhas para `entrada/` no formato da skill `contrato-de-dados`. Para conferir, rode:
`python3 skills/contrato-de-dados/scripts/validar_dados.py <pasta>/entrada`

Para demonstrar sem dados reais, aponte `CONDOMINIO_DADOS` para uma pasta com `assets/dados-exemplo` copiado como `entrada`. Para regenerar os dados com a data de hoje:
`python3 assets/gerar_dados_exemplo.py <pasta>/entrada`

## Limites (importante para a venda)
- Não substitui o síndico, o conselho, a assembleia, o contador, o advogado nem o engenheiro.
- Não envia, não paga, não assina e não publica. Entrega rascunhos para aprovação.
- Não aplica multa, não protesta, não negativa e não expõe devedor.
- Não guarda senhas nem credenciais.
- Trabalha com o número da unidade, sem nome, CPF ou telefone de morador (LGPD).
- **Custo:** os agentes usam IA paga pelo cliente (assinatura ou chave de API). Os orçamentos por agente vêm baixos (`budgetMonthlyCents`) e devem ser ajustados no Paperclip.
- Não é parecer jurídico, contábil ou técnico. As regras marcadas **[conferir]** dependem da convenção, do município ou do estado e devem ser confirmadas na implantação.

## Atualizações
Veja `CHANGELOG.md`.
