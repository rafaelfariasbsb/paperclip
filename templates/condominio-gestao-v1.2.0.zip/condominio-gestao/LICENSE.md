# Licença de uso — Condomínio – Gestão com IA

Copyright (c) 2026 Rafael Farias. Todos os direitos reservados.

1. Esta licença permite instalar e usar o pacote em **um condomínio** (um CNPJ) do cliente que o adquiriu. Síndicos profissionais e administradoras precisam de uma licença por condomínio atendido.
2. É proibido revender, redistribuir, sublicenciar ou publicar o pacote, no todo ou em parte, sem autorização por escrito.
3. O pacote é uma ferramenta de apoio à gestão. **Não substitui** o síndico, o conselho fiscal, a assembleia, o contador, o advogado nem o responsável técnico por laudos e manutenção. Não constitui parecer jurídico, contábil ou de engenharia.
4. O cliente é responsável:
   - pelas decisões tomadas a partir dos relatórios;
   - pelos dados que fornece;
   - pela base legal de tratamento de dados pessoais de moradores, funcionários e visitantes (LGPD);
   - pelos contratos com os provedores de IA que utilizar.
5. O pacote é fornecido "no estado em que se encontra". As atualizações de regras são oferecidas por assinatura separada.

*Modelo de licença: revise com um advogado antes de comercializar.*
