#!/usr/bin/env python3
"""Gera dados FICTICIOS de um condominio de 40 unidades, com problemas plantados para demonstracao e QA.
Uso: python3 gerar_dados_exemplo.py <pasta_saida> [--hoje AAAA-MM-DD]

Problemas plantados (o que cada script deve encontrar):
- balancete: 'Manutencao e reparos' muito acima do orcado no mes anterior; 1 lancamento sem documento.
- conciliar: 1 PIX enviado sem lancamento; 1 lancamento em duplicidade; tarifas bancarias.
- inadimplencia: A-302 com 4 parcelas (> 90 dias), B-104 com 2, A-201 com 1; B-503 pagou atrasado.
- manutencao: limpeza de reservatorio atrasada; dedetizacao sem registro; SPDA nos proximos 30 dias.
- prazos: AVCB vence em 25 dias; certificado de dedetizacao vencido; certidoes da portaria vencidas.
- consumo: agua do ultimo mes 35% acima da media.
- cotacoes: impermeabilizacao com menor preco de documentacao pendente; pintura com so 2 orcamentos.
- votos: contas aprovadas; fachada (2/3) nao atinge o quorum.
- ocorrencias: chamado antigo fora do prazo, barulho reincidente em B-402, 1 ocorrencia de seguranca.
"""
import argparse, csv, os, random
from datetime import date, timedelta

CATEG = [  # categoria, valor mensal base, variacao
    ("Folha e encargos", 11200, 0.02), ("Portaria terceirizada", 9100, 0.0), ("Agua e esgoto", 3400, 0.08),
    ("Energia", 2200, 0.07), ("Administradora", 1800, 0.0), ("Elevadores", 1650, 0.0),
    ("Manutencao e reparos", 1500, 0.35), ("Limpeza e materiais", 780, 0.15), ("Jardinagem", 600, 0.0),
    ("Tarifas bancarias", 95, 0.0),
]


def mes_add(y, m, k):
    m += k
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    return y, m


def w(pasta, nome, cab, linhas):
    with open(os.path.join(pasta, nome), "w", encoding="utf-8", newline="") as f:
        cw = csv.writer(f, delimiter=";")
        cw.writerow(cab)
        cw.writerows(linhas)


def br(v):
    return f"{v:.2f}".replace(".", ",")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    a = ap.parse_args()
    os.makedirs(a.pasta, exist_ok=True)
    rnd = random.Random(42)
    hoje = date.fromisoformat(a.hoje)

    # unidades: 2 blocos x 5 andares x 4 aptos; finais 01 e 04 maiores
    unid = []
    for b in "AB":
        for andar in range(1, 6):
            for ap_ in range(1, 5):
                fr = 0.0275 if ap_ in (1, 4) else 0.0225
                unid.append((f"{b}-{andar}0{ap_}", b, fr))
    w(a.pasta, "unidades.csv", ["unidade", "bloco", "fracao_ideal", "tipo"],
      [(u, b, f"{fr:.6f}".replace(".", ","), "RESIDENCIAL") for u, b, fr in unid])

    cota_total = 32000.0
    fr_pct = 0.10
    # 13 competencias: 12 passadas + a atual (vencimento dia 10)
    comps = [mes_add(hoje.year, hoje.month, k) for k in range(-12, 1)]
    devedores = {"A-302": 4, "B-104": 2, "A-201": 1}
    ult_venc = max(i for i, (y, m) in enumerate(comps) if date(y, m, 10) < hoje)
    cob, lanc = [], []
    for i, (y, m) in enumerate(comps):
        venc = date(y, m, 10)
        comp = f"{y:04d}-{m:02d}"
        rec_ord = rec_fr = 0.0
        for u, b, fr in unid:
            ordv = round(cota_total * fr, 2); frv = round(cota_total * fr_pct * fr, 2)
            pago_em, pago_o, pago_f = venc - timedelta(days=rnd.randint(0, 4)), ordv, frv
            atraso_meses = devedores.get(u, 0)
            if venc >= hoje:  # ainda nao venceu
                if rnd.random() < 0.6:
                    pago_em, pago_o, pago_f = None, 0, 0
            elif atraso_meses and i > ult_venc - atraso_meses:
                pago_em, pago_o, pago_f = None, 0, 0
            elif u == "B-503" and i == ult_venc - 1:
                pago_em = venc + timedelta(days=23)
            for tipo, v, p in (("ORDINARIA", ordv, pago_o), ("FUNDO_RESERVA", frv, pago_f)):
                cob.append((u, comp, tipo, venc.isoformat(), br(v), pago_em.isoformat() if pago_em and p else "", br(p) if p else ""))
            if pago_em and pago_em <= hoje:
                rec_ord += pago_o; rec_fr += pago_f
        if venc < hoje:
            lanc.append((date(y, m, 12).isoformat(), "ORDINARIA", "Taxa condominial", f"Recebimentos competencia {comp}", br(rec_ord), f"REC-{comp}"))
            lanc.append((date(y, m, 12).isoformat(), "FUNDO_RESERVA", "Fundo de reserva", f"Recebimentos competencia {comp}", br(rec_fr), f"REC-FR-{comp}"))
            for cat, base, var in CATEG:
                v = base * (1 + rnd.uniform(-var, var))
                if cat == "Manutencao e reparos" and i == ult_venc:
                    v = 4850.0  # desvio plantado no mes anterior
                dia = 5 if cat == "Folha e encargos" else 15
                doc = f"NF-{comp}-{cat[:3].upper()}"
                lanc.append((date(y, m, dia).isoformat(), "ORDINARIA", cat, cat, br(-round(v, 2)), doc))
            if m == 3:
                lanc.append((date(y, m, 20).isoformat(), "ORDINARIA", "Seguro", "Seguro predial anual", br(-6200), f"APOLICE-{y}"))
    # mes anterior: lancamento sem documento e duplicidade
    yp, mp = comps[ult_venc]
    lanc.append((date(yp, mp, 18).isoformat(), "ORDINARIA", "Manutencao e reparos", "Compra de lampadas", br(-187.40), ""))
    lanc.append((date(yp, mp, 21).isoformat(), "ORDINARIA", "Manutencao e reparos", "Desentupidora Rapida", br(-450.00), f"NF-{yp}-{mp:02d}-DES1"))
    lanc.append((date(yp, mp, 22).isoformat(), "ORDINARIA", "Manutencao e reparos", "Desentupidora Rapida", br(-450.00), f"NF-{yp}-{mp:02d}-DES2"))
    lanc.sort()
    w(a.pasta, "lancamentos.csv", ["data", "conta", "categoria", "descricao", "valor", "documento"], lanc)
    w(a.pasta, "cobrancas.csv", ["unidade", "competencia", "tipo", "vencimento", "valor", "pago_em", "valor_pago"], cob)
    w(a.pasta, "orcamento.csv", ["categoria", "valor_mensal"], [(c, br(v)) for c, v, _ in CATEG] + [("Seguro", br(520))])

    # extrato dos ultimos 40 dias, espelhando os lancamentos, com uma saida sem lancamento
    ini = hoje - timedelta(days=40)
    ext = []
    for d, conta, cat, desc, v, doc in lanc:
        dd = date.fromisoformat(d)
        if ini <= dd <= hoje and not (desc == "Desentupidora Rapida" and doc.endswith("DES2")):
            ext.append((d, conta, ("TARIFA PACOTE SERVICOS" if cat == "Tarifas bancarias" else desc.upper()), v))
    ext.append(((hoje - timedelta(days=6)).isoformat(), "ORDINARIA", "PIX ENVIADO 12345678000199", br(-1250.00)))
    ext.sort()
    w(a.pasta, "extrato_bancario.csv", ["data", "conta", "descricao", "valor"], ext)
    w(a.pasta, "saldos.csv", ["data", "conta", "saldo"], [
        ((hoje - timedelta(days=1)).isoformat(), "ORDINARIA", br(18450.33)),
        ((hoje - timedelta(days=1)).isoformat(), "FUNDO_RESERVA", br(41230.10)),
        ((hoje - timedelta(days=1)).isoformat(), "FUNDO_OBRAS", br(0))])

    def antes(d):
        return (hoje - timedelta(days=d)).isoformat()
    w(a.pasta, "plano_manutencao.csv", ["sistema", "atividade", "periodicidade_dias", "ultima_execucao", "responsavel", "exige_laudo"], [
        ("Reservatorios", "Limpeza e desinfeccao", 180, antes(205), "Empresa contratada", "S"),
        ("Agua potavel", "Analise de potabilidade", 180, antes(200), "Laboratorio", "S"),
        ("Elevadores", "Manutencao preventiva mensal", 30, antes(12), "Conservadora", "N"),
        ("Elevadores", "Inspecao anual (RIA)", 365, antes(300), "Conservadora", "S"),
        ("SPDA", "Inspecao e medicao com laudo", 365, antes(350), "Engenheiro eletricista", "S"),
        ("Incendio", "Inspecao visual dos extintores", 30, antes(20), "Zelador", "N"),
        ("Incendio", "Recarga dos extintores", 365, antes(120), "Empresa certificada", "S"),
        ("Incendio", "Teste da iluminacao de emergencia", 30, antes(45), "Zelador", "N"),
        ("Bombas", "Revezamento das bombas de recalque", 7, antes(3), "Zelador", "N"),
        ("Gerador", "Teste em carga", 30, antes(25), "Zelador", "N"),
        ("Pragas", "Dedetizacao e desratizacao", 180, "", "Empresa licenciada", "S"),
        ("Portoes", "Manutencao preventiva", 90, antes(60), "Contrato portoes", "N"),
        ("Fachada", "Inspecao visual", 365, antes(400), "Sindico e zelador", "N"),
    ])

    def depois(d):
        return (hoje + timedelta(days=d)).isoformat()
    w(a.pasta, "documentos.csv", ["documento", "orgao", "numero", "validade", "responsavel"], [
        ("AVCB", "Corpo de Bombeiros", "AVCB-000123", depois(25), "Sindico"),
        ("Seguro predial (art. 1.346)", "Seguradora Exemplo", "APL-778899", depois(118), "Sindico"),
        ("Certificado de dedetizacao", "Dedetizadora Exemplo", "CD-4455", antes(12), "Zelador"),
        ("Certificado de limpeza dos reservatorios", "Limpa Caixa Exemplo", "LR-2211", antes(25), "Zelador"),
        ("Laudo SPDA com ART", "Eng. Exemplo", "ART-998877", depois(15), "Sindico"),
        ("Mandato do sindico (ata de eleicao)", "Assembleia", "ATA-AGO", depois(75), "Sindico"),
        ("Certidao negativa federal do condominio", "Receita/PGFN", "CND-1", depois(140), "Administradora"),
    ])
    w(a.pasta, "contratos.csv", ["fornecedor", "objeto", "valor_mensal", "fim", "indice_reajuste", "certidoes_validade"], [
        ("Portaria Exemplo Ltda", "Portaria 24h", br(9100), depois(160), "CCT da categoria", antes(10)),
        ("Elevadores Exemplo", "Conservacao de elevadores", br(1650), depois(45), "IPCA", depois(90)),
        ("Administradora Exemplo", "Administracao condominial", br(1800), depois(230), "IPCA", depois(120)),
    ])
    w(a.pasta, "cotacoes.csv", ["item", "fornecedor", "valor", "prazo_dias", "garantia_meses", "documentos_ok", "observacao"], [
        ("Impermeabilizacao da laje da cobertura", "Impermeabiliza A", br(38500), 25, 60, "N", "sem ART e sem seguro RC"),
        ("Impermeabilizacao da laje da cobertura", "Impermeabiliza B", br(42900), 30, 60, "S", "manta asfaltica 4mm"),
        ("Impermeabilizacao da laje da cobertura", "Impermeabiliza C", br(47800), 20, 120, "S", "inclui protecao mecanica"),
        ("Pintura do hall social", "Pinturas X", br(6200), 10, 12, "S", ""),
        ("Pintura do hall social", "Pinturas Y", br(7450), 7, 24, "S", ""),
    ])
    votos = []
    for k, (u, b, fr) in enumerate(unid):
        if k % 10 in (3, 7):
            continue  # ausentes
        votos.append(("Aprovacao das contas do exercicio", u, "SIM" if k % 6 else "ABSTENCAO", "N"))
        votos.append(("Pintura da fachada (obra voluptuaria)", u, "SIM" if k % 3 else "NAO", "S" if k % 9 == 0 else "N"))
    w(a.pasta, "votos.csv", ["item", "unidade", "voto", "procuracao"], votos)
    oc = [
        ("1", antes(16), "A-104", "Manutencao", "Infiltracao no teto do banheiro vinda da unidade de cima", "ANDAMENTO", ""),
        ("2", antes(40), "B-402", "Barulho", "Som alto apos 22h (relato do vizinho)", "FECHADA", antes(38)),
        ("3", antes(20), "B-402", "Barulho", "Som alto apos 22h (relato do vizinho)", "FECHADA", antes(19)),
        ("4", antes(3), "B-402", "Barulho", "Som alto apos 22h (relato do vizinho)", "ABERTA", ""),
        ("5", antes(1), "AREA COMUM", "Seguranca", "Portao da garagem ficando aberto apos passagem", "ABERTA", ""),
        ("6", antes(8), "A-503", "Vaga", "Veiculo de visitante na vaga da unidade", "FECHADA", antes(6)),
        ("7", antes(2), "B-201", "Pedido", "Agendamento de mudanca", "ABERTA", ""),
        ("8", antes(10), "A-305", "Pet", "Cachorro sem guia no elevador", "FECHADA", antes(9)),
    ]
    w(a.pasta, "ocorrencias.csv", ["id", "abertura", "unidade", "tipo", "descricao", "status", "fechamento"], oc)
    cons = []
    for k in range(-8, 0):
        y, m = mes_add(hoje.year, hoje.month, k)
        mes = f"{y:04d}-{m:02d}"
        agua = 480 * (1 + rnd.uniform(-0.05, 0.05)) * (1.35 if k == -1 else 1)
        ener = 2600 * (1 + rnd.uniform(-0.06, 0.06))
        cons.append((mes, "AGUA", br(round(agua, 1)), br(round(agua * 7.1, 2))))
        cons.append((mes, "ENERGIA", br(round(ener, 1)), br(round(ener * 0.85, 2))))
    w(a.pasta, "consumo.csv", ["mes", "tipo", "quantidade", "valor"], cons)
    idx = []
    for k in range(-14, 1):
        y, m = mes_add(hoje.year, hoje.month, k)
        idx.append((f"{y:04d}-{m:02d}", br(0.38), br(0.72)))
    w(a.pasta, "indices.csv", ["mes", "ipca_pct", "juros_pct"], idx)
    print(f"Dados ficticios gerados em {a.pasta} (referencia {hoje}).")


if __name__ == "__main__":
    main()
