# Termo de ciência — WhatsApp em modo NÃO OFICIAL

Condomínio: ____________________________  Número de WhatsApp usado: (__) _____-______

Eu, síndico(a) acima identificado(a), declaro que:

1. Escolhi conectar o atendimento automático ao WhatsApp pelo **modo não oficial** (cliente não oficial, como a Evolution API), que **não é autorizado pelos Termos de Serviço do WhatsApp**.
2. Sei que o número pode ser **banido a qualquer momento, sem aviso**, com perda do número e do histórico das conversas, e que não há garantia de recuperação.
3. Sei que existe o **modo oficial** (WhatsApp Cloud API da Meta), sem esse risco, e que posso trocar de modo quando quiser.
4. A Evolution API (ou ferramenta equivalente) foi **instalada e é mantida por mim ou por quem eu contratei**; ela não faz parte do pacote "Condomínio – Gestão com IA".
5. Usarei um **número exclusivo** do condomínio, o atendimento só **responde** a quem escreve (sem envio em massa nem cobrança) e os moradores foram **avisados** sobre o atendimento automático e o tratamento dos dados (LGPD).
6. Assumo a responsabilidade pelas consequências dessa escolha perante o condomínio e terceiros.

Local e data: ______________________

Para ativar, o agente procura a linha abaixo preenchida no arquivo `termo-ciencia-whatsapp.md` da pasta `CONDOMINIO_DADOS`:

ACEITO POR: <nome do síndico> em <AAAA-MM-DD>

*Modelo: revise com um advogado antes de usar.*
