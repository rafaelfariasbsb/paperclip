---
name: "Revisão semestral do orçamento"
assignee: financeiro
recurring: true
---

Compare o realizado do 1º semestre com o orçamento aprovado (`python3 scripts/balancete.py` mês a mês) e projete o 2º semestre. Se houver risco de déficit, apresente opções ao síndico (cortes, renegociação, rateio extra para a assembleia), sem decidir.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
