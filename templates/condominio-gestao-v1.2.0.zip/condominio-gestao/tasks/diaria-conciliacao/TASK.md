---
name: "Conciliação bancária"
assignee: financeiro
recurring: true
---

Rode `python3 scripts/conciliar.py "$CONDOMINIO_DADOS/entrada" --dias 7` (skill `conciliacao-bancaria`). Cada saída no banco sem lançamento vira tarefa `[SINDICO]` urgente. Liste duplicidades e lançamentos sem movimento. Nunca acessar o banco nem pagar.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
