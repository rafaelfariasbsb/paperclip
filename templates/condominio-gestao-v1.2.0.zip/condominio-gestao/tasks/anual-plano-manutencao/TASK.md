---
name: "Revisão anual do plano de manutenção e custos"
assignee: manutencao-predial
recurring: true
---

Revise `plano_manutencao.csv` com o zelador e o manual da construtora (NBR 14037). Estime o custo de cada manutenção e laudo do próximo ano e envie ao `financeiro` para a previsão orçamentária.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
