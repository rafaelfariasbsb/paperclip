---
name: "Implantação: configurar o condomínio"
assignee: implantacao
---

Siga o passo a passo do agente de implantação: entrevista com o síndico, `config-condominio.md`, validação dos dados (`validar_dados.py`), planilhas `documentos.csv` e `plano_manutencao.csv`, conferência de LGPD e relatório de implantação ao gerente-geral.
