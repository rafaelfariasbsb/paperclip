---
name: "Balancete e orçado x realizado para o conselho"
assignee: financeiro
recurring: true
---

Rode `python3 scripts/balancete.py "$CONDOMINIO_DADOS/entrada" --mes <mês anterior>` (skill `balancete-prestacao-contas`). Explique cada desvio acima de 10% e liste lançamentos sem documento. Entregue o pacote `[CONSELHO]` até o dia 10.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
