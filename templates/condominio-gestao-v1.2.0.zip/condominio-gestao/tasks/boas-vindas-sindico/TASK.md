---
name: "Boas-vindas: como esta empresa funciona"
assignee: gerente-geral
---

Escreva ao síndico uma mensagem curta explicando:
- o que cada agente faz;
- o que nunca fazem: enviar, pagar, assinar, cobrar, multar ou decidir;
- quais tarefas pedem aprovação dele e quais vão para o conselho ou a assembleia;
- que as rotinas começam desligadas e são ativadas por ele quando a implantação terminar.
