---
name: "Fechamento do mês e pauta com o conselho"
assignee: gerente-geral
recurring: true
---

Consolide os indicadores do mês de todos os agentes, proponha metas e parâmetros para o mês seguinte (sem aplicar) e monte a pauta da reunião do síndico com o conselho.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
