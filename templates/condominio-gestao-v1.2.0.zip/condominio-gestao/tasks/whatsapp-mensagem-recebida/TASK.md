---
name: "WhatsApp: mensagem recebida"
assignee: atendimento-whatsapp
recurring: true
---

Acordado pelo webhook da Evolution API (modo não oficial) ou do provedor (modo oficial). Siga o agente `atendimento-whatsapp` e a skill `whatsapp-atendimento`: rode `python3 scripts/whatsapp_caixa.py`, responda só a lista fechada com `whatsapp_enviar.py`, urgências com a orientação de emergência e `[SINDICO] URGENTE`, e encaminhe o resto ao síndico.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
