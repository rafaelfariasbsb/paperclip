---
name: "Resumo diário para o síndico"
assignee: gerente-geral
recurring: true
---

Consolide os resultados do dia dos outros agentes no formato da skill `relatorios-para-o-sindico`, em no máximo 10 linhas. Destaque urgências e aprovações pendentes.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
