---
name: "Manutenção: atrasadas e próximas 30 dias"
assignee: manutencao-predial
recurring: true
---

Rode `python3 scripts/manutencao.py "$CONDOMINIO_DADOS/entrada" --janela 30` (skill `plano-manutencao-nbr5674`). Monte a lista de serviço da semana para o zelador e abra `[SINDICO]` para cada item atrasado que exige laudo ou ART.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
