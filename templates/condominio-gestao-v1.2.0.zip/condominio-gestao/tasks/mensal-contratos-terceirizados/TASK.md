---
name: "Contratos e certidões dos prestadores"
assignee: conformidade
recurring: true
---

Rode `python3 scripts/prazos.py "$CONDOMINIO_DADOS/entrada"` e destaque contratos que vencem ou reajustam nos próximos 60 dias e prestadores com certidões vencidas (risco trabalhista, Súmula 331 do TST). Rascunho do pedido de certidões para o síndico enviar.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
