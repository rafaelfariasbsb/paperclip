---
name: "Checklist de obrigações trabalhistas e fiscais do mês"
assignee: conformidade
recurring: true
---

Monte o checklist do mês da skill `obrigacoes-trabalhistas-fiscais` (eSocial, FGTS Digital, EFD-Reinf, DCTFWeb, retenções) e deixe-o como tarefa para a administradora ou o contador confirmar "enviado em / protocolo". No dia 20, o que não foi confirmado vira `[SINDICO]`. Nunca pedir senha ou certificado.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
