---
name: "Previsão orçamentária e rateio para a assembleia"
assignee: financeiro
recurring: true
---

Rode `python3 scripts/orcamento.py "$CONDOMINIO_DADOS/entrada"` com reajustes, inadimplência, fundo de reserva e rateio de `config-condominio.md` e o custo anual de manutenção (`--extra-anual`). Monte a memória de cálculo para a assembleia (skill `previsao-orcamentaria-rateio`). Ajuste a data desta rotina para 60 dias antes da assembleia ordinária.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
