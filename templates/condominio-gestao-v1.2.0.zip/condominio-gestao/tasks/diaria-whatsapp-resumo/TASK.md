---
name: "WhatsApp: resumo do dia e retenção"
assignee: atendimento-whatsapp
recurring: true
---

Rode `python3 scripts/whatsapp_caixa.py` (para não deixar mensagem sem tratar) e `python3 scripts/whatsapp_resumo.py`. Envie ao síndico só as contagens e a lista de tarefas `[SINDICO]` abertas no dia; o expurgo de 90 dias roda junto.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
