---
name: "Consumo de água, energia e gás"
assignee: manutencao-predial
recurring: true
---

Rode `python3 scripts/consumo.py "$CONDOMINIO_DADOS/entrada" --meses 6 --limite 20` (skill `consumo-agua-energia`). Cada alerta vira tarefa de verificação para o zelador; gás vira `[SINDICO]` urgente.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
