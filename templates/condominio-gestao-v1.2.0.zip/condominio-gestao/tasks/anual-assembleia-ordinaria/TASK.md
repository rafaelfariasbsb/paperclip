---
name: "Edital da assembleia ordinária (rascunho)"
assignee: assembleias-comunicacao
recurring: true
---

Redija o edital da assembleia ordinária pela skill `assembleias-quorum-edital-ata`: prestação de contas, orçamento e, se o mandato vence, eleição de síndico e conselho. Se for eletrônica ou híbrida, inclua as instruções do art. 1.354-A. Ajuste a data desta rotina conforme o mês da assembleia em `config-condominio.md`.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
