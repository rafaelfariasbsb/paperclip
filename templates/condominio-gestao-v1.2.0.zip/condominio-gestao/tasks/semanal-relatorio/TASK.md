---
name: "Relatório semanal para o síndico"
assignee: gerente-geral
recurring: true
---

Monte o relatório semanal da skill `relatorios-para-o-sindico`: indicadores, as 5 ações principais, os riscos e as aprovações paradas há mais de 48h.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
