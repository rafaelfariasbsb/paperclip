---
name: "Prazos de documentos, laudos, seguro e contratos"
assignee: conformidade
recurring: true
---

Rode `python3 scripts/prazos.py "$CONDOMINIO_DADOS/entrada" --alertas 60,30,7` (skill `documentos-laudos-seguro`). Abra tarefa `[SINDICO]` para cada item vencido ou a vencer, com o que contratar ou renovar e quanto tempo costuma levar.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
