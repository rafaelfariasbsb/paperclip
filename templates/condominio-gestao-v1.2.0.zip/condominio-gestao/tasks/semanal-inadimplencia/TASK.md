---
name: "Inadimplência e régua de cobrança"
assignee: cobranca
recurring: true
---

Rode `python3 scripts/inadimplencia.py "$CONDOMINIO_DADOS/entrada"` com multa e juros de `config-condominio.md` (`--juros-mensal` se a convenção fixar; senão `indices.csv`). Para cada unidade, proponha a etapa da skill `regua-cobranca-respeitosa` com o rascunho da mensagem. Relatório **interno**. **Não envie nada.**

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
