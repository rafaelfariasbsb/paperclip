---
name: "Chamados e ocorrências do dia"
assignee: atendimento-moradores
recurring: true
---

Rode `python3 scripts/ocorrencias.py "$CONDOMINIO_DADOS/entrada" --prazo <prazo de config-condominio.md>` (skill `ocorrencias-e-regimento`). Segurança vira `[SINDICO]` urgente; manutenção vira tarefa para `manutencao-predial`; reincidência vira rascunho de notificação com prazo de defesa. **Não responda moradores.**

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
