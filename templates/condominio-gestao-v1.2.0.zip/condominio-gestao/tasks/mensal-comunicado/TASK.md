---
name: "Circular do mês aos moradores (rascunho)"
assignee: assembleias-comunicacao
recurring: true
---

Redija a circular do mês seguinte pela skill `comunicados-moradores`: manutenções programadas (da rotina de manutenção), um lembrete do regimento e avisos da administração. Sem citar unidades. **Não envie.**

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
