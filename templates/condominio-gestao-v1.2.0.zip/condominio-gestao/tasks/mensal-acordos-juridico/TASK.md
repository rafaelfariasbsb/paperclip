---
name: "Acordos em andamento e casos para o advogado"
assignee: cobranca
recurring: true
---

Rode `python3 scripts/inadimplencia.py "$CONDOMINIO_DADOS/entrada"`. Liste acordos com parcela atrasada e unidades que atingiram a etapa do advogado na régua, com o dossiê (boletos, cálculo, ata ou convenção que aprova a cota). Decisão do síndico.

Regras: carregue a skill `limites-do-sindico`. Se `config-condominio.md` não existir, avise que o condomínio ainda não foi configurado e pare. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$CONDOMINIO_DADOS/saida/`.
