"""Funcoes comuns dos scripts de WhatsApp (sem dependencias externas).
Configuracao por variaveis de ambiente (segredos do agente no Paperclip, nunca na pasta de dados):
  WHATSAPP_MODO          oficial | nao_oficial
  -- nao_oficial (Evolution API local) --
  EVOLUTION_URL          ex.: http://127.0.0.1:8080
  EVOLUTION_APIKEY       chave da Evolution API
  EVOLUTION_INSTANCIA    nome da instancia (numero do condominio)
  -- oficial (WhatsApp Cloud API da Meta) --
  META_TOKEN             token de acesso do sistema (System User)
  META_PHONE_NUMBER_ID   id do numero na Meta
  META_API_VERSAO        opcional, padrao v21.0 [conferir a versao vigente]
  META_API_URL           opcional, padrao https://graph.facebook.com
Estado e conversas ficam em $CONDOMINIO_DADOS/whatsapp/ (area com dado pessoal; retencao de 90 dias).
"""
import json, os, sys, time, urllib.request, urllib.error

LIMITE_HORA_TOTAL = 30
LIMITE_HORA_NUMERO = 5
JANELA_RESPOSTA_S = 24 * 3600
RETENCAO_DIAS = 90


def pasta_whats():
    base = os.environ.get("CONDOMINIO_DADOS")
    if not base:
        sys.exit("CONDOMINIO_DADOS nao definida.")
    p = os.path.join(base, "whatsapp")
    os.makedirs(os.path.join(p, "conversas"), exist_ok=True)
    return base, p


def carregar_estado(p):
    f = os.path.join(p, "estado.json")
    if os.path.exists(f):
        return json.load(open(f, encoding="utf-8"))
    return {"ultimo_ts": 0, "vistos": [], "ultima_msg_de": {}, "envios": []}


def salvar_estado(p, e):
    e["vistos"] = e["vistos"][-2000:]
    agora = time.time()
    e["envios"] = [x for x in e["envios"] if agora - x[0] < 3600]
    tmp = os.path.join(p, "estado.json.tmp")
    json.dump(e, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    os.replace(tmp, os.path.join(p, "estado.json"))


def registrar(p, numero, direcao, texto, ts=None):
    ts = ts or time.time()
    dia = time.strftime("%Y-%m-%d", time.localtime(ts))
    with open(os.path.join(p, "conversas", f"{dia}.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": int(ts), "numero": numero, "direcao": direcao, "texto": texto}, ensure_ascii=False) + "\n")


def expurgar(p):
    limite = time.time() - RETENCAO_DIAS * 86400
    n = 0
    for nome in os.listdir(os.path.join(p, "conversas")):
        try:
            if time.mktime(time.strptime(nome[:10], "%Y-%m-%d")) < limite:
                os.remove(os.path.join(p, "conversas", nome)); n += 1
        except ValueError:
            pass
    return n


def termo_aceito(base):
    """Exige a linha 'ACEITO POR: <nome> em AAAA-MM-DD' preenchida (o modelo vem com '<...>' e nao vale)."""
    import re
    f = os.path.join(base, "termo-ciencia-whatsapp.md")
    if not os.path.exists(f):
        return False
    return re.search(r"^ACEITO POR:\s*[^<\s].*\bem\s+\d{4}-\d{2}-\d{2}\s*$", open(f, encoding="utf-8").read(), re.M) is not None


def modo():
    m = os.environ.get("WHATSAPP_MODO", "").strip().lower()
    if m not in ("oficial", "nao_oficial"):
        sys.exit("WHATSAPP_MODO deve ser 'oficial' ou 'nao_oficial' (configurado pelo sindico na implantacao).")
    return m


def http(metodo, url, corpo=None, cabecalhos=None, timeout=20):
    dados = json.dumps(corpo).encode() if corpo is not None else None
    req = urllib.request.Request(url, data=dados, method=metodo, headers={"Content-Type": "application/json", **(cabecalhos or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode() or "{}"
            return r.status, json.loads(txt)
    except urllib.error.HTTPError as e:
        return e.code, {"erro": e.read().decode(errors="replace")[:500]}
    except urllib.error.URLError as e:
        return 0, {"erro": str(e.reason)}


def numero_limpo(n):
    return "".join(c for c in str(n).split("@")[0] if c.isdigit())
