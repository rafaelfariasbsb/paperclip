#!/usr/bin/env python3
"""Responde a um morador pelo WhatsApp do condominio, com as travas do pacote.
Uso: python3 whatsapp_enviar.py <numero> "<texto>" [--simular]
Travas (nao podem ser desligadas pelo agente):
- so responde a numero que escreveu nas ultimas 24h (nunca inicia conversa, nunca envia em massa);
- no maximo 30 mensagens por hora no total e 5 por numero;
- texto de ate 1000 caracteres;
- modo nao_oficial exige o termo de ciencia aceito pelo sindico.
"""
import argparse, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from whatsapp_comum import *  # noqa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("numero")
    ap.add_argument("texto")
    ap.add_argument("--simular", action="store_true", help="aplica as travas e mostra o que seria enviado, sem enviar")
    a = ap.parse_args()
    base, p = pasta_whats()
    md = modo()
    num = numero_limpo(a.numero)
    texto = a.texto.strip()
    if md == "nao_oficial" and not termo_aceito(base):
        sys.exit("BLOQUEADO: modo nao oficial sem termo de ciencia aceito pelo sindico.")
    if not texto or len(texto) > 1000:
        sys.exit("BLOQUEADO: texto vazio ou com mais de 1000 caracteres.")
    e = carregar_estado(p)
    agora = time.time()
    ultima = e["ultima_msg_de"].get(num, 0)
    if agora - ultima > JANELA_RESPOSTA_S:
        sys.exit("BLOQUEADO: este numero nao escreveu nas ultimas 24h. O agente so responde; nao inicia conversa.")
    recentes = [x for x in e["envios"] if agora - x[0] < 3600]
    if len(recentes) >= LIMITE_HORA_TOTAL:
        sys.exit("BLOQUEADO: limite de 30 mensagens por hora atingido. Abra tarefa [SINDICO] se houver urgencia.")
    if sum(1 for x in recentes if x[1] == num) >= LIMITE_HORA_NUMERO:
        sys.exit("BLOQUEADO: limite de 5 mensagens por hora para este numero. Encaminhe ao sindico.")
    if a.simular:
        print(f"SIMULACAO ({md}) para {num}:\n{texto}")
        return
    if md == "nao_oficial":
        url = os.environ.get("EVOLUTION_URL", "http://127.0.0.1:8080").rstrip("/")
        st, r = http("POST", f"{url}/message/sendText/{os.environ.get('EVOLUTION_INSTANCIA', '')}",
                     {"number": num, "text": texto}, {"apikey": os.environ.get("EVOLUTION_APIKEY", "")})
    else:
        ver = os.environ.get("META_API_VERSAO", "v21.0")
        api = os.environ.get("META_API_URL", "https://graph.facebook.com").rstrip("/")
        st, r = http("POST", f"{api}/{ver}/{os.environ.get('META_PHONE_NUMBER_ID', '')}/messages",
                     {"messaging_product": "whatsapp", "to": num, "type": "text", "text": {"body": texto}},
                     {"Authorization": f"Bearer {os.environ.get('META_TOKEN', '')}"})
    if st not in (200, 201):
        sys.exit(f"FALHOU ({st}): {r}. Nada foi registrado como enviado.")
    e["envios"].append([agora, num])
    salvar_estado(p, e)
    registrar(p, num, "enviada", texto, agora)
    print(f"ENVIADO ({md}) para {num}.")


if __name__ == "__main__":
    main()
