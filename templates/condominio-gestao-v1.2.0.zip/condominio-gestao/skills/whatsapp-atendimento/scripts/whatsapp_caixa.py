#!/usr/bin/env python3
"""Lista as mensagens novas recebidas no WhatsApp do condominio e marca como vistas.
Uso: python3 whatsapp_caixa.py [--max 50] [--nao-marcar]
- Modo nao_oficial: busca na Evolution API local (POST /chat/findMessages/<instancia>).
- Modo oficial: le as mensagens que o provedor gravou em $CONDOMINIO_DADOS/whatsapp/entrada-oficial/*.json
  (formato do webhook da Cloud API). A entrega dessas mensagens depende do provedor ou tunel escolhido.
Ignora grupos, status e mensagens enviadas pelo proprio numero. Saida: Markdown com numero, unidade (se conhecida) e texto.
"""
import argparse, csv, glob, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from whatsapp_comum import *  # noqa


def texto_evolution(msg):
    m = msg.get("message") or {}
    return (m.get("conversation") or (m.get("extendedTextMessage") or {}).get("text")
            or (m.get("imageMessage") or {}).get("caption") or ("[midia]" if m else ""))


def buscar_evolution():
    url = os.environ.get("EVOLUTION_URL", "http://127.0.0.1:8080").rstrip("/")
    inst = os.environ.get("EVOLUTION_INSTANCIA", "")
    st, r = http("POST", f"{url}/chat/findMessages/{inst}", {"where": {"key": {"fromMe": False}}},
                 {"apikey": os.environ.get("EVOLUTION_APIKEY", "")})
    if st != 200:
        sys.exit(f"Evolution API respondeu {st}: {r}. Confira se ela esta rodando e conectada (QR code).")
    regs = r.get("messages", {}).get("records") if isinstance(r, dict) else r  # v2 pagina em messages.records
    out = []
    for m in regs or []:
        k = m.get("key") or {}
        jid = k.get("remoteJid", "")
        if k.get("fromMe") or not jid.endswith("@s.whatsapp.net"):
            continue
        out.append((k.get("id"), int(m.get("messageTimestamp") or 0), numero_limpo(jid), texto_evolution(m)))
    return out


def buscar_oficial(p):
    out = []
    for f in sorted(glob.glob(os.path.join(p, "entrada-oficial", "*.json"))):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except ValueError:
            continue
        for ent in d.get("entry", []):
            for ch in ent.get("changes", []):
                for m in (ch.get("value") or {}).get("messages", []) or []:
                    txt = (m.get("text") or {}).get("body") or f"[{m.get('type', 'midia')}]"
                    out.append((m.get("id"), int(m.get("timestamp") or 0), numero_limpo(m.get("from")), txt))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max", type=int, default=50)
    ap.add_argument("--nao-marcar", action="store_true")
    a = ap.parse_args()
    base, p = pasta_whats()
    md = modo()
    if md == "nao_oficial" and not termo_aceito(base):
        sys.exit("Modo nao oficial sem termo de ciencia aceito (termo-ciencia-whatsapp.md). Nada foi lido.")
    e = carregar_estado(p)
    vistos = set(e["vistos"])
    msgs = buscar_evolution() if md == "nao_oficial" else buscar_oficial(p)
    novas = sorted([m for m in msgs if m[0] and m[0] not in vistos], key=lambda m: m[1])[: a.max]
    contatos = {}
    f = os.path.join(p, "contatos.csv")
    if os.path.exists(f):
        for r in csv.DictReader(open(f, encoding="utf-8-sig"), delimiter=";"):
            contatos[numero_limpo(r.get("telefone", ""))] = r.get("unidade", "")
    print(f"# Caixa do WhatsApp ({md}) - {len(novas)} mensagem(ns) nova(s)\n")
    for mid, ts, num, txt in novas:
        unidade = contatos.get(num) or "NAO IDENTIFICADA"
        print(f"- [{time.strftime('%d/%m %H:%M', time.localtime(ts))}] numero {num} · unidade {unidade}: {txt}")
        if not a.nao_marcar:
            e["vistos"].append(mid)
            e["ultima_msg_de"][num] = max(ts, e["ultima_msg_de"].get(num, 0))
            registrar(p, num, "recebida", txt, ts)
    if not novas:
        print("Nenhuma mensagem nova.")
    if not a.nao_marcar:
        salvar_estado(p, e)
    print("\n> Responda so os assuntos da lista fechada (skill whatsapp-atendimento) com whatsapp_enviar.py. O resto vira tarefa [SINDICO].")


if __name__ == "__main__":
    main()
