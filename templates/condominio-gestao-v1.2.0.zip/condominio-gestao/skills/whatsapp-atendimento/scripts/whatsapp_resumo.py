#!/usr/bin/env python3
"""Resumo do dia do WhatsApp para o sindico e expurgo das conversas com mais de 90 dias.
Uso: python3 whatsapp_resumo.py [--dia AAAA-MM-DD]
Mostra contagens (mensagens recebidas/enviadas, numeros distintos, numeros sem resposta). Nao mostra o texto das conversas.
"""
import argparse, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from whatsapp_comum import *  # noqa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dia", default=time.strftime("%Y-%m-%d"))
    a = ap.parse_args()
    _, p = pasta_whats()
    f = os.path.join(p, "conversas", f"{a.dia}.jsonl")
    rec, env = {}, {}
    if os.path.exists(f):
        for linha in open(f, encoding="utf-8"):
            m = json.loads(linha)
            (rec if m["direcao"] == "recebida" else env)[m["numero"]] = (rec if m["direcao"] == "recebida" else env).get(m["numero"], 0) + 1
    sem_resp = [n for n in rec if n not in env]
    print(f"# WhatsApp em {a.dia}\n")
    print(f"- Mensagens recebidas: {sum(rec.values())} de {len(rec)} numero(s)")
    print(f"- Respostas enviadas: {sum(env.values())}")
    print(f"- Numeros sem resposta automatica (encaminhados ou pendentes): {len(sem_resp)}")
    print(f"- Conversas apagadas por retencao (> {RETENCAO_DIAS} dias): {expurgar(p)} arquivo(s)")
    print("\n> Confira as tarefas [SINDICO] abertas pelo agente para os numeros sem resposta.")


if __name__ == "__main__":
    main()
