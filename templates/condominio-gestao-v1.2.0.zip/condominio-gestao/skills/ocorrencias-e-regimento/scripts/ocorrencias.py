#!/usr/bin/env python3
"""Chamados e ocorrencias: abertos, fora do prazo (dias uteis), reincidencia e tipos do mes.
Uso: python3 ocorrencias.py <pasta> [--hoje AAAA-MM-DD] [--prazo 3] [--janela 90]
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def dias_uteis(d1, d2):
    n, d = 0, d1
    while d < d2:
        d += timedelta(days=1)
        if d.weekday() < 5:
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--prazo", type=int, default=3)
    ap.add_argument("--janela", type=int, default=90)
    a = ap.parse_args()
    hoje = dt(a.hoje)
    oc = exigir(a.pasta, "ocorrencias.csv")
    abertas = [r for r in oc if r["status"].upper() != "FECHADA"]
    print(f"# Ocorrencias em {hoje}\n\nAbertas ou em andamento: {len(abertas)}\n")
    print("| Id | Aberta em | Unidade | Tipo | Dias uteis | Situacao | Descricao |\n|---|---|---|---|---|---|---|")
    fora = 0
    for r in sorted(abertas, key=lambda r: r["abertura"]):
        du = dias_uteis(dt(r["abertura"]), hoje)
        seg = "seguranc" in r["tipo"].lower()
        sit = "URGENTE (seguranca)" if seg else ("FORA DO PRAZO" if du > a.prazo else "no prazo")
        fora += du > a.prazo
        print(f"| {r['id']} | {r['abertura']} | {r['unidade']} | {r['tipo']} | {du} | {sit} | {r['descricao'][:60]} |")
    print(f"\nFora do prazo de {a.prazo} dias uteis: {fora}")
    ini = hoje - timedelta(days=a.janela)
    rec = defaultdict(int)
    for r in oc:
        if dt(r["abertura"]) >= ini:
            rec[(r["unidade"], r["tipo"])] += 1
    rein = [(k, v) for k, v in rec.items() if v >= 2]
    print(f"\n## Reincidencia nos ultimos {a.janela} dias (2 ou mais)\n")
    for (u, t), v in sorted(rein, key=lambda x: -x[1]):
        print(f"- {u} / {t}: {v} ocorrencias -> avaliar notificacao pelo regimento (com prazo de defesa)")
    if not rein:
        print("Nenhuma.")
    mes = hoje.strftime("%Y-%m")
    tipos = defaultdict(int)
    for r in oc:
        if r["abertura"].startswith(mes):
            tipos[r["tipo"]] += 1
    print(f"\n## Tipos no mes {mes}\n")
    for t, v in sorted(tipos.items(), key=lambda x: -x[1]):
        print(f"- {t}: {v}")
    fech = [r for r in oc if r["status"].upper() == "FECHADA" and r["fechamento"]]
    if fech:
        no_prazo = sum(dias_uteis(dt(r["abertura"]), dt(r["fechamento"])) <= a.prazo for r in fech)
        print(f"\nChamados fechados no prazo: {no_prazo}/{len(fech)} ({no_prazo / len(fech) * 100:.0f}%)")
    print("\n> Relatorio interno. O agente nao responde moradores nem aplica multa.")


if __name__ == "__main__":
    main()
