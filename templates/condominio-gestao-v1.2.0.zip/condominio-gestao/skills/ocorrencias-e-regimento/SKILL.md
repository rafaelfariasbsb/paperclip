---
name: ocorrencias-e-regimento
description: "Controle de chamados e ocorrências dos moradores com prazo, reincidência e procedimento de notificação e multa pelo regimento, com direito de defesa."
---

# Ocorrências e regimento interno

`python3 scripts/ocorrencias.py "$CONDOMINIO_DADOS/entrada" --hoje AAAA-MM-DD --prazo 3`

- Lista chamados abertos e em andamento com idade em dias úteis e marca os que passaram do `--prazo`.
- Conta reincidência por unidade e tipo nos últimos 90 dias.
- Resume os tipos mais frequentes do mês (barulho, vazamento, vaga, pet, lixo, obra, segurança).

## Encaminhamentos
| Tipo | Caminho |
|---|---|
| Manutenção (vazamento, lâmpada, portão) | tarefa para o agente de manutenção |
| Convivência (barulho, pet, vaga) | orientação ao morador com o artigo do regimento; reincidência leva a notificação |
| Segurança (portão aberto, invasão, briga) | `[SINDICO]` urgente |
| Pedido (mudança, reserva, reforma) | confere a regra e prepara parecer |

## Procedimento de penalidade (rascunhos para o síndico)
1. **Registro do fato:** data, hora, o que aconteceu, quem relatou (sem expor o relator ao vizinho), evidência disponível.
2. **Advertência ou notificação** escrita, citando o artigo do regimento ou da convenção e dando **prazo de defesa** **[conferir]** prazo na convenção.
3. **Análise da defesa** pelo síndico (ou pelo conselho, se a convenção mandar).
4. **Multa**, se mantida: valor e competência pela convenção. Limites do Código Civil:
   - obra que comprometa a segurança, mudança de fachada ou uso nocivo da unidade (art. 1.336, II a IV): até 5 vezes a cota, conforme a convenção (art. 1.336, §2º);
   - descumprimento reiterado de deveres: até 5 vezes a cota, por deliberação de 3/4 dos condôminos restantes (art. 1.337, caput);
   - comportamento antissocial reiterado: até 10 vezes a cota, até nova deliberação da assembleia (art. 1.337, parágrafo único).
5. **Cobrança** junto com a cota, sem exposição.

Sem direito de defesa, a multa é frágil na Justiça. O agente nunca aplica multa, só prepara o procedimento.
