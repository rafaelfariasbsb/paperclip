---
name: assembleias-quorum-edital-ata
description: "Convocação, edital, quóruns do Código Civil, assembleia eletrônica (art. 1.354-A), apuração de votos por fração ideal e modelo de ata."
---

# Assembleias: edital, quórum e ata

`python3 scripts/apurar_votos.py "$CONDOMINIO_DADOS/entrada" --quorum maioria_presentes`

- Soma os votos de `votos.csv` por item, pela **fração ideal** de `unidades.csv` (ou por unidade, com `--peso unidade`, se a convenção mandar).
- Confere o quórum pedido (`--quorum`): `maioria_presentes`, `maioria_absoluta` (mais da metade das frações do condomínio), `dois_tercos` (2/3 das frações do condomínio; confira se a convenção conta por fração ou por unidade) ou `unanimidade`.
- Informa: presentes (frações), votos SIM/NÃO/ABSTENÇÃO e se o item **atingiu** o quórum.

## Quóruns do Código Civil (a convenção pode exigir mais) **[conferir]** sempre a convenção
| Deliberação | Quórum |
|---|---|
| Regra geral, 1ª convocação | maioria dos presentes que representem pelo menos metade das frações ideais (art. 1.352) |
| Regra geral, 2ª convocação | maioria dos presentes, salvo quórum especial (art. 1.353) |
| Alterar a convenção | 2/3 dos votos dos condôminos (art. 1.351) |
| Mudar a destinação do edifício ou da unidade | 2/3 dos votos dos condôminos (art. 1.351, redação da Lei 14.405/2022) |
| Obras voluptuárias (embelezamento) | 2/3 dos condôminos (art. 1.341, I) |
| Obras úteis | maioria dos condôminos (art. 1.341, II) |
| Obras ou acréscimos em área comum para facilitar uso | 2/3 dos condôminos (art. 1.342) |
| Destituir o síndico | maioria absoluta dos membros da assembleia (art. 1.349) |
| Multa por descumprimento reiterado de deveres | 3/4 dos condôminos restantes (art. 1.337) |

## Edital
- Quem convoca: o síndico; ou 1/4 dos condôminos, se ele não convocar (art. 1.350, §1º).
- Todos os condôminos devem ser convocados, ou a deliberação pode ser anulada (art. 1.354).
- Pauta clara, item por item. Assunto fora da pauta não pode ser votado.
- Antecedência e forma de entrega pela convenção **[conferir]**.
- **Assembleia eletrônica ou híbrida** (art. 1.354-A, Lei 14.309/2022): permitida se a convenção não proibir. O edital deve dizer que será eletrônica e trazer as instruções de acesso, de manifestação e de coleta de votos. A gravação e a ata ficam à disposição dos condôminos.
- **Sessão permanente:** se um item exigir quórum especial não atingido, a assembleia pode, pela maioria dos presentes, converter a reunião em sessão permanente por até 90 dias, para colher os votos que faltam.

## Assembleia ordinária anual (art. 1.350)
Pauta mínima: prestação de contas do ano, orçamento e contribuições do ano seguinte e, quando for o caso, eleição do síndico (mandato de até 2 anos, art. 1.347) e do conselho.

## Modelo de ata
Data, hora, local ou plataforma; convocação (1ª ou 2ª); presentes por fração ideal e lista de presença anexa; mesa (presidente e secretário); cada item com a discussão resumida, a votação (frações SIM/NÃO/ABSTENÇÃO) e o resultado com o quórum aplicado; encerramento e assinaturas. Sem comentários pessoais e sem identificar devedores.
