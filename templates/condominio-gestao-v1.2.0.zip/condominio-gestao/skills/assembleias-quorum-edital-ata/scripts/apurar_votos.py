#!/usr/bin/env python3
"""Apuracao de votos por fracao ideal (ou por unidade) e conferencia de quorum.
Uso: python3 apurar_votos.py <pasta> [--quorum maioria_presentes|maioria_absoluta|dois_tercos|unanimidade]
       [--peso fracao|unidade] [--quorum-item "item=dois_tercos" ...]
Unidades em atraso nao votam (art. 1.335, III) se --inadimplentes-nao-votam for usado com cobrancas.csv.
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--quorum", default="maioria_presentes")
    ap.add_argument("--quorum-item", action="append", default=[])
    ap.add_argument("--peso", choices=["fracao", "unidade"], default="fracao")
    ap.add_argument("--inadimplentes-nao-votam", action="store_true")
    ap.add_argument("--hoje", default=date.today().isoformat())
    a = ap.parse_args()
    unid = {u["unidade"]: (num(u["fracao_ideal"]) if a.peso == "fracao" else 1.0) for u in exigir(a.pasta, "unidades.csv")}
    total = sum(unid.values())
    votos = exigir(a.pasta, "votos.csv")
    bloqueadas = set()
    if a.inadimplentes_nao_votam:
        hoje = dt(a.hoje)
        for r in ler(a.pasta, "cobrancas.csv") or []:
            if dt(r["vencimento"]) < hoje and num(r["valor"]) - num(r["valor_pago"]) > 0.009:
                bloqueadas.add(r["unidade"])
    qi = dict(s.rsplit("=", 1) for s in a.quorum_item)
    itens = defaultdict(dict)
    desconhecidas = set()
    for r in votos:
        if r["unidade"] not in unid:
            desconhecidas.add(r["unidade"]); continue
        itens[r["item"]][r["unidade"]] = r["voto"].upper()
    print(f"# Apuracao de votos (peso: {'fracao ideal' if a.peso == 'fracao' else 'uma unidade, um voto'})\n")
    for item, vs in itens.items():
        q = qi.get(item, a.quorum)
        val = {u: v for u, v in vs.items() if u not in bloqueadas}
        pres = sum(unid[u] for u in val)
        s = sum(unid[u] for u, v in val.items() if v == "SIM")
        n = sum(unid[u] for u, v in val.items() if v in ("NAO", "NÃO"))
        ab = pres - s - n
        if q == "maioria_presentes":
            ok = s > n; regra = "SIM > NAO entre os presentes"
        elif q == "maioria_absoluta":
            ok = s > total / 2; regra = "SIM > 50% do total"
        elif q == "dois_tercos":
            ok = s >= total * 2 / 3 - 1e-9; regra = "SIM >= 2/3 do total"
        elif q == "unanimidade":
            ok = s >= total - 1e-9; regra = "SIM = 100% do total"
        else:
            print(f"Quorum desconhecido: {q}"); sys.exit(2)
        pct = lambda x: f"{x / total * 100:.2f}%"
        print(f"## {item}\n\n- Quorum aplicado: {q} ({regra})")
        print(f"- Presentes: {len(val)} unidades = {pct(pres)} do total")
        print(f"- SIM: {pct(s)} · NAO: {pct(n)} · ABSTENCAO: {pct(ab)}")
        print(f"- Resultado: **{'APROVADO' if ok else 'NAO APROVADO'}**")
        if q != "maioria_presentes" and not ok:
            print("- Item de quorum especial nao atingido: a assembleia pode converter em sessao permanente (art. 1.354-A, ate 90 dias).")
        if vs.keys() & bloqueadas:
            print(f"- Votos desconsiderados por atraso (art. 1.335, III): {len(vs.keys() & bloqueadas)} unidade(s). Confira a convencao.")
        print()
    if desconhecidas:
        print(f"ATENCAO: unidades que nao existem em unidades.csv: {', '.join(sorted(desconhecidas))}")
    print("> Conferencia para a mesa da assembleia. A convencao pode exigir quorum maior: confira antes de declarar o resultado.")


if __name__ == "__main__":
    main()
