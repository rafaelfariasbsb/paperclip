---
name: cotacao-tres-orcamentos
description: "Quadro comparativo de orçamentos de fornecedores (preço, prazo, garantia, documentação) e checklist mínimo antes de contratar."
---

# Cotação com três orçamentos

`python3 scripts/comparar_orcamentos.py "$CONDOMINIO_DADOS/entrada" --item "<item>"`

- Agrupa `cotacoes.csv` por item e ordena por valor.
- Mostra diferença para o menor preço, prazo, garantia e se a documentação está ok.
- Avisa se o item tem menos de três orçamentos ou se o menor preço está com documentação pendente.

## Checklist do fornecedor (antes de o síndico decidir)
- Escopo igual entre as propostas (mesmo material, mesma área, mesmos serviços); senão a comparação não vale.
- CNPJ ativo e compatível com o serviço; certidões (federal, FGTS, trabalhista) em dia.
- ART ou RRT quando o serviço envolve estrutura, elétrica, gás, SPDA, elevador, fachada ou impermeabilização.
- Seguro de responsabilidade civil e treinamento de trabalho em altura (NR 35) para serviços em altura.
- Contrato com escopo, prazo, garantia, multa por atraso e forma de pagamento por etapa.
- Valor acima do teto de `config-condominio.md`: conselho ou assembleia, conforme a convenção.

O agente não liga, não pede orçamento e não negocia. Ele organiza o que o síndico ou o zelador recebeu.
