#!/usr/bin/env python3
"""Quadro comparativo de orcamentos por item.
Uso: python3 comparar_orcamentos.py <pasta> [--item "<texto>"] [--minimo 3]
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--item")
    ap.add_argument("--minimo", type=int, default=3)
    a = ap.parse_args()
    por_item = defaultdict(list)
    for r in exigir(a.pasta, "cotacoes.csv"):
        if not a.item or a.item.lower() in r["item"].lower():
            por_item[r["item"]].append(r)
    if not por_item:
        print("Nenhuma cotacao encontrada para o filtro.")
        return
    for item, cs in por_item.items():
        cs.sort(key=lambda r: num(r["valor"]))
        menor = num(cs[0]["valor"])
        print(f"# {item}\n\n| Fornecedor | Valor | Dif. p/ menor | Prazo (dias) | Garantia (meses) | Documentos | Observacao |\n|---|---|---|---|---|---|---|")
        for r in cs:
            v = num(r["valor"])
            print(f"| {r['fornecedor']} | {brl(v)} | {((v / menor - 1) * 100 if menor else 0):+.0f}% | {r['prazo_dias']} | {r['garantia_meses']} | {'ok' if r['documentos_ok'].upper() == 'S' else 'PENDENTE'} | {r['observacao']} |")
        print()
        if len(cs) < a.minimo:
            print(f"- ATENCAO: so {len(cs)} orcamento(s); o minimo combinado e {a.minimo}.")
        if cs[0]["documentos_ok"].upper() != "S":
            print("- ATENCAO: o menor preco esta com documentacao pendente (CNPJ, certidoes, ART, seguro).")
        print("- Confira se o escopo e igual entre as propostas antes de comparar preco.\n")
    print("> Quadro para decisao do sindico (ou conselho/assembleia acima do teto da convencao).")


if __name__ == "__main__":
    main()
