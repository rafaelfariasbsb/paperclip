---
name: reformas-unidades-nbr16280
description: "Conferência de pedidos de reforma em unidades pela ABNT NBR 16280: documentos exigidos, responsabilidades e parecer para o síndico."
---

# Reformas nas unidades (NBR 16280)

A NBR 16280 exige que toda reforma que altere sistemas da edificação tenha um **plano de reforma** apresentado ao síndico antes do início. O síndico autoriza ou não; o agente só confere a documentação.

## Documentos a conferir
- Plano de reforma com descrição do serviço, cronograma, empresa ou profissionais, horários e destino do entulho.
- ART ou RRT do responsável técnico quando houver: demolição ou abertura de parede, mudança em instalação elétrica, hidráulica ou de gás, impermeabilização, fachada, esquadrias, estrutura.
- Lista de quem vai trabalhar (para a portaria), sem dados além do necessário.
- Concordância com o regimento: horários de obra, uso de elevador de serviço, proteção das áreas comuns.

## Sinais de alerta (sempre levar ao síndico)
- Remoção de parede sem laudo de que não é estrutural.
- Fechamento de sacada, troca de esquadria ou mudança de fachada (pode exigir assembleia, art. 1.336, III).
- Obra em área de prumada, shaft ou laje.

## Parecer
"Documentação completa / incompleta (falta: ...)", riscos, condições sugeridas. A decisão é do síndico, e responsáveis técnicos respondem pela parte técnica.
