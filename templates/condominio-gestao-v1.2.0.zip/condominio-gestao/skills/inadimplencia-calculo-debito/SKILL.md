---
name: inadimplencia-calculo-debito
description: "Inadimplência por faixa de atraso e cálculo do débito atualizado por unidade: multa de até 2%, juros pela convenção ou pela taxa legal (Lei 14.905/2024) e correção monetária."
---

# Inadimplência e cálculo do débito

`python3 scripts/inadimplencia.py "$CONDOMINIO_DADOS/entrada" --hoje AAAA-MM-DD --multa 2 --juros-mensal 1`

Sem `--juros-mensal`, o script usa a coluna `juros_pct` de `indices.csv` mês a mês (taxa legal). Com `indices.csv`, também aplica a correção pelo IPCA (`ipca_pct`).

## Regras
- **Multa:** até **2%** sobre o débito (Código Civil, art. 1.336, §1º), aplicada **uma vez** por parcela em atraso, não por mês.
- **Juros:** os previstos na convenção (muitas convenções antigas preveem 1% ao mês). **Se a convenção não fixar**, aplica-se a **taxa legal**: Selic menos IPCA, divulgada mensalmente pelo Banco Central (Lei 14.905/2024, que alterou os arts. 389 e 406 do Código Civil). **[conferir]** a cláusula da convenção na implantação.
- **Correção monetária:** pela convenção; sem previsão, IPCA (Lei 14.905/2024).
- **Cobrança judicial:** a cota aprovada em convenção ou assembleia é título executivo extrajudicial (CPC, art. 784, X), o que permite execução e protesto. A decisão e a condução são do síndico com o advogado.
- **Desconto de multa ou juros em acordo:** só se a convenção ou a assembleia autorizar o síndico.

## Saída do script
1. Taxa de inadimplência do mês (valor emitido x valor recebido até hoje).
2. Faixas de atraso: até 30, 31–60, 61–90 e mais de 90 dias (quantidade de unidades e valor).
3. Por unidade: parcelas em aberto, principal, multa, juros, correção e total atualizado.

## Uso do resultado
- O relatório por unidade é **interno** (síndico, conselho, administradora, advogado).
- Na prestação de contas aos condôminos, a lista de unidades em atraso pode constar do balancete, sem comentários e sem nome de pessoa. **[conferir]** com o advogado o entendimento do tribunal do estado.
