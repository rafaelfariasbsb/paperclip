#!/usr/bin/env python3
"""Inadimplencia por faixa de atraso e debito atualizado por unidade.
Uso: python3 inadimplencia.py <pasta> [--hoje AAAA-MM-DD] [--multa 2] [--juros-mensal 1] [--sem-correcao]
- Multa: aplicada uma vez por parcela (Codigo Civil, art. 1.336, par. 1o: ate 2%).
- Juros simples pro rata dia: --juros-mensal (taxa da convencao) ou, sem ele, a coluna juros_pct
  de indices.csv do mes de cada dia (taxa legal, Lei 14.905/2024).
- Correcao: IPCA por mes cheio de atraso.
- Correcao: IPCA de indices.csv (ipca_pct), salvo --sem-correcao.
Relatorio INTERNO: nao divulgar a lista por unidade em comunicado geral.
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def meses_entre(d1, d2):
    """Meses AAAA-MM depois do mes de d1 ate o mes anterior a d2 (meses cheios de atraso)."""
    y, m = d1.year, d1.month
    out = []
    while True:
        m += 1
        if m == 13:
            y, m = y + 1, 1
        if (y, m) >= (d2.year, d2.month):
            return out
        out.append(f"{y:04d}-{m:02d}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--multa", type=float, default=2.0)
    ap.add_argument("--juros-mensal", type=float)
    ap.add_argument("--sem-correcao", action="store_true")
    a = ap.parse_args()
    if a.multa > 2:
        print("ATENCAO: multa acima de 2% contraria o art. 1.336, par. 1o, do Codigo Civil. Usando 2%.")
        a.multa = 2.0
    hoje = dt(a.hoje)
    cob = exigir(a.pasta, "cobrancas.csv")
    idx = {r["mes"]: r for r in (ler(a.pasta, "indices.csv") or [])}
    if a.juros_mensal is None and not idx:
        print("Sem --juros-mensal e sem indices.csv: informe a taxa da convencao ou o arquivo de indices. Calculando sem juros.\n")
    vencidas = [r for r in cob if dt(r["vencimento"]) < hoje]
    ref = max((r["vencimento"][:7] for r in vencidas), default=None)
    print(f"# Inadimplencia em {hoje}\n")
    if ref:
        emit = sum(num(r["valor"]) for r in vencidas if r["vencimento"][:7] == ref)
        aberto_ref = sum(max(num(r["valor"]) - num(r["valor_pago"]), 0) for r in vencidas if r["vencimento"][:7] == ref)
        print(f"Taxa de inadimplencia dos boletos vencidos em {ref}: {aberto_ref / emit * 100 if emit else 0:.1f}% ({brl(aberto_ref)} de {brl(emit)})\n")
    faixas = {"ate 30": [0, 0.0, set()], "31-60": [0, 0.0, set()], "61-90": [0, 0.0, set()], "mais de 90": [0, 0.0, set()]}
    por_unidade = defaultdict(list)
    for r in vencidas:
        aberto = num(r["valor"]) - num(r["valor_pago"])
        if aberto <= 0.009:
            continue
        venc = dt(r["vencimento"]); dias = (hoje - venc).days
        f = "ate 30" if dias <= 30 else "31-60" if dias <= 60 else "61-90" if dias <= 90 else "mais de 90"
        faixas[f][0] += 1; faixas[f][1] += aberto; faixas[f][2].add(r["unidade"])
        meses = meses_entre(venc, hoje)
        fator = 1.0
        if not a.sem_correcao:
            for mm in meses:
                if mm in idx:
                    fator *= 1 + num(idx[mm]["ipca_pct"]) / 100
        corrigido = aberto * fator
        multa = corrigido * a.multa / 100
        if a.juros_mensal is not None:
            juros = corrigido * a.juros_mensal / 100 * dias / 30
        else:
            taxa, d = 0.0, venc
            while d < hoje:  # pro rata dia, com a taxa do mes de cada dia
                d += timedelta(days=1)
                mm = d.strftime("%Y-%m")
                if mm in idx:
                    prox = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
                    taxa += num(idx[mm]["juros_pct"]) / (prox - d.replace(day=1)).days
            juros = corrigido * taxa / 100
        por_unidade[r["unidade"]].append((r["competencia"], r["tipo"], dias, aberto, corrigido - aberto, multa, juros))
    print("## Faixas de atraso\n\n| Faixa (dias) | Parcelas | Unidades | Valor original |\n|---|---|---|---|")
    for f, (q, v, u) in faixas.items():
        print(f"| {f} | {q} | {len(u)} | {brl(v)} |")
    print(f"\nUnidades com debito: {len(por_unidade)}\n")
    print("## Debito atualizado por unidade (INTERNO)\n")
    print("| Unidade | Competencias | Maior atraso (dias) | Principal | Correcao | Multa | Juros | Total |\n|---|---|---|---|---|---|---|---|")
    tot = 0.0
    linhas = []
    for u, ps in por_unidade.items():
        p = sum(x[3] for x in ps); c = sum(x[4] for x in ps); m = sum(x[5] for x in ps); j = sum(x[6] for x in ps)
        linhas.append((max(x[2] for x in ps), u, len({x[0] for x in ps}), p, c, m, j, p + c + m + j))
    for d, u, q, p, c, m, j, t in sorted(linhas, reverse=True):
        tot += t
        print(f"| {u} | {q} | {d} | {brl(p)} | {brl(c)} | {brl(m)} | {brl(j)} | {brl(t)} |")
    print(f"\nTotal atualizado a receber: {brl(tot)}")
    regra = f"juros {a.juros_mensal}% a.m. (convencao)" if a.juros_mensal is not None else "juros pela taxa de indices.csv (taxa legal)"
    print(f"\nCriterio: multa {a.multa}% uma vez por parcela; {regra}; correcao {'desligada' if a.sem_correcao else 'IPCA de indices.csv'}.")
    print("> Proxima etapa por unidade: skill regua-cobranca-respeitosa. Nada e enviado sem aprovacao do sindico.")


if __name__ == "__main__":
    main()
