---
name: relatorios-para-o-sindico
description: "Formato dos resumos diário, semanal e mensal para o síndico: curto, priorizado, com fatos separados de sugestões."
---

# Relatórios para o síndico

## Resumo diário (no máximo 10 linhas)
```
🔴 Urgente: <segurança, vazamento, elevador parado, documento vencido>
🟡 Aprovações pendentes: <n> (mais antiga: <há quantas horas>)
💰 Caixa: saldo conta ordinária R$ <valor> · divergências na conciliação: <n>
🛠️ Manutenção: <n> atrasadas · próxima obrigatória: <atividade> em <data>
📄 Prazos: <documento> vence em <n> dias
📨 Chamados: <n> abertos, <n> fora do prazo
```

## Relatório semanal
1. Indicadores da semana comparados à anterior: inadimplência (% e R$), caixa, manutenções atrasadas, chamados fora do prazo, documentos a vencer em 60 dias.
2. As 5 ações mais importantes, com responsável e prazo.
3. Riscos (financeiros, legais, de segurança).
4. Aprovações paradas há mais de 48h.

## Pacote mensal
- Balancete e orçado x realizado `[CONSELHO]`.
- Inadimplência por faixa de atraso, sem identificar unidade no texto que vai para todos.
- Plano de manutenção: executado x previsto.
- Pauta sugerida para a reunião com o conselho.

## Indicadores de referência
| Indicador | Como calcular | Referência inicial |
|---|---|---|
| Inadimplência do mês | valor vencido e não pago / valor emitido no mês | meta da implantação (sugestão: até 5%) |
| Inadimplência acumulada | total em atraso / receita mensal | acompanhar tendência |
| Execução do orçamento | realizado / orçado por categoria | ±10% |
| Folha e encargos | total da folha / despesa total | acompanhar tendência |
| Manutenção em dia | atividades no prazo / atividades previstas | 100% das obrigatórias |
| Chamados no prazo | fechados no prazo / fechados | meta da implantação |

Referências de mercado (ex.: índices de inadimplência de administradoras) servem só como comparação, não como meta.

## Regras
- Primeiro o que exige decisão, depois o informativo.
- Todo número sai de um arquivo ou script. Cite qual.
- "Sugestão" sempre marcada como rascunho.
- Valores em R$ no formato brasileiro (R$ 1.234,56).
- Sem jargão: escreva para o síndico, não para o contador.
