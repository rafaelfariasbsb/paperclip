---
name: regua-cobranca-respeitosa
description: "Régua de cobrança extrajudicial em etapas, com modelos de mensagem respeitosa e as práticas proibidas (exposição, constrangimento, corte de serviço)."
---

# Régua de cobrança respeitosa

A cobrança é do condomínio contra a **unidade**. O objetivo é receber e manter a convivência. O CDC (art. 42) proíbe expor o devedor ao ridículo ou constrangê-lo; tribunais condenam condomínios que expõem devedores.

## Etapas (padrão; o síndico ajusta na implantação)
| Quando | Ação (sempre rascunho para o síndico aprovar) |
|---|---|
| D+3 | Lembrete simples: "consta em aberto a cota de <mês>; se já pagou, desconsidere". Segunda via. |
| D+15 | Aviso formal com o valor atualizado e a memória de cálculo. |
| D+30 | Convite para conversar e proposta de acordo dentro do que a convenção ou a assembleia permitem. |
| D+60 | Notificação com prazo, informando os próximos passos legais (protesto ou cobrança judicial). |
| D+90 | Dossiê para o advogado: boletos, cálculo, ata ou convenção que aprova a cota, histórico de contatos. |

## Modelos
- Tom: neutro, educado, sem adjetivos, sem ameaça.
- Sempre: valor, competência, como pagar, como falar com a administração, "se já pagou, desconsidere".
- Nunca: menção a vizinhos, à situação pessoal do morador ou a consequências que não sejam legais.
- Endereçado ao responsável pela unidade, pelo canal que o síndico escolher. O agente não envia.

## Proibido sugerir ou redigir
- Lista de devedores em elevador, mural, portaria, grupo de WhatsApp ou circular com unidade identificada.
- Corte de água, gás ou energia da unidade.
- Proibição de uso de elevador, garagem ou áreas comuns essenciais.
- Cobrança em horário ou forma que constranja, ou contato com terceiros (empregador, parentes).
- Restrição de voto em assembleia além do que a lei e a convenção preveem (art. 1.335, III: o condômino precisa estar quite para votar). **[conferir]** a convenção.

## Acordos
- Proposta com entrada, número de parcelas e o que acontece se uma parcela atrasar.
- Desconto de multa ou juros só com autorização da convenção ou da assembleia.
- Acordo assinado pelo síndico; o agente acompanha as parcelas na rotina mensal.
