#!/usr/bin/env python3
"""Plano de manutencao (NBR 5674): atividades atrasadas, sem registro e proximas.
Uso: python3 manutencao.py <pasta> [--hoje AAAA-MM-DD] [--janela 30]
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--janela", type=int, default=30)
    a = ap.parse_args()
    hoje = dt(a.hoje)
    plano = exigir(a.pasta, "plano_manutencao.csv")
    atras, prox, sem = [], [], []
    for r in plano:
        per = int(num(r["periodicidade_dias"]) or 0)
        laudo = " [LAUDO/ART]" if r["exige_laudo"].upper() == "S" else ""
        if not r["ultima_execucao"]:
            sem.append((r, laudo)); continue
        proxima = dt(r["ultima_execucao"]) + timedelta(days=per)
        dias = (proxima - hoje).days
        if dias < 0:
            atras.append((-dias, r, proxima, laudo))
        elif dias <= a.janela:
            prox.append((dias, r, proxima, laudo))
    print(f"# Plano de manutencao em {hoje}\n\nAtividades no plano: {len(plano)}\n")
    print(f"## ATRASADAS ({len(atras)})\n\n| Sistema | Atividade | Deveria em | Atraso (dias) | Responsavel |\n|---|---|---|---|---|")
    for d, r, p, l in sorted(atras, key=lambda x: (x[3] == "", -x[0])):
        print(f"| {r['sistema']} | {r['atividade']}{l} | {p} | {d} | {r['responsavel']} |")
    print(f"\n## Sem registro de execucao ({len(sem)}): tratar como atrasadas ate o zelador informar a data\n")
    for r, l in sem:
        print(f"- {r['sistema']}: {r['atividade']}{l} ({r['responsavel']})")
    print(f"\n## Proximos {a.janela} dias ({len(prox)})\n\n| Data | Sistema | Atividade | Responsavel |\n|---|---|---|---|")
    for d, r, p, l in sorted(prox, key=lambda x: x[0]):
        print(f"| {p} | {r['sistema']} | {r['atividade']}{l} | {r['responsavel']} |")
    em_dia = len(plano) - len(atras) - len(sem)
    print(f"\nManutencao em dia: {em_dia}/{len(plano)} ({em_dia / len(plano) * 100 if plano else 0:.0f}%)")
    print("> Itens com [LAUDO/ART] exigem empresa ou profissional habilitado. O agente nao contrata nem libera equipamento.")


if __name__ == "__main__":
    main()
