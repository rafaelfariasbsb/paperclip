---
name: plano-manutencao-nbr5674
description: "Plano de manutenção preventiva pela ABNT NBR 5674: lista-base de sistemas e periodicidades, controle de atividades atrasadas e próximas, e registros que provam a execução."
---

# Plano de manutenção (NBR 5674)

`python3 scripts/manutencao.py "$CONDOMINIO_DADOS/entrada" --hoje AAAA-MM-DD --janela 30`

- Para cada linha de `plano_manutencao.csv`, calcula a próxima data (`ultima_execucao + periodicidade_dias`).
- Lista **atrasadas** (com dias de atraso) e as **próximas** dentro da janela, destacando as que exigem laudo ou ART.
- Linha sem `ultima_execucao` aparece como "sem registro": trate como atrasada até o zelador informar a data.

## Normas de referência
- **NBR 5674:** obriga o condomínio a ter um programa de manutenção com calendário, responsáveis, recursos e registros.
- **NBR 14037:** manual de uso, operação e manutenção entregue pela construtora. É a primeira fonte das periodicidades.
- **NBR 16747:** inspeção predial (vistoria geral periódica). Alguns municípios exigem autovistoria ou laudo periódico **[conferir]**.
- **NBR 17170:** prazos de garantia da edificação. Manutenção não feita pode fazer o condomínio perder a garantia da construtora.

## Lista-base (ajustar ao manual da construtora e à lei local)
| Sistema | Atividade | Periodicidade típica | Laudo/ART |
|---|---|---|---|
| Reservatórios de água | limpeza e desinfecção | 6 meses (exigência municipal em várias cidades) **[conferir]** | certificado da empresa |
| Água potável | análise de potabilidade | 6 meses, após a limpeza | laudo de laboratório |
| Elevadores | manutenção mensal; inspeção anual (RIA, onde exigido) **[conferir]** | 30 dias / 365 dias | relatório da conservadora |
| SPDA (para-raios) | inspeção e medição | 12 meses (NBR 5419; alguns municípios pedem laudo anual com ART) **[conferir]** | laudo com ART |
| Extintores | inspeção visual / recarga | 30 dias / 12 meses ou conforme etiqueta | empresa certificada |
| Hidrantes e mangueiras | inspeção / teste hidrostático | 6 meses / 12 meses | empresa habilitada |
| Iluminação de emergência e alarme | teste | 30 dias | registro interno |
| AVCB / CLCB | renovação | conforme o certificado (estadual) **[conferir]** | Corpo de Bombeiros |
| Bombas de recalque | revezamento e verificação | 7 dias / 6 meses | registro / técnico |
| Gerador | teste em carga | 30 dias | registro / técnico |
| Gás central | inspeção da rede | 12 meses **[conferir]** | empresa habilitada |
| Portões e interfones | manutenção preventiva | 30–90 dias | contrato |
| Dedetização e desratização | aplicação | 6 meses **[conferir]** | certificado |
| Piscina | tratamento / análise da água | diário / mensal **[conferir]** | registro / laudo |
| Fachada e impermeabilização | inspeção visual | 12 meses | engenheiro, se houver dano |
| Instalações elétricas | inspeção do quadro geral | 12 meses | eletricista habilitado |

## Registros (prova de execução)
Para cada atividade feita, o zelador atualiza `ultima_execucao` e guarda nota, certificado, laudo ou ordem de serviço. Sem registro, para o seguro e para a Justiça, a manutenção não existiu.
