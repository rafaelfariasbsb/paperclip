---
name: lgpd-condominio
description: "Regras de proteção de dados no condomínio: minimização (número da unidade), câmeras, controle de acesso e biometria, pedidos de titulares e contratos com fornecedores."
---

# LGPD no condomínio

O condomínio trata dados de moradores, funcionários, visitantes e prestadores e está sujeito à LGPD, com as regras simplificadas para agentes de pequeno porte (Resolução CD/ANPD nº 2/2022). O síndico representa o controlador.

## Regras deste pacote
- **Minimização:** os agentes trabalham com o código da unidade. Nome, CPF, RG, telefone, e-mail, placa, imagem e biometria **não** entram na pasta de dados.
- O `validar_dados.py` avisa se um cabeçalho parece dado pessoal.
- Relatórios internos (inadimplência, ocorrências) não vão para comunicados gerais.

## Câmeras (CFTV)
- Avisos visíveis de área monitorada.
- Câmeras só em áreas comuns, sem enquadrar o interior de unidades.
- Prazo de guarda definido (ex.: 30 dias) e acesso restrito (síndico e quem ele designar), com registro de quem viu e por quê.
- Imagens só são entregues a autoridade ou mediante pedido formal analisado pelo síndico.

## Controle de acesso e biometria
- Biometria e reconhecimento facial são **dados sensíveis**. Exigem base legal adequada, transparência e segurança reforçada.
- Ofereça meio alternativo (cartão, tag, senha) a quem não quiser a biometria **[conferir]** com o advogado.
- Apagar dados de quem se mudou ou de prestador que encerrou o serviço.
- Contrato com a empresa do sistema com cláusulas de proteção de dados (operador).

## Pedidos de titulares
Morador, funcionário ou visitante pode pedir acesso, correção ou exclusão. O agente registra e prepara o rascunho de resposta; o síndico responde. Prazo: o mais breve possível **[conferir]** prazo regulamentar vigente.

## Fornecedores
Administradora, portaria remota, sistema de boletos e de acesso são operadores: o contrato deve ter cláusula de proteção de dados. O agente aponta contratos sem essa cláusula na revisão anual.
