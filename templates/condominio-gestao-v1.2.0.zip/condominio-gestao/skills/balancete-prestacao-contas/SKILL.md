---
name: balancete-prestacao-contas
description: "Balancete mensal por conta e categoria, orçado x realizado e pacote de prestação de contas para o conselho fiscal e a assembleia."
---

# Balancete e prestação de contas

`python3 scripts/balancete.py "$CONDOMINIO_DADOS/entrada" --mes AAAA-MM`

- Soma receitas e despesas do mês por **conta** (ordinária, fundo de reserva, fundo de obras) e por **categoria**.
- Compara a despesa de cada categoria com `orcamento.csv` e marca desvio acima de 10%.
- Lista lançamentos **sem documento** (coluna `documento` vazia): cada um precisa de comprovante antes de ir ao conselho.
- Mostra o saldo final por conta, se `saldos.csv` existir.

## Base legal
- O síndico presta contas à assembleia anualmente e quando exigidas (Código Civil, art. 1.348, VIII).
- O conselho fiscal, se houver, dá parecer sobre as contas (art. 1.356).
- Qualquer condômino pode pedir para ver as contas e os comprovantes.

## Pacote `[CONSELHO]` do mês
1. Balancete por conta e categoria.
2. Orçado x realizado com explicação de cada desvio acima de 10%.
3. Lista de lançamentos sem comprovante.
4. Conciliação bancária do mês (skill `conciliacao-bancaria`).
5. Inadimplência por faixa de atraso (skill `inadimplencia-calculo-debito`).
6. Movimentação do fundo de reserva, com a aprovação que autorizou cada saída.

## Boas práticas
- Fundo de reserva e fundo de obras em conta separada da ordinária.
- Pasta mensal com notas, recibos, extratos e contratos, numerados como na coluna `documento`.
- Nada de "outros" com valor relevante: abra a categoria.
