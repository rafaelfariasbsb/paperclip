#!/usr/bin/env python3
"""Balancete mensal por conta e categoria, orcado x realizado e lancamentos sem documento.
Uso: python3 balancete.py <pasta> [--mes AAAA-MM] [--desvio 10]
Sem --mes, usa o mes anterior ao de hoje.
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--mes")
    ap.add_argument("--desvio", type=float, default=10.0)
    a = ap.parse_args()
    if not a.mes:
        a.mes = (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
    lanc = [r for r in exigir(a.pasta, "lancamentos.csv") if r["data"].startswith(a.mes)]
    print(f"# Balancete {a.mes}\n")
    if not lanc:
        print("Nenhum lancamento no mes. Confira se o arquivo foi atualizado.")
        return
    por_conta = defaultdict(lambda: [0.0, 0.0])
    desp_cat, rec_cat = defaultdict(float), defaultdict(float)
    sem_doc = []
    for r in lanc:
        v = num(r["valor"]); c = r["conta"].upper() or "ORDINARIA"
        por_conta[c][0 if v >= 0 else 1] += v
        if c == "ORDINARIA":
            (rec_cat if v >= 0 else desp_cat)[r["categoria"]] += v
        if not r.get("documento"):
            sem_doc.append(r)
    print("## Resumo por conta\n\n| Conta | Receitas | Despesas | Resultado do mes |\n|---|---|---|---|")
    for c, (rec, desp) in sorted(por_conta.items()):
        print(f"| {c} | {brl(rec)} | {brl(desp)} | {brl(rec + desp)} |")
    print("\n## Receitas da conta ordinaria\n\n| Categoria | Valor |\n|---|---|")
    for k, v in sorted(rec_cat.items(), key=lambda x: -x[1]):
        print(f"| {k} | {brl(v)} |")
    orc = {r["categoria"]: num(r["valor_mensal"]) for r in (ler(a.pasta, "orcamento.csv") or [])}
    print("\n## Despesas da conta ordinaria: orcado x realizado\n\n| Categoria | Orcado | Realizado | Desvio | Situacao |\n|---|---|---|---|---|")
    total_o = total_r = 0.0
    for k in sorted(set(desp_cat) | set(orc)):
        real = -desp_cat.get(k, 0.0); o = orc.get(k)
        total_r += real; total_o += o or 0
        if o:
            d = (real - o) / o * 100
            sit = "ACIMA" if d > a.desvio else ("abaixo" if d < -a.desvio else "ok")
            print(f"| {k} | {brl(o)} | {brl(real)} | {d:+.1f}% | {sit} |")
        else:
            print(f"| {k} | sem orcamento | {brl(real)} | - | SEM PREVISAO |")
    print(f"| **Total** | {brl(total_o)} | {brl(total_r)} | {((total_r - total_o) / total_o * 100 if total_o else 0):+.1f}% | |")
    if not orc:
        print("\n(orcamento.csv ausente: sem comparacao com o previsto)")
    saldos = ler(a.pasta, "saldos.csv")
    if saldos:
        ult = {}
        for r in saldos:
            if r["data"][:7] <= a.mes and (r["conta"] not in ult or r["data"] > ult[r["conta"]][0]):
                ult[r["conta"]] = (r["data"], num(r["saldo"]))
        print("\n## Saldos por conta\n\n| Conta | Data | Saldo |\n|---|---|---|")
        for c, (d, s) in sorted(ult.items()):
            print(f"| {c} | {d} | {brl(s)} |")
    print(f"\n## Lancamentos sem documento ({len(sem_doc)})\n")
    for r in sem_doc:
        print(f"- {r['data']} | {r['conta']} | {r['categoria']} | {r['descricao']} | {brl(num(r['valor']))}")
    if not sem_doc:
        print("Nenhum.")
    print("\n> Pacote para o conselho fiscal. O agente nao paga nem altera lancamentos.")


if __name__ == "__main__":
    main()
