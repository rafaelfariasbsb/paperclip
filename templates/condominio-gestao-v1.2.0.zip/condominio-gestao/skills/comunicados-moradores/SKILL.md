---
name: comunicados-moradores
description: "Como redigir circulares, avisos de manutenção e respostas aos moradores: claros, neutros, sem expor ninguém."
---

# Comunicados aos moradores

## Estrutura de um aviso
1. **Título curto** (o que vai acontecer).
2. **Quando:** data, horário de início e de fim previstos.
3. **Impacto:** o que para (água, elevador, garagem) e o que o morador deve fazer.
4. **Contato** da administração para dúvidas.

## Circular do mês
- Manutenções programadas do mês seguinte (da rotina de manutenção).
- Lembretes do regimento (um tema por mês: barulho, pets, lixo, vagas, obras).
- Resultado de assembleia e próximos passos.
- Sem números de inadimplência por unidade, sem citar infratores, sem tom de bronca.

## Respostas a moradores
- Agradeça o contato, diga o que foi verificado, o que será feito e quando.
- Se não houver solução imediata, diga a próxima data de retorno.
- Assunto que envolve outro morador: fale da regra, não da pessoa.

## Tom
Português simples, frases curtas, sem jargão jurídico. Nada de caixa alta, ameaça ou ironia. Todo comunicado é rascunho: quem aprova e envia é o síndico.
