---
name: documentos-laudos-seguro
description: "Planilha-mestre de documentos, laudos, seguro obrigatório, certidões e contratos do condomínio, com alertas de vencimento em 60/30/7 dias."
---

# Documentos, laudos e seguro

`python3 scripts/prazos.py "$CONDOMINIO_DADOS/entrada" --hoje AAAA-MM-DD --alertas 60,30,7`

- Lê `documentos.csv` (validade) e `contratos.csv` (fim do contrato e validade das certidões do prestador).
- Classifica: **VENCIDO**, vence em até 7, 30 ou 60 dias, ou em dia.

## Lista-base da planilha (ajustar na implantação)
| Documento | Órgão / quem emite | Observação |
|---|---|---|
| AVCB ou CLCB | Corpo de Bombeiros (estadual) | validade definida no certificado **[conferir]** |
| Seguro obrigatório da edificação | seguradora | **obrigatório** contra incêndio ou destruição, total ou parcial (Código Civil, art. 1.346); contratação é dever do síndico (art. 1.348, IX). Responsabilidade civil é recomendada |
| Certificado de limpeza dos reservatórios | empresa contratada | semestral em várias cidades **[conferir]** |
| Laudo de potabilidade da água | laboratório | após cada limpeza |
| Laudo do SPDA com ART | engenheiro | anual em vários municípios **[conferir]** |
| RIA dos elevadores | conservadora | anual onde a lei municipal exige **[conferir]** |
| Certificado de dedetização | empresa licenciada | semestral **[conferir]** |
| Inspeção ou autovistoria predial | engenheiro | exigência municipal em algumas cidades **[conferir]** |
| Ata de eleição do síndico | assembleia | o mandato vence: preparar a assembleia com antecedência |
| Cartão CNPJ e certidões do condomínio | Receita, PGFN, Caixa, TST | necessárias para banco, contratos e financiamentos |
| Alvará ou licenças de equipamentos (gerador, piscina, gás) | prefeitura / órgão estadual | **[conferir]** |

## Contratos
Para cada contrato: fim, índice e mês de reajuste, aviso prévio para não renovar e validade das certidões do prestador. Em serviço terceirizado com mão de obra (portaria, limpeza, segurança), certidões vencidas da contratada são risco trabalhista para o condomínio (responsabilidade subsidiária, Súmula 331 do TST).

## Alertas
Cada item vira tarefa `[SINDICO]` com: o que vence, a data, o que precisa ser contratado ou renovado, quanto tempo a renovação costuma levar e se o seguro pode recusar sinistro com o documento vencido.
