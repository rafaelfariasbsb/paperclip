#!/usr/bin/env python3
"""Prazos de documentos, laudos, seguro, contratos e certidoes de prestadores.
Uso: python3 prazos.py <pasta> [--hoje AAAA-MM-DD] [--alertas 60,30,7]
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--alertas", default="60,30,7")
    a = ap.parse_args()
    hoje = dt(a.hoje); lim = sorted(int(x) for x in a.alertas.split(","))
    itens = []
    docs = ler(a.pasta, "documentos.csv"); contr = ler(a.pasta, "contratos.csv")
    if docs is None and contr is None:
        print("FALTAM documentos.csv e contratos.csv. Rotina nao executada; nao invente dados."); sys.exit(2)
    for r in docs or []:
        itens.append((r["validade"], r["documento"], r["orgao"], r["responsavel"]))
    for r in contr or []:
        itens.append((r["fim"], f"Contrato: {r['objeto']}", r["fornecedor"], f"reajuste {r['indice_reajuste']}"))
        itens.append((r["certidoes_validade"], f"Certidoes do prestador: {r['objeto']}", r["fornecedor"], "pedir certidoes atualizadas"))
    print(f"# Prazos em {hoje}\n\n| Situacao | Item | Orgao/fornecedor | Validade | Dias | Obs. |\n|---|---|---|---|---|---|")
    cont = defaultdict(int)
    for val, item, org, obs in sorted(itens, key=lambda x: x[0] or "0000"):
        if not val:
            sit, dias = "SEM DATA", "-"
        else:
            d = (dt(val) - hoje).days; dias = d
            sit = "VENCIDO" if d < 0 else next((f"vence em ate {x} dias" for x in lim if d <= x), "em dia")
        cont[sit] += 1
        if sit != "em dia":
            print(f"| {sit} | {item} | {org} | {val or '-'} | {dias} | {obs} |")
    print("\nResumo: " + ", ".join(f"{k}: {v}" for k, v in sorted(cont.items())))
    print("> Cada item vencido ou a vencer vira tarefa [SINDICO]. O agente nao contrata nem protocola.")


if __name__ == "__main__":
    main()
