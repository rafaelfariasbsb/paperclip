---
name: conciliacao-bancaria
description: "Conciliação do extrato bancário com os lançamentos do condomínio: saídas sem lançamento, lançamentos sem extrato, duplicidades e tarifas."
---

# Conciliação bancária

`python3 scripts/conciliar.py "$CONDOMINIO_DADOS/entrada" --dias 7 --tolerancia 0.05`

- Casa cada linha do extrato com um lançamento da mesma conta, mesmo valor (com tolerância) e data próxima (até `--dias`).
- Lista:
  - **saídas no banco sem lançamento** (o mais grave: dinheiro saiu sem registro);
  - **lançamentos sem movimento no banco** (pagamento registrado e não feito, ou feito em outra conta);
  - **possíveis duplicidades** (mesmo valor e descrição parecida na mesma semana);
  - **tarifas bancárias** do período, para comparar com o pacote contratado.
- Cada saída sem lançamento vira tarefa `[SINDICO]` urgente.

O agente nunca acessa o internet banking: o extrato chega como arquivo exportado pelo síndico ou pela administradora.
