#!/usr/bin/env python3
"""Conciliacao bancaria: extrato x lancamentos (mesma conta, mesmo valor, data proxima).
Uso: python3 conciliar.py <pasta> [--de AAAA-MM-DD] [--ate AAAA-MM-DD] [--dias 7] [--tolerancia 0.05]
Sem --de, usa os ultimos 30 dias.
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None
import re


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--de")
    ap.add_argument("--ate", default=date.today().isoformat())
    ap.add_argument("--dias", type=int, default=7)
    ap.add_argument("--tolerancia", type=float, default=0.05)
    a = ap.parse_args()
    ate = dt(a.ate); de = dt(a.de) if a.de else ate - timedelta(days=30)
    ext = [r for r in exigir(a.pasta, "extrato_bancario.csv") if de <= dt(r["data"]) <= ate]
    lanc = [r for r in exigir(a.pasta, "lancamentos.csv") if de - timedelta(days=a.dias) <= dt(r["data"]) <= ate + timedelta(days=a.dias)]
    usados = set()
    sem_lanc, tarifas = [], []
    for e in ext:
        v = num(e["valor"])
        if re.search(r"tarifa|cesta|pacote de servi", e["descricao"], re.I):
            tarifas.append(e)
        melhor = None
        for i, l in enumerate(lanc):
            if i in usados or l["conta"].upper() != e["conta"].upper():
                continue
            if abs(num(l["valor"]) - v) <= a.tolerancia:
                gap = abs((dt(l["data"]) - dt(e["data"])).days)
                if gap <= a.dias and (melhor is None or gap < melhor[1]):
                    melhor = (i, gap)
        if melhor:
            usados.add(melhor[0])
        else:
            sem_lanc.append(e)
    sem_ext = [l for i, l in enumerate(lanc) if i not in usados and de <= dt(l["data"]) <= ate]
    vistos, dup = {}, []
    for l in lanc:
        k = (l["conta"].upper(), round(num(l["valor"]), 2), re.sub(r"\W+", " ", l["descricao"].lower())[:20])
        if k in vistos and abs((dt(l["data"]) - dt(vistos[k]["data"])).days) <= 7:
            dup.append((vistos[k], l))
        vistos[k] = l
    print(f"# Conciliacao bancaria {de} a {ate}\n")
    print(f"Linhas do extrato: {len(ext)} · conciliadas: {len(ext) - len(sem_lanc)}\n")
    saidas = [e for e in sem_lanc if num(e["valor"]) < 0 and e not in tarifas]
    print(f"## URGENTE: saidas no banco sem lancamento ({len(saidas)})\n")
    for e in saidas:
        print(f"- {e['data']} | {e['conta']} | {e['descricao']} | {brl(num(e['valor']))}")
    if not saidas:
        print("Nenhuma.")
    ent = [e for e in sem_lanc if num(e["valor"]) >= 0]
    print(f"\n## Entradas no banco sem lancamento ({len(ent)})\n")
    for e in ent:
        print(f"- {e['data']} | {e['conta']} | {e['descricao']} | {brl(num(e['valor']))}")
    print(f"\n## Lancamentos sem movimento no banco ({len(sem_ext)})\n")
    for l in sem_ext:
        print(f"- {l['data']} | {l['conta']} | {l['categoria']} | {l['descricao']} | {brl(num(l['valor']))}")
    print(f"\n## Possiveis duplicidades ({len(dup)})\n")
    for x, y in dup:
        print(f"- {x['data']} e {y['data']} | {y['descricao']} | {brl(num(y['valor']))}")
    print(f"\n## Tarifas bancarias no periodo: {brl(sum(num(t['valor']) for t in tarifas))} ({len(tarifas)} lancamentos)")
    print("\n> O agente nunca acessa o internet banking nem paga. Cada saida sem lancamento vira tarefa [SINDICO].")


if __name__ == "__main__":
    main()
