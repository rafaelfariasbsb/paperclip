---
name: contrato-de-dados
description: "Formato dos arquivos de entrada (lançamentos, extrato, boletos, plano de manutenção, documentos etc.), o arquivo config-condominio.md e o script de validação. Use antes de qualquer cálculo."
---

# Contrato de dados

Todos os agentes leem a pasta da variável `CONDOMINIO_DADOS`:

```
$CONDOMINIO_DADOS/
├── config-condominio.md   # configuração, criada pelo agente de implantação
├── mapas/                 # mapas de colunas de cada exportação (skill integracoes-sistemas)
├── whatsapp/              # só se o WhatsApp for ativado: contatos e conversas (DADO PESSOAL, retenção 90 dias)
├── entrada/               # planilhas e exportações (atualizadas pelo síndico, zelador ou administradora)
└── saida/                 # relatórios e rascunhos gerados pelos agentes
```

## Formato
CSV em UTF-8, com cabeçalho na primeira linha. O separador preferido é `;`, mas os scripts também aceitam `,`. Números podem vir com vírgula decimal (`1.234,56`). Datas no formato `AAAA-MM-DD`; meses no formato `AAAA-MM`. **Unidades sempre pelo código** (ex.: `A-101`), nunca pelo nome do morador.

| Arquivo | Obrigatório | Colunas |
|---|---|---|
| unidades.csv | sim | unidade; bloco; fracao_ideal; tipo (RESIDENCIAL/COMERCIAL/GARAGEM) |
| lancamentos.csv | sim | data; conta (ORDINARIA/FUNDO_RESERVA/FUNDO_OBRAS); categoria; descricao; valor (receita positiva, despesa negativa); documento |
| cobrancas.csv | sim | unidade; competencia; tipo (ORDINARIA/EXTRA/FUNDO_RESERVA); vencimento; valor; pago_em; valor_pago |
| orcamento.csv | não | categoria; valor_mensal |
| extrato_bancario.csv | não | data; conta; descricao; valor |
| saldos.csv | não | data; conta; saldo |
| plano_manutencao.csv | não | sistema; atividade; periodicidade_dias; ultima_execucao; responsavel; exige_laudo (S/N) |
| documentos.csv | não | documento; orgao; numero; validade; responsavel |
| contratos.csv | não | fornecedor; objeto; valor_mensal; fim; indice_reajuste; certidoes_validade |
| cotacoes.csv | não | item; fornecedor; valor; prazo_dias; garantia_meses; documentos_ok (S/N); observacao |
| votos.csv | não | item; unidade; voto (SIM/NAO/ABSTENCAO); procuracao (S/N) |
| ocorrencias.csv | não | id; abertura; unidade; tipo; descricao; status (ABERTA/ANDAMENTO/FECHADA); fechamento |
| consumo.csv | não | mes; tipo (AGUA/ENERGIA/GAS); quantidade; valor |
| indices.csv | não | mes; ipca_pct; juros_pct (taxa de juros do mês, conforme a convenção ou a taxa legal) |

Se faltar um arquivo opcional, a rotina que depende dele avisa e não roda. **Nunca invente dado.**

## Validação
`python3 scripts/validar_dados.py "$CONDOMINIO_DADOS/entrada"` gera um relatório, avisa se encontrar coluna com cara de dado pessoal (nome, CPF, telefone, e-mail, placa) e devolve código 1 se faltar arquivo obrigatório.

## Modelo do config-condominio.md
```
# Configuração do condomínio
- Nome:                                   Cidade/UF:
- Blocos / unidades:                      Área comercial: sim/não
- Síndico: morador/profissional           Mandato: AAAA-MM-DD a AAAA-MM-DD
- Administradora / contador / advogado:
- Funcionários próprios:                  Terceirizados:
- Rateio: fração ideal/igualitário (cláusula)
- Vencimento da cota: dia                 Banco:            Conta do fundo de reserva separada: sim/não
- Multa por atraso: 2%                    Juros: 1% a.m. (convenção) | taxa legal (Lei 14.905/2024)
- Correção monetária: IPCA                Fundo de reserva: <n>% da cota (cláusula)
- Assembleia eletrônica: permitida/vedada pela convenção    Antecedência do edital: <n> dias
- Assembleia ordinária: mês habitual
- Teto de gasto sem 3 orçamentos (R$):    Teto sem consultar conselho (R$):
- Meta de inadimplência: 5%               Prazo de chamados: 3 dias úteis
- Régua de cobrança: lembrete D+3, aviso D+15, proposta de acordo D+30, advogado D+90
- Equipamentos: elevadores/gerador/bombas/piscina/gás central/portões/CFTV/biometria/SPDA
- Conselho acessa o Paperclip: sim/não
- WhatsApp: desligado | oficial | nao_oficial (termo aceito em AAAA-MM-DD)   Telefone da portaria para urgências:
```

## De onde vêm os arquivos
Cada sistema exporta com nomes de coluna diferentes. Use a skill `integracoes-sistemas`: o extrato do banco em OFX vira `extrato_bancario.csv` com `ofx_para_csv.py`, e qualquer outra exportação é convertida com `converter_planilha.py` e um mapa de colunas guardado em `$CONDOMINIO_DADOS/mapas/`.
