#!/usr/bin/env python3
"""Confere se os arquivos de entrada seguem o contrato de dados do template de condominio.
Tambem avisa se algum cabecalho parece dado pessoal (LGPD: use so o codigo da unidade).
Uso: python3 validar_dados.py <pasta_de_dados>
Codigo de saida 1 se faltar arquivo obrigatorio.
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None

CONTRATO = {
    "unidades.csv": (True, ["unidade", "bloco", "fracao_ideal", "tipo"], "todos"),
    "lancamentos.csv": (True, ["data", "conta", "categoria", "descricao", "valor", "documento"], "financeiro"),
    "cobrancas.csv": (True, ["unidade", "competencia", "tipo", "vencimento", "valor", "pago_em", "valor_pago"], "cobranca, financeiro"),
    "orcamento.csv": (False, ["categoria", "valor_mensal"], "financeiro"),
    "extrato_bancario.csv": (False, ["data", "conta", "descricao", "valor"], "financeiro"),
    "saldos.csv": (False, ["data", "conta", "saldo"], "financeiro"),
    "plano_manutencao.csv": (False, ["sistema", "atividade", "periodicidade_dias", "ultima_execucao", "responsavel", "exige_laudo"], "manutencao"),
    "documentos.csv": (False, ["documento", "orgao", "numero", "validade", "responsavel"], "conformidade"),
    "contratos.csv": (False, ["fornecedor", "objeto", "valor_mensal", "fim", "indice_reajuste", "certidoes_validade"], "conformidade"),
    "cotacoes.csv": (False, ["item", "fornecedor", "valor", "prazo_dias", "garantia_meses", "documentos_ok", "observacao"], "manutencao"),
    "votos.csv": (False, ["item", "unidade", "voto", "procuracao"], "assembleias"),
    "ocorrencias.csv": (False, ["id", "abertura", "unidade", "tipo", "descricao", "status", "fechamento"], "atendimento"),
    "consumo.csv": (False, ["mes", "tipo", "quantidade", "valor"], "manutencao"),
    "indices.csv": (False, ["mes", "ipca_pct", "juros_pct"], "cobranca"),
}
PESSOAIS = ("nome", "cpf", "rg", "telefone", "celular", "whatsapp", "email", "mail", "placa", "foto", "biometria", "nascimento")


def main():
    pasta = sys.argv[1] if len(sys.argv) > 1 else "."
    bloqueado = False
    alertas = []
    print(f"# Validacao do contrato de dados\n\nPasta: `{pasta}`\n")
    print("| Arquivo | Situacao | Linhas | Usado por | Observacao |\n|---|---|---|---|---|")
    for nome, (obrig, cols, uso) in CONTRATO.items():
        caminho = os.path.join(pasta, nome)
        if not os.path.exists(caminho):
            bloqueado |= obrig
            print(f"| {nome} | {'FALTA (obrigatorio)' if obrig else 'ausente (opcional)'} | - | {uso} | rotinas que dependem dele ficam desligadas |")
            continue
        with open(caminho, encoding="utf-8-sig", newline="") as f:
            amostra = f.read(4096); f.seek(0)
            sep = ";" if amostra.count(";") >= amostra.count(",") else ","
            leitor = csv.DictReader(f, delimiter=sep)
            cab = [c.strip().lower() for c in (leitor.fieldnames or [])]
            n = sum(1 for _ in leitor)
        falt = [c for c in cols if c not in cab]
        pess = [c for c in cab if c in PESSOAIS or any(tok in PESSOAIS for tok in c.replace("-", "_").split("_"))]
        if pess:
            alertas.append(f"{nome}: colunas {', '.join(pess)}")
        if falt and obrig:
            bloqueado = True
        obs = ("faltam: " + ", ".join(falt)) if falt else (f"separador '{sep}'" + (" (preferir ';')" if sep != ";" else ""))
        print(f"| {nome} | {'OK' if not falt else 'COLUNAS FALTANDO'} | {n} | {uso} | {obs} |")
    if alertas:
        print("\n## ALERTA LGPD\nEstes cabecalhos parecem dado pessoal. Troque pelo codigo da unidade e apague a coluna:")
        for a in alertas:
            print(f"- {a}")
    print("\nResultado:", "BLOQUEADO - corrigir arquivos obrigatorios" if bloqueado else "OK para rodar as rotinas")
    sys.exit(1 if bloqueado else 0)


if __name__ == "__main__":
    main()
