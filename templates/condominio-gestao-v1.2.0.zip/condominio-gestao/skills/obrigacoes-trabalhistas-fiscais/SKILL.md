---
name: obrigacoes-trabalhistas-fiscais
description: "Checklist mensal e anual das obrigações trabalhistas e fiscais do condomínio (eSocial, FGTS Digital, DCTFWeb, EFD-Reinf, retenções, RAIS/DIRF extintas) para conferência com a administradora ou o contador."
---

# Obrigações trabalhistas e fiscais

O condomínio edilício tem CNPJ e, mesmo sem fins lucrativos, cumpre obrigações acessórias e faz retenções. **Quem transmite é o contador ou a administradora.** O agente monta o checklist e pede confirmação; não acessa portais.

## Checklist mensal (datas típicas **[conferir]** o calendário oficial do ano)
| Obrigação | O que é | Prazo típico |
|---|---|---|
| eSocial | folha, admissões, desligamentos, afastamentos. **Sem funcionário, envio sem movimento** | até o dia 15 |
| FGTS Digital | guia do FGTS gerada a partir do eSocial | até o dia 20 |
| EFD-Reinf | retenções sobre serviços tomados (cessão de mão de obra: portaria, limpeza, segurança, manutenção) e pagamentos a terceiros | até o dia 15 |
| DCTFWeb e DARF | consolida eSocial e EFD-Reinf; gera a guia de INSS e retenções | guia até o dia 20 **[conferir]** |
| Retenções na fonte | INSS (11% sobre cessão de mão de obra), IR e PIS/COFINS/CSLL quando aplicáveis | conforme a nota |
| Folha e benefícios | salário até o 5º dia útil; vale-transporte; regras da convenção coletiva local **[conferir]** | mensal |

## Anual
- **DIRF:** extinta. As informações passaram para eSocial e EFD-Reinf.
- Informe de rendimentos aos funcionários e prestadores pessoa física.
- Férias, 13º (1ª parcela até 30/11, 2ª até 20/12) e dissídio da categoria.
- **Reforma tributária (LC 214/2025):** acompanhar com o contador como CBS e IBS afetam o condomínio e os serviços que ele contrata, na transição a partir de 2026–2027 **[conferir]**.

## Como o agente trabalha
- Dia 2: tarefa para a administradora ou o contador com o checklist do mês, pedindo "enviado em / protocolo".
- Dia 20: o que não foi confirmado vira tarefa `[SINDICO]`, porque atraso gera multa automática.
- Nunca pedir senha, certificado digital ou procuração eletrônica.
