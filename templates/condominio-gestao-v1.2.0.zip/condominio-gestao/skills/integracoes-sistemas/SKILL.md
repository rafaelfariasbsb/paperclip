---
name: integracoes-sistemas
description: "Sistemas e sites mais usados por condomínios e administradoras (Superlógica, Condomínio21, uCondo, TownSq e outros), bancos e apps de portaria: o que exportam, se têm API e como trazer os dados para o contrato de dados com segurança."
---

# Integrações com sistemas do condomínio

A regra é a mesma para qualquer sistema: **os dados chegam como arquivo na pasta `$CONDOMINIO_DADOS/entrada`**, no formato da skill `contrato-de-dados`. O agente não entra em site, não guarda senha e não usa a conta do síndico.

## Caminhos de integração, do mais simples ao mais avançado
1. **Exportação manual + conversor (padrão, funciona com tudo):** o síndico, o zelador ou a administradora exporta o relatório (CSV, Excel salvo como CSV ou OFX) e salva em `entrada/`. O agente converte com os scripts abaixo.
2. **Envio automático pela administradora:** muitas administradoras mandam relatórios por e-mail em dia fixo. O síndico salva os anexos na pasta, ou configura uma pasta sincronizada (OneDrive, Google Drive) que aponte para `entrada/`.
3. **API (só onde existe documentação pública e com token de leitura):** conector dedicado, configurado pelo síndico como segredo no Paperclip, nunca na pasta de dados. Ver a tabela.

## Sistemas de gestão condominial (ERP de administradora ou autogestão)
| Sistema | Uso típico | API pública? | Como integrar hoje |
|---|---|---|---|
| **Superlógica Condomínios** | líder de mercado; mais de 130 mil condomínios; administradoras e autogestão | **Sim.** Documentação no Postman (`apicondominios.superlogica.com`); base `https://api.superlogica.net/v2/condor/`; autenticação por `app_token` + `access_token` criados no ERP (menu de integração → Aplicativos), com as permissões do usuário que os criou | Hoje: exportar relatórios (inadimplência, balancete, lançamentos, unidades). Conector API: versão futura, com usuário **somente leitura** criado só para isso **[conferir]** endpoints na documentação |
| **Condomínio21** (Group Software) | administradoras tradicionais | não encontrada | exportar relatórios em Excel/CSV |
| **uCondo** | autogestão e administradoras; régua de cobrança e acordos | não encontrada | exportar relatórios |
| **TownSq** | app de comunicação e gestão; integrações com sistemas de administradoras | anunciada, sem documentação pública | exportar; perguntar ao fornecedor |
| **Sigadm, AlmahCondos, Club System, Alterdata Immobile** | administradoras regionais | não encontrada | exportar relatórios |

Sem API pública, **não** use automação de navegador (robô que entra com a senha do síndico): quebra quando o site muda, viola os termos de uso e expõe a credencial.

## Bancos
| Dado | Formato | Como trazer |
|---|---|---|
| Extrato da conta | **OFX** (todos os grandes bancos exportam no internet banking) | `scripts/ofx_para_csv.py` → `extrato_bancario.csv` |
| Boletos pagos (retorno de cobrança) | CNAB 240/400 (layout varia por banco) ou relatório do sistema de boletos | preferir o relatório de "cobranças/recebimentos" do sistema de gestão, convertido com `converter_planilha.py` |
| Saldos | extrato ou print do síndico | `saldos.csv` digitado (3 linhas por mês) |

Open Finance exige empresa autorizada pelo Banco Central; não se aplica a este pacote.

## Apps de portaria, acesso e comunicação
Sistemas como Gruvi (Superlógica, Cyrela e Intelbras), Portaria na Nuvem (Seventh), apps de portaria remota e controle de acesso (Intelbras, Hikvision, Control iD) guardam **dados pessoais e biometria**. Este pacote **não integra** com eles. Só entram aqui, se o síndico quiser, **contagens agregadas** (ex.: chamados por tipo, reservas por mês), sem nomes, placas ou imagens. Ver skill `lgpd-condominio`.

## Scripts
### OFX → extrato
`python3 scripts/ofx_para_csv.py <extrato.ofx> "$CONDOMINIO_DADOS/entrada" --conta ORDINARIA --anexar`

Repita com `--conta FUNDO_RESERVA` para a conta do fundo, se for separada.

### Qualquer exportação → contrato de dados
`python3 scripts/converter_planilha.py <exportacao.csv> <mapa.txt> "$CONDOMINIO_DADOS/entrada"`

Na implantação, o agente olha o cabeçalho da exportação e escreve o `mapa.txt` uma vez por relatório. Os mapas ficam salvos em `$CONDOMINIO_DADOS/mapas/` para o síndico reusar todo mês. Exemplo para um relatório de cobranças:

```
arquivo = cobrancas.csv
unidade = Unidade
competencia = Competência
tipo = =ORDINARIA
vencimento = Vencimento
valor = Valor
pago_em = Data Pagamento
valor_pago = Valor Pago
ignorar_se_vazio = unidade
```

O conversor troca datas `DD/MM/AAAA` por `AAAA-MM-DD` e **não copia** colunas de nome, CPF, telefone, e-mail ou placa, mesmo que estejam no mapa.

## Checklist na implantação
1. Qual sistema a administradora (ou o síndico) usa? Qual banco?
2. Quais relatórios o sistema exporta e em que formato? Peça um exemplo de cada um.
3. Escreva os mapas, converta e rode `validar_dados.py` da skill `contrato-de-dados`.
4. Combine quem exporta, quando (ex.: todo dia 3) e onde salva.
5. Se for Superlógica e o síndico quiser API no futuro, anote: precisa de um usuário só de leitura e de aprovação dele para criar o token.
