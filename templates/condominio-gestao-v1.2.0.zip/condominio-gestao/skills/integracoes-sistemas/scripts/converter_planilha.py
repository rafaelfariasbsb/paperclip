#!/usr/bin/env python3
"""Converte uma exportacao de sistema (CSV ou Excel salvo como CSV) para um arquivo do contrato de dados,
usando um arquivo de mapeamento de colunas. Serve para qualquer sistema de condominio ou banco.

Uso: python3 converter_planilha.py <exportacao.csv> <mapa.txt> <pasta_entrada>

Formato do mapa.txt (uma regra por linha; # comenta):
    arquivo = cobrancas.csv            # arquivo de destino do contrato de dados
    unidade = Unidade                  # coluna_destino = coluna da exportacao
    competencia = Competencia
    vencimento = Vencimento
    valor = Valor
    pago_em = Data de Pagamento
    valor_pago = Valor Pago
    tipo = =ORDINARIA                  # valor fixo: comece com =
    ignorar_se_vazio = unidade         # opcional: descarta linha sem esse campo

Datas DD/MM/AAAA viram AAAA-MM-DD; MM/AAAA vira AAAA-MM. Colunas de dado pessoal (nome, CPF, telefone,
e-mail, placa) nao sao copiadas, mesmo que estejam no mapa.
"""
import csv, os, re, sys

PESSOAIS = ("nome", "cpf", "rg", "telefone", "celular", "whatsapp", "email", "mail", "placa", "nascimento")


def ler_csv(caminho):
    raw = open(caminho, "rb").read()
    try:
        txt = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        txt = raw.decode("latin-1")
    amostra = txt[:4096]
    sep = max(";,\t", key=amostra.count)
    return list(csv.DictReader(txt.splitlines(), delimiter=sep))


def normaliza(v):
    v = (v or "").strip()
    m = re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})", v)
    if m:
        return f"{m[3]}-{m[2]}-{m[1]}"
    m = re.fullmatch(r"(\d{2})/(\d{4})", v)
    if m:
        return f"{m[2]}-{m[1]}"
    return v.replace("R$", "").strip()


def main():
    if len(sys.argv) != 4:
        print(__doc__); raise SystemExit(2)
    origem, mapa_arq, pasta = sys.argv[1:]
    mapa, destino, obrig = {}, None, None
    for linha in open(mapa_arq, encoding="utf-8"):
        linha = linha.split("#", 1)[0].strip()
        if "=" not in linha:
            continue
        k, v = (x.strip() for x in linha.split("=", 1))
        if k == "arquivo":
            destino = v
        elif k == "ignorar_se_vazio":
            obrig = v
        elif any(p == k or p in k.split("_") for p in PESSOAIS):
            print(f"Ignorando '{k}': parece dado pessoal (LGPD).")
        else:
            mapa[k] = v
    if not destino:
        print("O mapa precisa da linha 'arquivo = <nome>.csv'."); raise SystemExit(2)
    linhas = ler_csv(origem)
    cab = {c.strip().lower(): c for c in (linhas[0].keys() if linhas else [])}
    faltam = [v for v in mapa.values() if not v.startswith("=") and v.strip().lower() not in cab]
    if faltam:
        print(f"Colunas do mapa que nao existem na exportacao: {', '.join(faltam)}")
        print(f"Colunas disponiveis: {', '.join(cab.values())}")
        raise SystemExit(2)
    saida = []
    for r in linhas:
        novo = {k: (v[1:] if v.startswith("=") else normaliza(r[cab[v.strip().lower()]])) for k, v in mapa.items()}
        if obrig and not novo.get(obrig):
            continue
        saida.append(novo)
    os.makedirs(pasta, exist_ok=True)
    with open(os.path.join(pasta, destino), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(mapa), delimiter=";")
        w.writeheader(); w.writerows(saida)
    print(f"{len(saida)} linhas gravadas em {os.path.join(pasta, destino)}. Rode validar_dados.py para conferir.")


if __name__ == "__main__":
    main()
