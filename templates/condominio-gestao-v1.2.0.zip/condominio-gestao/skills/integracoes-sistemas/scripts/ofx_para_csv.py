#!/usr/bin/env python3
"""Converte extrato bancario OFX (padrao de todos os grandes bancos) para extrato_bancario.csv do contrato de dados.
Uso: python3 ofx_para_csv.py <arquivo.ofx> <pasta_entrada> [--conta ORDINARIA] [--anexar]
Aceita OFX 1.x (SGML, sem tags de fechamento) e 2.x (XML). Le em UTF-8 ou Latin-1.
"""
import argparse, csv, os, re


def campo(bloco, tag):
    m = re.search(rf"<{tag}>\s*([^<\r\n]*)", bloco, re.I)
    return m.group(1).strip() if m else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ofx")
    ap.add_argument("pasta")
    ap.add_argument("--conta", default="ORDINARIA")
    ap.add_argument("--anexar", action="store_true", help="acrescenta ao extrato_bancario.csv existente, sem duplicar")
    a = ap.parse_args()
    raw = open(a.ofx, "rb").read()
    try:
        txt = raw.decode("utf-8")
    except UnicodeDecodeError:
        txt = raw.decode("latin-1")
    linhas = []
    for bloco in re.findall(r"<STMTTRN>(.*?)(?:</STMTTRN>|(?=<STMTTRN>)|</BANKTRANLIST>)", txt, re.I | re.S):
        d = campo(bloco, "DTPOSTED")[:8]
        if len(d) != 8:
            continue
        valor = campo(bloco, "TRNAMT").replace(",", ".")
        desc = " ".join(x for x in (campo(bloco, "NAME"), campo(bloco, "MEMO")) if x) or campo(bloco, "TRNTYPE")
        linhas.append((f"{d[:4]}-{d[4:6]}-{d[6:]}", a.conta.upper(), re.sub(r"\s+", " ", desc), f"{float(valor):.2f}".replace(".", ",")))
    if not linhas:
        print("Nenhuma transacao encontrada. Confira se o arquivo e mesmo OFX (extrato) e nao PDF ou Excel.")
        raise SystemExit(2)
    os.makedirs(a.pasta, exist_ok=True)
    destino = os.path.join(a.pasta, "extrato_bancario.csv")
    existentes = []
    if a.anexar and os.path.exists(destino):
        with open(destino, encoding="utf-8-sig", newline="") as f:
            existentes = [tuple(r) for r in csv.reader(f, delimiter=";")][1:]
    todas = sorted(set(existentes) | set(linhas))
    with open(destino, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["data", "conta", "descricao", "valor"])
        w.writerows(todas)
    print(f"{len(linhas)} transacoes lidas ({min(l[0] for l in linhas)} a {max(l[0] for l in linhas)}); {len(todas)} linhas em {destino}")


if __name__ == "__main__":
    main()
