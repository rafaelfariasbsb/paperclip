#!/usr/bin/env python3
"""Previsao orcamentaria anual e rateio por unidade.
Uso: python3 orcamento.py <pasta> [--ate AAAA-MM] [--reajuste 5] [--reajuste-categoria "Folha e encargos=6.5" ...]
       [--inadimplencia 5] [--fundo-reserva 10] [--rateio fracao|igual] [--extra-anual 0]
Base: media mensal das despesas da conta ORDINARIA nos 12 meses ate --ate (padrao: mes anterior).
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--ate")
    ap.add_argument("--reajuste", type=float, default=5.0)
    ap.add_argument("--reajuste-categoria", action="append", default=[])
    ap.add_argument("--inadimplencia", type=float, default=5.0)
    ap.add_argument("--fundo-reserva", type=float, default=10.0)
    ap.add_argument("--rateio", choices=["fracao", "igual"], default="fracao")
    ap.add_argument("--extra-anual", type=float, default=0.0, help="manutencoes previstas no ano (R$), fora do historico")
    a = ap.parse_args()
    ate = a.ate or (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
    y, m = map(int, ate.split("-"))
    meses = []
    for _ in range(12):
        meses.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    lanc = [r for r in exigir(a.pasta, "lancamentos.csv")
            if r["conta"].upper() == "ORDINARIA" and r["data"][:7] in meses and num(r["valor"]) < 0]
    unid = exigir(a.pasta, "unidades.csv")
    meses_com_dado = sorted({r["data"][:7] for r in lanc})
    n = len(meses_com_dado) or 1
    por_cat = defaultdict(float)
    for r in lanc:
        por_cat[r["categoria"]] += -num(r["valor"])
    esp = {}
    for s in a.reajuste_categoria:
        k, v = s.rsplit("=", 1); esp[k.strip()] = float(v)
    print(f"# Previsao orcamentaria (base: {meses_com_dado[0] if lanc else '-'} a {ate}, {n} meses com dados)\n")
    if n < 12:
        print(f"> Atencao: so {n} meses de historico. A media pode nao representar o ano.\n")
    print("| Categoria | Media mensal | Reajuste | Previsto mensal |\n|---|---|---|---|")
    total = 0.0
    for k, v in sorted(por_cat.items(), key=lambda x: -x[1]):
        med = v / n; rj = esp.get(k, a.reajuste); prev = med * (1 + rj / 100); total += prev
        print(f"| {k} | {brl(med)} | {rj:.1f}% | {brl(prev)} |")
    extra = a.extra_anual / 12
    base = total + extra
    prov = base * a.inadimplencia / (100 - a.inadimplencia)
    ordinaria = base + prov
    fr = ordinaria * a.fundo_reserva / 100
    print(f"| Manutencoes previstas (anual/12) | | | {brl(extra)} |")
    print(f"\n- Despesa prevista mensal: {brl(base)}")
    print(f"- Provisao de inadimplencia ({a.inadimplencia:.1f}%): {brl(prov)}")
    print(f"- Arrecadacao ordinaria necessaria: {brl(ordinaria)}")
    print(f"- Fundo de reserva ({a.fundo_reserva:.1f}% da cota): {brl(fr)}")
    print(f"- **Total mensal a ratear: {brl(ordinaria + fr)}** · anual: {brl((ordinaria + fr) * 12)}\n")
    soma_fr = sum(num(u["fracao_ideal"]) for u in unid) or 1
    cotas = defaultdict(list)
    print(f"## Rateio ({'fracao ideal' if a.rateio == 'fracao' else 'igualitario'}), {len(unid)} unidades\n")
    print("| Unidade | Fracao | Cota ordinaria | Fundo de reserva | Total |\n|---|---|---|---|---|")
    for u in unid:
        p = num(u["fracao_ideal"]) / soma_fr if a.rateio == "fracao" else 1 / len(unid)
        c, f = ordinaria * p, fr * p
        cotas[round(c + f, 2)].append(u["unidade"])
        print(f"| {u['unidade']} | {num(u['fracao_ideal']):.6f} | {brl(c)} | {brl(f)} | {brl(c + f)} |")
    atual = {}
    for r in ler(a.pasta, "cobrancas.csv") or []:
        if r["tipo"].upper() in ("ORDINARIA", "FUNDO_RESERVA") and r["competencia"] == ate:
            atual[r["unidade"]] = atual.get(r["unidade"], 0) + num(r["valor"])
    if atual:
        tot_atual = sum(atual.values())
        print(f"\nArrecadacao atual ({ate}): {brl(tot_atual)} -> proposta {brl(ordinaria + fr)} ({((ordinaria + fr) / tot_atual - 1) * 100:+.1f}%)")
    if abs(soma_fr - 1) > 0.001 and a.rateio == "fracao":
        print(f"\n> Atencao: a soma das fracoes ideais e {soma_fr:.6f} (esperado 1). O rateio foi normalizado; confira unidades.csv.")
    print("\n> Rascunho para a assembleia (art. 1.350). Quem aprova e a assembleia.")


if __name__ == "__main__":
    main()
