---
name: previsao-orcamentaria-rateio
description: "Previsão orçamentária anual a partir do histórico de 12 meses, com reajustes, provisão de inadimplência, fundo de reserva e rateio por unidade (fração ideal ou igualitário)."
---

# Previsão orçamentária e rateio

`python3 scripts/orcamento.py "$CONDOMINIO_DADOS/entrada" --reajuste 5 --inadimplencia 5 --fundo-reserva 10 --rateio fracao`

- Média mensal por categoria de despesa nos últimos 12 meses de `lancamentos.csv` (conta ordinária).
- Aplica o reajuste geral (`--reajuste`, em %) e, se informado, reajustes por categoria (`--reajuste-categoria "Folha e encargos=6.5"`).
- Soma a provisão de inadimplência (`--inadimplencia`, em %): sem ela, quem paga em dia cobre o déficit com rateio extra.
- Calcula o fundo de reserva como % da cota (`--fundo-reserva`), conforme a convenção.
- Rateia pelo `fracao_ideal` de `unidades.csv` (`--rateio fracao`, regra do art. 1.336, I) ou em partes iguais (`--rateio igual`), se a convenção mandar.

## Como montar para a assembleia
1. Histórico de 12 meses por categoria, com o que foi atípico (obra, conserto grande) retirado ou explicado.
2. Contratos com reajuste previsto (índice e mês), dissídio da categoria dos funcionários **[conferir]** na convenção coletiva local.
3. Manutenções do plano anual (skill `plano-manutencao-nbr5674`) com custo estimado.
4. Provisão de inadimplência e fundo de reserva.
5. Cota por unidade e comparação com a cota atual (variação em R$ e %).

## Base legal
- O síndico elabora o orçamento da receita e da despesa de cada ano (art. 1.348, VI).
- A assembleia ordinária anual aprova o orçamento, as contribuições e as contas (art. 1.350).

## Erros comuns que o agente deve apontar
- Orçamento sem reajuste realista, que vira rateio extra no meio do ano.
- Fundo de reserva usado para despesa ordinária.
- Manutenção obrigatória (laudos, reservatórios, elevador) fora do orçamento.
