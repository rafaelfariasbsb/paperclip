#!/usr/bin/env python3
"""Consumo de agua, energia e gas: ultimo mes x media dos meses anteriores.
Uso: python3 consumo.py <pasta> [--meses 6] [--limite 20]
"""
import argparse, csv, os, sys
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if not v:
        return 0.0
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def exigir(pasta, nome):
    linhas = ler(pasta, nome)
    if linhas is None:
        print(f"FALTA o arquivo {nome} em {pasta}. Rotina nao executada; nao invente dados.")
        sys.exit(2)
    return linhas


def brl(v):
    s = f"R$ {abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return "-" + s if v < 0 else s


def dt(s):
    return date.fromisoformat(s[:10]) if s else None

DICAS = {
    "AGUA": "vazamento em reservatorio ou tubulacao, boia travada, descarga de area comum, ladrao escorrendo, piscina, medidor",
    "ENERGIA": "bomba ligando demais (boia/pressostato), iluminacao acesa de dia, elevador com defeito, equipamento novo",
    "GAS": "POSSIVEL VAZAMENTO: tratar como urgencia de seguranca e acionar empresa habilitada",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--meses", type=int, default=6)
    ap.add_argument("--limite", type=float, default=20.0)
    a = ap.parse_args()
    dados = defaultdict(dict)
    for r in exigir(a.pasta, "consumo.csv"):
        dados[r["tipo"].upper()][r["mes"]] = (num(r["quantidade"]), num(r["valor"]))
    print("# Consumo das areas comuns\n\n| Tipo | Mes | Quantidade | Media anterior | Variacao | Valor | Situacao |\n|---|---|---|---|---|---|---|")
    alertas = []
    for tipo, serie in sorted(dados.items()):
        meses = sorted(serie)
        if len(meses) < 2:
            print(f"| {tipo} | {meses[-1] if meses else '-'} | - | - | - | - | historico insuficiente |")
            continue
        ult = meses[-1]; ant = meses[-1 - a.meses:-1]
        media = sum(serie[m][0] for m in ant) / len(ant)
        var = (serie[ult][0] / media - 1) * 100 if media else 0
        sit = "ALERTA" if var > a.limite else "ok"
        if sit == "ALERTA":
            alertas.append((tipo, ult, var))
        print(f"| {tipo} | {ult} | {serie[ult][0]:.1f} | {media:.1f} | {var:+.1f}% | {brl(serie[ult][1])} | {sit} |")
    print()
    for tipo, mes, var in alertas:
        print(f"- **{tipo} {mes} ({var:+.1f}%)**: verificar {DICAS.get(tipo, 'causa do aumento')}.")
    if not alertas:
        print(f"Nenhum consumo acima de {a.limite:.0f}% da media.")


if __name__ == "__main__":
    main()
