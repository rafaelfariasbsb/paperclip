---
name: consumo-agua-energia
description: "Acompanhamento mensal do consumo de água, energia e gás das áreas comuns, com alerta de salto em relação à média para investigar vazamentos e falhas."
---

# Consumo de água, energia e gás

`python3 scripts/consumo.py "$CONDOMINIO_DADOS/entrada" --meses 6 --limite 20`

- Compara o último mês de cada tipo (`AGUA`, `ENERGIA`, `GAS`) com a média dos `--meses` anteriores.
- Salto acima de `--limite` % vira alerta com hipóteses a verificar.

## Hipóteses por tipo
- **Água:** vazamento em reservatório, boia travada, descarga com defeito em área comum, ladrão escorrendo, rega em excesso, piscina, medidor.
- **Energia:** bomba ligando demais (boia ou pressostato), iluminação acesa de dia, elevador com defeito, equipamento novo.
- **Gás:** vazamento (tratar como **urgência de segurança**: tarefa `[SINDICO]` imediata para acionar a empresa habilitada), aquecimento central.

Leitura de medidor individual de unidade não entra aqui: é dado de consumo do morador e depende de regra da convenção.
