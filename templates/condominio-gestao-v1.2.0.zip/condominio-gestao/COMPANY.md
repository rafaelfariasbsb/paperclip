---
name: Condomínio – Gestão com IA
description: Escritório de apoio ao síndico de condomínio residencial — finanças e prestação de contas, inadimplência, manutenção preventiva (NBR 5674), documentos e prazos legais, assembleias, comunicados e atendimento aos moradores. Agentes preparam; síndico, conselho e assembleia decidem.
slug: condominio-gestao
schema: agentcompanies/v1
version: 1.2.0
license: Proprietária — veja LICENSE.md
authors:
  - name: Rafael Farias
tags:
  - condominio
  - sindico
  - administracao-predial
  - brasil
goals:
  - Nenhum documento, laudo, seguro ou manutenção obrigatória vencido sem tarefa aberta
  - Prestação de contas mensal pronta para o conselho até o dia 10, com orçado x realizado
  - Inadimplência medida toda semana e tratada com régua de cobrança respeitosa e dentro da lei
  - Plano de manutenção preventiva (NBR 5674) em dia e provisionado no orçamento
  - Assembleias convocadas e registradas sem falha de forma (edital, quórum, ata)
---

# Condomínio – Gestão com IA

Esta empresa dá ao síndico de um condomínio residencial a retaguarda de uma administradora: os agentes leem as planilhas e exportações colocadas numa pasta combinada (lançamentos, extrato do banco, boletos, plano de manutenção, documentos), calculam, conferem, alertam e escrevem rascunhos. **Quem decide é sempre um humano.**

## Quem é quem

- **Board (síndico):** representante legal do condomínio (Código Civil, art. 1.348). Aprova pagamentos, contratações, comunicados, notificações, multas e propostas para a assembleia.
- **Conselho fiscal:** dá parecer sobre as contas (art. 1.356). Recebe o balancete mensal preparado pelos agentes.
- **Assembleia:** aprova orçamento, contas, obras, alterações de convenção e regimento, e elege o síndico.
- **Administradora, contador e advogado:** quando existirem, fazem folha, guias, obrigações fiscais e cobrança judicial. Os agentes só preparam a pré-conferência e o dossiê.
- **Zelador ou gerente predial:** executa a manutenção e alimenta o plano com as datas reais.

## Organograma

```
Síndico (board)
 └── gerente-geral
       ├── implantacao               (configura o condomínio na 1ª semana)
       ├── conformidade              (documentos, laudos, seguro, obrigações, LGPD)
       ├── financeiro
       │     └── cobranca
       ├── manutencao-predial
       ├── assembleias-comunicacao
       └── atendimento-moradores
             └── atendimento-whatsapp  (opcional; modo oficial ou não oficial)
```

## A regra que nenhum agente quebra

Os agentes **não pagam, não assinam, não enviam e não decidem.** A única exceção é o atendimento pelo WhatsApp (agente `atendimento-whatsapp`), que vem desligado e, quando o síndico ativa, só responde a lista fechada de assuntos da skill `whatsapp-atendimento`. Não falam com moradores, fornecedores, bancos, cartórios ou órgãos públicos. Não aplicam multa, não protestam, não negativam, não cortam serviço e não expõem devedor. Tudo sai como rascunho para o síndico aprovar. Todo agente carrega a skill `limites-do-sindico`.

## Dados

Os agentes leem a pasta definida em `CONDOMINIO_DADOS`. O formato dos arquivos está na skill `contrato-de-dados`. As unidades aparecem só pelo número (ex.: `A-101`): nomes, CPF, telefone e placa dos moradores **não** entram na pasta. Dados de exemplo fictícios ficam em `assets/dados-exemplo/`. Nenhuma credencial (banco, gov.br, e-CNPJ, administradora) entra no sistema.

## Atualizações

As regras mudam (Código Civil, leis municipais de laudos e reservatórios, normas ABNT, calendário do eSocial e da EFD-Reinf, reforma tributária). Elas ficam versionadas nas skills, e cada versão deste pacote traz a data da última revisão em `CHANGELOG.md`.
