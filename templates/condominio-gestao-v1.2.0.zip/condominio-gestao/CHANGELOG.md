# Changelog

## 1.2.0 — 2026-11-24
- Novo agente opcional `atendimento-whatsapp` (vem desligado) e skill `whatsapp-atendimento`: lista fechada de assuntos, encaminhamento ao síndico, orientação de urgência, LGPD e retenção de 90 dias.
- Dois modos à escolha do síndico: **oficial** (WhatsApp Cloud API da Meta) e **não oficial** (Evolution API instalada pelo síndico, com termo de ciência obrigatório em `assets/modelos/`).
- Scripts `whatsapp_caixa.py`, `whatsapp_enviar.py` (travas: só responde em 24h, 30/h no total, 5/h por número, termo exigido no modo não oficial) e `whatsapp_resumo.py`.
- Rotinas `whatsapp-mensagem-recebida` (gatilho webhook) e `diaria-whatsapp-resumo`.

## 1.1.0 — 2026-11-24
- Nova skill `integracoes-sistemas`: sistemas mais usados por condomínios e administradoras (Superlógica, Condomínio21, uCondo, TownSq e outros), bancos e apps de portaria, com o caminho de integração de cada um.
- Novos scripts: `ofx_para_csv.py` (extrato OFX de qualquer banco) e `converter_planilha.py` (qualquer exportação, por mapa de colunas, sem copiar dado pessoal).
- Agente de implantação passa a perguntar sistema e banco e a montar os mapas de conversão.

## 1.0.0 — 2026-11-24
- Primeira versão: 8 agentes, 18 skills, 11 scripts, 18 rotinas e dados de exemplo.
- Revisão de regras feita em 24/11/2026. Destaques:
  - **Código Civil, arts. 1.331 a 1.358-A:** deveres do síndico, assembleia ordinária anual, quóruns, multa de até 2% por atraso.
  - **Lei 14.905/2024:** sem taxa de juros na convenção, aplica-se a taxa legal (Selic menos IPCA, divulgada pelo Banco Central) e correção pelo IPCA.
  - **Lei 14.309/2022 (art. 1.354-A):** assembleia eletrônica ou híbrida, se a convenção não proibir; sessão permanente de até 90 dias.
  - **CPC, art. 784, X:** cota condominial aprovada é título executivo extrajudicial.
  - **DIRF extinta:** informações passam por eSocial e EFD-Reinf (mensal).
  - **ABNT:** NBR 5674 (manutenção), NBR 14037 (manual de uso), NBR 16280 (reformas), NBR 16747 (inspeção predial), NBR 17170 (garantias).
  - **LGPD:** condomínio é agente de tratamento; biometria é dado sensível.
- Itens que dependem do município, do estado ou da convenção estão marcados **[conferir]** nas skills.
