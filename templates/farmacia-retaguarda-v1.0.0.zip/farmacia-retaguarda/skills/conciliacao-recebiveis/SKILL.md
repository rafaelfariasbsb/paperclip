---
name: conciliacao-recebiveis
description: "Conciliação diária de vendas do ERP com extratos de cartão e Pix, conferência de taxas e fluxo de caixa projetado de 30 dias."
---

# Conciliação e fluxo de caixa

`python3 scripts/conciliar.py "$FARMACIA_DADOS/entrada" --tolerancia 1.00 --horizonte 30`

- Compara, por dia e forma de pagamento, o valor vendido no ERP com o bruto do extrato. Dinheiro fica fora.
- Mostra a taxa efetiva cobrada. Compare com a taxa contratada informada pelo dono.
- Projeta o saldo dia a dia (saldo + recebíveis − contas a pagar) e alerta o **menor saldo** e a data.
- Divergências viram tarefa `[DONO]` com a lista. O agente nunca contata a adquirente nem antecipa recebíveis.
