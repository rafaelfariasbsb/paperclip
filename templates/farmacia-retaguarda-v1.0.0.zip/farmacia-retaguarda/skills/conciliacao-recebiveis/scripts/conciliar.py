#!/usr/bin/env python3
"""Conciliacao diaria: vendas no ERP x extrato de recebimentos (cartao/Pix), e fluxo de caixa projetado.
Dinheiro nao aparece no extrato e e ignorado na conciliacao.
Uso: python3 conciliar.py <pasta_dados> [--hoje AAAA-MM-DD] [--tolerancia 1.00] [--horizonte 30]
"""
import argparse, csv, os
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def brl(v):
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--tolerancia", type=float, default=1.00)
    ap.add_argument("--horizonte", type=int, default=30)
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    erp, ext, taxas = defaultdict(float), defaultdict(float), defaultdict(float)
    for r in ler(a.pasta, "caixa_erp.csv"):
        if r["forma_pagamento"].upper() != "DINHEIRO":
            erp[(r["data"], r["forma_pagamento"].upper())] += num(r["valor"])
    for r in ler(a.pasta, "extrato_recebimentos.csv"):
        k = (r["data"], r["forma_pagamento"].upper())
        ext[k] += num(r["valor_bruto"]); taxas[k] += num(r["taxa"])
    print(f"# Conciliacao e caixa - {hoje}\n")
    print("## Vendas ERP x extrato (cartao e Pix)\n")
    print("| Data | Forma | ERP | Extrato | Diferenca | Taxa cobrada | Situacao |\n|---|---|---|---|---|---|---|")
    difs = 0
    for k in sorted(set(erp) | set(ext)):
        d = erp[k] - ext[k]
        sit = "OK" if abs(d) <= a.tolerancia else "DIVERGENTE"
        difs += sit != "OK"
        pct = f"{taxas[k] / ext[k]:.2%}" if ext[k] else "-"
        print(f"| {k[0]} | {k[1]} | {brl(erp[k])} | {brl(ext[k])} | {brl(d)} | {pct} | {sit} |")
    print(f"\nDivergencias acima de {brl(a.tolerancia)}: {difs}")

    saldo = sum(num(r["saldo"]) for r in ler(a.pasta, "saldos.csv"))
    fim = (hoje + timedelta(days=a.horizonte)).isoformat()
    ent = [(r["data_prevista"], r["origem"], num(r["valor"])) for r in ler(a.pasta, "recebiveis_futuros.csv") if r["data_prevista"] <= fim]
    sai = [(r["vencimento"], r["fornecedor"] + " - " + r["descricao"], -num(r["valor"]))
           for r in ler(a.pasta, "contas_pagar.csv") if r["status"].upper() == "ABERTO" and r["vencimento"] <= fim]
    print(f"\n## Fluxo de caixa projetado ({a.horizonte} dias)\n\nSaldo inicial: {brl(saldo)}\n")
    print("| Data | Movimento | Valor | Saldo |\n|---|---|---|---|")
    menor, dia_menor = saldo, hoje.isoformat()
    for d, desc, v in sorted(ent + sai):
        saldo += v
        if saldo < menor:
            menor, dia_menor = saldo, d
        print(f"| {d} | {desc} | {brl(v)} | {brl(saldo)} |")
    alerta = "ALERTA: saldo negativo projetado" if menor < 0 else "sem saldo negativo projetado"
    print(f"\nMenor saldo: {brl(menor)} em {dia_menor} -> {alerta}")
    print("\n> O agente nunca paga, transfere ou antecipa recebiveis. Decisao do dono.")


if __name__ == "__main__":
    main()
