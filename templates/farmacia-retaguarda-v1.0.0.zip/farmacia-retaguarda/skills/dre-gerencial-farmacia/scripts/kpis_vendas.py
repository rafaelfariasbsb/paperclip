#!/usr/bin/env python3
"""KPIs comerciais e margem por categoria a partir das vendas e do custo atual.
Saida: faturamento, cupons, ticket medio, itens por cupom, margem bruta por categoria, % genericos.
Obs.: usa o custo unitario ATUAL do cadastro (aproximacao do CMV); trocar pelo CMV contabil quando disponivel.
Uso: python3 kpis_vendas.py <pasta_dados> [--de AAAA-MM-DD] [--ate AAAA-MM-DD]
"""
import argparse, csv, os
from collections import defaultdict

NOMES = {"GEN": "Genericos", "REF": "Referencia", "SIM": "Similares", "MIP": "MIP", "HPC": "HPC/perfumaria", "CTRL": "Controlados"}


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def brl(v):
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--de", default="0000-00-00")
    ap.add_argument("--ate", default="9999-99-99")
    a = ap.parse_args()
    prods = {p["sku"]: p for p in ler(a.pasta, "produtos_estoque.csv")}
    rec, cmv = defaultdict(float), defaultdict(float)
    cupons, itens = set(), 0.0
    for r in ler(a.pasta, "vendas_itens.csv"):
        if not (a.de <= r["data"] <= a.ate):
            continue
        p = prods.get(r["sku"], {})
        cat = p.get("categoria", "OUTROS")
        q = num(r["quantidade"])
        rec[cat] += num(r["valor_total"])
        cmv[cat] += q * num(p.get("custo_unit", "0"))
        cupons.add(r["cupom"]); itens += q
    fat = sum(rec.values())
    print(f"# KPIs de vendas ({a.de} a {a.ate})\n")
    if not fat:
        print("Sem vendas no periodo."); return
    print(f"- Faturamento: {brl(fat)}")
    print(f"- Cupons: {len(cupons)} | Ticket medio: {brl(fat / len(cupons))} | Itens por cupom: {itens / len(cupons):.2f}")
    med = sum(v for k, v in rec.items() if k in ("GEN", "REF", "SIM", "MIP", "CTRL"))
    if med:
        print(f"- % genericos sobre medicamentos: {rec.get('GEN', 0) / med:.1%}")
    tot_cmv = sum(cmv.values())
    print(f"- Margem bruta total (aprox.): {(fat - tot_cmv) / fat:.1%}\n")
    print("| Categoria | Receita | % receita | Margem bruta |\n|---|---|---|---|")
    for cat in sorted(rec, key=lambda c: -rec[c]):
        m = (rec[cat] - cmv[cat]) / rec[cat] if rec[cat] else 0
        print(f"| {NOMES.get(cat, cat)} | {brl(rec[cat])} | {rec[cat] / fat:.1%} | {m:.1%} |")
    print("\n> Benchmarks de mercado para drogaria independente nao tem fonte publica confiavel: comparar com a linha de base da propria farmacia.")


if __name__ == "__main__":
    main()
