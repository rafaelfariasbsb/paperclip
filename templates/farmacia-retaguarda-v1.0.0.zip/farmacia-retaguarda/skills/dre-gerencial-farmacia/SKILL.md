---
name: dre-gerencial-farmacia
description: "DRE gerencial mensal da drogaria, KPIs comerciais (ticket, itens por cupom, margem por categoria, % genéricos), ciclo financeiro e capital de giro."
---

# DRE gerencial e KPIs

`python3 scripts/kpis_vendas.py "$FARMACIA_DADOS/entrada" --de AAAA-MM-01 --ate AAAA-MM-31`

## Estrutura do DRE gerencial
```
Receita bruta de vendas
(−) Deduções (impostos sobre venda, devoluções)
(=) Receita líquida
(−) CMV
(=) Lucro bruto         -> margem bruta por categoria: GEN, REF, SIM, MIP, HPC, CTRL
(−) Pessoal (total), aluguel, taxas de cartão, sistemas, outras despesas
(=) Resultado operacional
```

## Indicadores
- Ticket médio = faturamento ÷ cupons. Itens por cupom = itens ÷ cupons.
- PME = estoque médio ÷ CMV × 30. PMR = recebíveis ÷ vendas a prazo × 30. PMP = fornecedores ÷ compras × 30.
- Ciclo financeiro = PME + PMR − PMP.
- Capital de giro ÷ custos fixos mensais: **meta ≥ 3** (Sebrae).

O script usa o custo atual do cadastro como aproximação do CMV. Troque pelo CMV contábil quando o contador enviar. Não existem benchmarks públicos confiáveis para drogaria independente: compare com a própria linha de base.
