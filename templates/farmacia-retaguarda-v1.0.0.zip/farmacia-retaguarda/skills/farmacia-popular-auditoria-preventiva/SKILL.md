---
name: farmacia-popular-auditoria-preventiva
description: "Auditoria preventiva mensal do Programa Farmácia Popular: cruzamento de notas de entrada, estoque e dispensações, e prazos do credenciamento."
---

# Farmácia Popular: auditoria preventiva

Só se aplica a farmácia credenciada (veja `config-farmacia.md`).

## Mensal
1. Para cada SKU do programa: estoque inicial + entradas por NF − estoque final, comparado com o dispensado. **A meta de divergência é zero.**
2. Picos atípicos de dispensação, por dia ou por item.
3. Documentos de compra (NF) guardados e localizáveis.
4. Alterações cadastrais (endereço, RT, responsável) comunicadas no prazo.

## Contexto
Em agosto de 2026, a Portaria GM/MS 12.091/2026 atualizou as regras, segundo o CFF. Entre as mudanças estão renovação periódica, guarda de documentos por 5 anos, prazos para comunicar alterações, fiscalização automatizada por risco e multas percentuais. **[ler o texto integral vigente antes de usar números]**

## O agente nunca
Altera dado de dispensação, responde ao Ministério ou decide sobre dispensação. Ele entrega o relatório ao RT e ao dono.
