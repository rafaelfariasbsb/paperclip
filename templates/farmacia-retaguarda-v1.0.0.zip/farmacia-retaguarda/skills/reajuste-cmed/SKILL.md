---
name: reajuste-cmed
description: "Conformidade com o teto de preço (PMC) da CMED, rotina anual do reajuste (fim de março ou início de abril) e índice de preço frente à concorrência."
---

# Reajuste CMED e teto de preço

`python3 scripts/precos_vs_pmc.py "$FARMACIA_DADOS/entrada" --margem-minima 0.20`

## Regras
- **Nenhum preço pode ficar acima do PMC** da tabela CMED vigente. Se ficar, abra tarefa urgente para o dono corrigir.
- O reajuste anual vale a partir da data da resolução da CMED do ano, historicamente entre o fim de março e 1º de abril. Os percentuais variam por nível de concorrência. Em 2026 foram 3,81%, 2,47% e 1,13%, a partir de 31/03 (Resolução CMED nº 4/2026). **[atualizar todo ano]**
- O PMC muda conforme a alíquota de ICMS da UF. Use a coluna da tabela CMED correspondente ao ICMS da farmácia, informada pelo contador.
- **1º de março:** simular o impacto e combinar com o comprador a antecipação de compras.
- **Na data de vigência:** conferir se o ERP recebeu a tabela nova.
- **Competitividade:** os preços praticados nas grandes redes ficam muito abaixo do PMC, segundo um estudo do Idec de 2026 com lojas das 5 maiores redes. Compare com os concorrentes locais, não com o teto.
- Sugestões de preço respeitam a margem mínima e **valem para todos os clientes**, sem condicionar a CPF.
