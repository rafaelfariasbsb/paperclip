#!/usr/bin/env python3
"""Conformidade de preco (nenhum preco acima do PMC) e indice de preco frente a concorrencia.
PMC = 0 ou vazio significa item sem teto CMED (ex.: HPC) e e ignorado na checagem de teto.
Indice = preco proprio / media dos concorrentes (cesta com coleta disponivel).
Uso: python3 precos_vs_pmc.py <pasta_dados> [--margem-minima 0.20]
"""
import argparse, csv, os
from collections import defaultdict


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--margem-minima", type=float, default=0.20)
    a = ap.parse_args()
    prods = {p["sku"]: p for p in ler(a.pasta, "produtos_estoque.csv")}
    print("# Precos: teto PMC, margem e concorrencia\n")
    acima = [(s, p) for s, p in prods.items() if num(p["pmc"]) > 0 and num(p["preco_venda"]) > num(p["pmc"]) + 0.004]
    print(f"## Precos ACIMA do PMC: {len(acima)} (meta: zero)\n")
    for s, p in acima:
        print(f"- {s} {p['descricao']}: preco {p['preco_venda']} > PMC {p['pmc']} -> corrigir antes de vender")
    baixa = []
    for s, p in prods.items():
        pv, cu = num(p["preco_venda"]), num(p["custo_unit"])
        if pv > 0 and (pv - cu) / pv < a.margem_minima:
            baixa.append((s, p, (pv - cu) / pv))
    print(f"\n## Margem abaixo de {a.margem_minima:.0%}: {len(baixa)}\n")
    for s, p, m in baixa:
        print(f"- {s} {p['descricao']}: margem {m:.1%}")
    conc = defaultdict(list)
    for r in ler(a.pasta, "precos_concorrencia.csv"):
        conc[r["sku"]].append(num(r["preco"]))
    print("\n## Indice de preco x concorrencia (1,00 = igual a media)\n")
    if not conc:
        print("Sem coleta de precos da concorrencia.")
        return
    print("| SKU | Produto | Nosso preco | Media concorrentes | Indice | Sugestao (rascunho) |\n|---|---|---|---|---|---|")
    for s, precos in conc.items():
        p = prods.get(s)
        if not p:
            continue
        pv, media = num(p["preco_venda"]), sum(precos) / len(precos)
        idx = pv / media if media else 0
        cu = num(p["custo_unit"])
        piso = cu / (1 - a.margem_minima)
        if idx > 1.05:
            alvo = max(piso, round(media * 0.99, 2))
            sug = f"avaliar reduzir para {alvo:.2f}".replace(".", ",") if alvo < pv else "manter (piso de margem)"
        else:
            sug = "manter"
        print(f"| {s} | {p['descricao']} | {pv:.2f} | {media:.2f} | {idx:.2f} | {sug} |".replace(".", ","))
    print("\n> Toda alteracao de preco e RASCUNHO e depende de aprovacao do dono. Nunca condicionar preco a CPF/cadastro.")


if __name__ == "__main__":
    main()
