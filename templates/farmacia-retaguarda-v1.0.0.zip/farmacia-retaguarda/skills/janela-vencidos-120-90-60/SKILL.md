---
name: janela-vencidos-120-90-60
description: "Gestão de quase-vencidos por janelas de 120/90/60 dias com ação sugerida por faixa, e tratamento de vencidos."
---

# Janela de vencidos 120 / 90 / 60

`python3 scripts/vencidos.py "$FARMACIA_DADOS/entrada" --janelas 120,90,60`

| Faixa | Ação sugerida |
|---|---|
| ≤ 120 dias | Negociar troca com a distribuidora (só se houver acordo comercial) |
| ≤ 90 dias | Remanejar e expor primeiro (FEFO); avaliar promoção permitida |
| ≤ 60 dias | HPC/MIP: liquidar com checklist RDC 96. Medicamentos: priorizar saída, desconto só dentro da RDC 96 e segregar antes de vencer |
| Vencido | Segregar, bloquear venda no sistema e destinar conforme o PGRSS |

Controlados: só sinalizar ao RT. O escalonamento 120/90/60 é uma proposta: valide com as distribuidoras na implantação.
