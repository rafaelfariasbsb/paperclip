#!/usr/bin/env python3
"""Lotes vencidos e quase-vencidos por janela, com acao sugerida.
Janelas padrao: <=120 dias negociar troca; <=90 remanejar/expor; <=60 liquidar (HPC/MIP) ou segregar; vencido = segregar e bloquear.
Controlados: nunca sugerir devolucao/promocao - somente sinalizar ao RT.
Uso: python3 vencidos.py <pasta_dados> [--hoje AAAA-MM-DD] [--janelas 120,90,60]
"""
import argparse, csv, os
from datetime import date


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def brl(v):
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--janelas", default="120,90,60")
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    j120, j90, j60 = sorted((int(x) for x in a.janelas.split(",")), reverse=True)
    prods = {p["sku"]: p for p in ler(a.pasta, "produtos_estoque.csv")}
    faixas = {"VENCIDO": [], f"<= {j60} dias": [], f"<= {j90} dias": [], f"<= {j120} dias": []}
    for l in ler(a.pasta, "lotes.csv"):
        try:
            dias = (date.fromisoformat(l["validade"]) - hoje).days
        except ValueError:
            continue
        if dias > j120:
            continue
        p = prods.get(l["sku"], {})
        ctrl = p.get("controlado", "N").upper() == "S"
        valor = num(l["quantidade"]) * num(p.get("custo_unit", "0"))
        if dias < 0:
            fx, acao = "VENCIDO", "Segregar, bloquear venda no sistema e registrar para descarte (PGRSS)"
        elif dias <= j60:
            if p.get("categoria", "").upper() in ("HPC", "MIP"):
                acao = "Liquidar (oferta com checklist RDC 96) ou segregar"
            else:
                acao = "Priorizar saida (FEFO) e negociar troca; desconto so dentro da RDC 96; se nao sair, segregar antes de vencer"
            fx = f"<= {j60} dias"
        elif dias <= j90:
            fx, acao = f"<= {j90} dias", "Remanejar/expor primeiro (FEFO); avaliar promocao permitida"
        else:
            fx, acao = f"<= {j120} dias", "Negociar troca com a distribuidora (se houver acordo comercial)"
        if ctrl:
            acao = "CONTROLADO: somente sinalizar ao RT (sem devolucao/promocao)"
        faixas[fx].append((l["sku"], p.get("descricao", "?"), l["lote"], l["validade"], dias, l["quantidade"], valor, acao))
    print(f"# Vencidos e quase-vencidos - {hoje}\n")
    for fx, itens in faixas.items():
        tot = sum(i[6] for i in itens)
        print(f"## {fx}: {len(itens)} lote(s), {brl(tot)} a custo\n")
        for s, d, lote, val, dias, q, v, acao in sorted(itens, key=lambda i: i[4]):
            print(f"- {s} {d} | lote {lote} | validade {val} ({dias} dias) | {q} un | {brl(v)} -> {acao}")
        print()


if __name__ == "__main__":
    main()
