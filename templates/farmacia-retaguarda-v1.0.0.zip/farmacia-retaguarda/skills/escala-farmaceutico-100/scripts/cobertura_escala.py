#!/usr/bin/env python3
"""Confere se TODA hora de funcionamento tem farmaceutico escalado (Lei 13.021/2014).
Le horario_funcionamento.csv e escala.csv. Aponta lacunas em minutos.
Uso: python3 cobertura_escala.py <pasta_dados> [--hoje AAAA-MM-DD] [--dias 14]
"""
import argparse, csv, os
from datetime import date, timedelta

DIAS = ["seg", "ter", "qua", "qui", "sex", "sab", "dom"]


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def minutos(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def hhmm(x):
    return f"{x // 60:02d}:{x % 60:02d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--dias", type=int, default=14)
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    horario = {r["dia_semana"][:3].lower(): r for r in ler(a.pasta, "horario_funcionamento.csv")}
    escala = ler(a.pasta, "escala.csv")
    print(f"# Cobertura de farmaceutico - {hoje} (proximos {a.dias} dias)\n")
    if not horario or not escala:
        print("Faltam `horario_funcionamento.csv` ou `escala.csv`.")
        return
    total_aberto = total_coberto = 0
    lacunas = []
    for k in range(a.dias):
        dia = hoje + timedelta(days=k)
        h = horario.get(DIAS[dia.weekday()])
        if not h or not h["abre"]:
            continue
        ab, fe = minutos(h["abre"]), minutos(h["fecha"])
        coberto = [False] * (fe - ab)
        for e in escala:
            if e["data"] != dia.isoformat() or not e["inicio"]:
                continue
            i, f = max(ab, minutos(e["inicio"])), min(fe, minutos(e["fim"]))
            for t in range(i - ab, max(i - ab, f - ab)):
                coberto[t] = True
        total_aberto += len(coberto); total_coberto += sum(coberto)
        t = 0
        while t < len(coberto):
            if not coberto[t]:
                ini = t
                while t < len(coberto) and not coberto[t]:
                    t += 1
                lacunas.append((dia.isoformat(), hhmm(ab + ini), hhmm(ab + t), t - ini))
            t += 1
    pct = total_coberto / total_aberto if total_aberto else 1
    print(f"Cobertura: {pct:.1%} das horas abertas (meta: 100%).\n")
    if lacunas:
        print("## Lacunas SEM farmaceutico (corrigir a escala ou o horario)\n")
        for d, i, f, m in lacunas:
            print(f"- {d}: {i} as {f} ({m} min)")
    else:
        print("Nenhuma lacuna encontrada.")


if __name__ == "__main__":
    main()
