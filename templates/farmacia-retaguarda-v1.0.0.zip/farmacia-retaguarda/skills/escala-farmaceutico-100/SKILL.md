---
name: escala-farmaceutico-100
description: "Garantir farmacêutico presente em 100% do horário de funcionamento (Lei 13.021/2014) e estimar o custo de cobertura."
---

# Escala: farmacêutico em 100% do horário

`python3 scripts/cobertura_escala.py "$FARMACIA_DADOS/entrada" --dias 31` cruza `horario_funcionamento.csv` com `escala.csv` e lista cada intervalo sem farmacêutico.

- **A meta é 100%.** Qualquer lacuna gera tarefa `[DONO]` e `[RT]` para corrigir a escala ou o horário.
- A presença é física. Assistência remota não substitui a presença, segundo decisões judiciais noticiadas pelo CFF.
- O controller usa a escala para estimar o custo de cobertura (horas × custo/hora), sem dados individuais de salário.
