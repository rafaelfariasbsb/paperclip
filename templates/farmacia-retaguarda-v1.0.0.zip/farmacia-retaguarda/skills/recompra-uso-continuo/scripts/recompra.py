#!/usr/bin/env python3
"""Lista de recompra prevista para clientes COM opt-in valido (LGPD).
Regra: data_prevista = ultima compra do item + dias_por_embalagem x quantidade.
Exclui: sem opt-in, descadastrados, itens sem duracao cadastrada e controlados.
A lista e RASCUNHO para validacao do farmaceutico RT; nenhum contato e feito pelo agente.
Uso: python3 recompra.py <pasta_dados> [--hoje AAAA-MM-DD] [--janela 7]
"""
import argparse, csv, os
from datetime import date, timedelta


def num(v):
    v = (v or "").strip()
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--janela", type=int, default=7)
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    validos = {c["cliente_id"] for c in ler(a.pasta, "consentimentos.csv")
               if c["opt_in_recompra"].upper() == "S" and c["descadastrado"].upper() != "S"}
    dur = {d["sku"]: num(d["dias_por_embalagem"]) for d in ler(a.pasta, "duracao_tratamento.csv")}
    prods = {p["sku"]: p for p in ler(a.pasta, "produtos_estoque.csv")}
    ultima = {}
    excluidos_sem_optin = set()
    for r in ler(a.pasta, "vendas_itens.csv"):
        cli = r.get("cliente_id", "")
        if not cli or r["sku"] not in dur:
            continue
        if prods.get(r["sku"], {}).get("controlado", "N").upper() == "S":
            continue
        if cli not in validos:
            excluidos_sem_optin.add(cli); continue
        k = (cli, r["sku"])
        if r["data"] >= ultima.get(k, ("", 0))[0]:
            ultima[k] = (r["data"], num(r["quantidade"]))
    fim = hoje + timedelta(days=a.janela)
    lista = []
    for (cli, sku), (d, q) in ultima.items():
        prev = date.fromisoformat(d) + timedelta(days=int(dur[sku] * max(q, 1)))
        if hoje <= prev <= fim:
            lista.append((prev.isoformat(), cli, sku, prods.get(sku, {}).get("descricao", sku), d))
    print(f"# Recompra prevista ({hoje} a {fim}) - RASCUNHO para validacao do RT\n")
    print(f"Clientes com opt-in valido: {len(validos)}. Clientes ignorados por falta de opt-in: {len(excluidos_sem_optin)}.\n")
    print("| Data prevista | Cliente (id) | SKU | Produto | Ultima compra |\n|---|---|---|---|---|")
    for l in sorted(lista):
        print("| " + " | ".join(l) + " |")
    print("\nMensagem-modelo (neutra; sem nome de medicamento, doenca ou quantidade): \"Ola! Aqui e da farmacia <nome>. Passando para"
          " lembrar que estamos a disposicao para o que precisar. Para nao receber mais avisos, responda SAIR.\"")
    print("\n> Medicamento com receita: qualquer pedido resultante passa pela avaliacao da receita pelo farmaceutico antes da separacao.")
    print("\n> Envio feito por pessoa da equipe, apos validacao do RT e aprovacao do dono.")


if __name__ == "__main__":
    main()
