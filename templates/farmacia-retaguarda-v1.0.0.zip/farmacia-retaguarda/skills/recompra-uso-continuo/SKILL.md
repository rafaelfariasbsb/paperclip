---
name: recompra-uso-continuo
description: "Lista semanal de recompra prevista de medicamentos de uso contínuo, apenas para clientes com opt-in, validada pelo farmacêutico antes de qualquer contato."
---

# Recompra de uso contínuo

`python3 scripts/recompra.py "$FARMACIA_DADOS/entrada" --janela 7`

## Regra de cálculo
Data prevista = última compra + (dias por embalagem × quantidade). A duração por SKU fica em `duracao_tratamento.csv`, que o RT valida.

## Filtros automáticos
O script exclui clientes sem opt-in, clientes descadastrados, itens sem duração cadastrada e itens marcados como controlados (inclui antimicrobianos).

**O RT só deve cadastrar em `duracao_tratamento.csv` medicamentos de uso contínuo adequados para lembrete.** Nunca cadastre controlados, antimicrobianos, canetas GLP-1 ou outros itens sob retenção de receita.

Para medicamento de venda sob prescrição, qualquer pedido que resulte do lembrete passa pela avaliação da receita pelo farmacêutico antes da separação. O lembrete não pode iniciar a venda.

## Fluxo
1. O agente gera a lista e a mensagem-modelo.
2. O RT valida `[RT]`.
3. O dono aprova o modelo.
4. Uma pessoa da equipe envia.

## Mensagem-modelo
Neutra: não cita doença, dose nem nome do medicamento e oferece descadastro.

> "Olá! Aqui é da farmácia <nome>. Passando para lembrar que estamos à disposição para o que precisar. Para não receber mais avisos, responda SAIR."

Não cite o nome do medicamento, a doença ou a quantidade. Não ofereça "separar" um medicamento com receita: o atendimento é feito pela equipe e pelo farmacêutico quando o cliente responder.
