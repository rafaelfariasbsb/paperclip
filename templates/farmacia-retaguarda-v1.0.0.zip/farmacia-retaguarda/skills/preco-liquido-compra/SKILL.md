---
name: preco-liquido-compra
description: "Comparar ofertas de distribuidoras pelo preço líquido (desconto, bonificação, prazo e impostos) e não pelo preço de tabela."
---

# Preço líquido de compra

```
preço líquido = (preço de tabela − desconto) × (1 + ICMS-ST, se cobrado à parte)
                ÷ (1 + bonificação % em produto)
                ajustado pelo custo do prazo: −(taxa mensal × prazo em meses)
```

- Bonificação em produto só vale se o item gira. Bonificação parada vira estoque parado.
- Prazo maior melhora o caixa. Use a taxa de capital de giro informada pelo dono, ou 2% ao mês como padrão a confirmar.
- A tributação (ICMS-ST e monofásico) varia por UF e produto. **Confirme com o contador.**
- Entregue uma tabela por SKU com a distribuidora mais vantajosa e a economia estimada em R$. A escolha final é do dono.
