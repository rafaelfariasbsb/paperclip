---
name: calendario-sazonal-saude
description: "Calendário de campanhas e sazonalidade para marketing de farmácia, ligado aos serviços da loja."
---

# Calendário sazonal de saúde

| Mês | Tema e sazonalidade | Ideias (sempre com checklist RDC 96) |
|---|---|---|
| Jan–Fev | Verão, férias | Fotoproteção, hidratação, repelente, kit viagem (HPC/MIP) |
| Mar–Abr | Volta às aulas; outono; reajuste CMED | Higiene infantil; vacinação, se oferecida |
| Maio | Mês de conscientização sobre hipertensão | Mutirão de aferição de pressão (serviço) |
| Jun–Jul | Inverno, gripes | Vacinação contra gripe (se licenciada), hidratante, lenço, soro |
| Ago | Saúde do homem (preparação) | Conteúdo educativo, sem medicamento tarjado |
| Set | Primavera, alergias | Higiene nasal, protetor solar volta |
| Out | Outubro Rosa | Conteúdo educativo; apoio à prevenção |
| Nov | Novembro Azul; mês de conscientização sobre diabetes | Glicemia capilar (serviço), conteúdo educativo |
| Dez | Festas, férias | Kits presente (HPC), horário especial |

As datas de campanhas devem ser confirmadas no ano corrente. Serviços clínicos só podem ser divulgados se estiverem no licenciamento da loja e forem executados pelo farmacêutico.
