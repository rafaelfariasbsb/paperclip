---
name: relatorios-para-o-dono
description: "Formato dos resumos diário, semanal e mensal para o dono da farmácia: curto, priorizado, com fatos separados de sugestões."
---

# Relatórios para o dono

## Resumo diário (no máximo 10 linhas)
```
🔴 Urgente: <itens que exigem ação hoje>
🟡 Aprovações pendentes: <n> (mais antiga: <há quantas horas>)
📦 Compras: rascunho de R$ <valor> esperando aprovação
💰 Caixa: menor saldo previsto R$ <valor> em <data>
🧾 Prazos: <documento> vence em <n> dias
[RT] <o que o farmacêutico precisa ver>
```

## Relatório semanal
1. KPIs da semana comparados à semana anterior e à linha de base: ruptura, cobertura, ticket médio, margem e caixa projetado.
2. As 5 ações mais importantes, com dono e prazo.
3. Riscos regulatórios e financeiros.
4. Aprovações paradas há mais de 48h.

## Regras
- Primeiro o que exige decisão, depois o informativo.
- Todo número sai de um arquivo ou script. Cite qual.
- "Sugestão" sempre marcada como rascunho.
- Valores em R$ no formato brasileiro (R$ 1.234,56).
- Sem jargão: escreva para o dono, não para o contador.
