---
name: checklist-inspecao-sanitaria
description: "Checklist semanal em rodízio de itens de inspeção da Vigilância Sanitária (RDC 44/2009) e monitoramento de temperatura e umidade."
---

# Checklist de inspeção sanitária

## Temperatura e umidade (diário)
`python3 scripts/temperatura.py "$FARMACIA_DADOS/entrada" --desde AAAA-MM-DD` aponta leituras fora das faixas definidas em `faixas_temperatura.csv`. As faixas devem seguir as recomendações dos fabricantes; a referência comum é 15–30 °C no ambiente e 2–8 °C na geladeira. Para cada desvio, abra tarefa `[RT]` pedindo o registro da ação corretiva. A falta de registro também é pendência.

## Rodízio semanal: 5 a 8 itens por semana, para o RT confirmar
- POPs atualizados, assinados e disponíveis
- Licenças e certidões expostas em local visível
- Registro de temperatura e umidade em dia; termômetros calibrados
- Geladeira exclusiva para medicamentos, sem alimentos
- Área de produtos vencidos ou impróprios segregada e identificada
- Controlados em armário com chave, sob guarda do farmacêutico
- Certificado de controle de pragas válido
- PGRSS e destinação de resíduos (RDC 222/2018)
- Limpeza e organização das áreas de dispensação e de serviços
- Sala de serviços farmacêuticos de acordo com o licenciamento
- Treinamentos da equipe registrados

Os itens da RDC 44/2009 estão em revisão pela Anvisa. **[conferir texto vigente]**
