#!/usr/bin/env python3
"""Desvios de temperatura e umidade em relacao as faixas configuradas.
Le temperatura.csv e faixas_temperatura.csv (local;min;max;umidade_max).
Uso: python3 temperatura.py <pasta_dados> [--desde AAAA-MM-DD]
"""
import argparse, csv, os


def num(v):
    v = (v or "").strip()
    if not v:
        return None
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v)


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--desde", default="")
    a = ap.parse_args()
    faixas = {r["local"].lower(): r for r in ler(a.pasta, "faixas_temperatura.csv")}
    leituras = [r for r in ler(a.pasta, "temperatura.csv") if r["data_hora"] >= a.desde]
    print("# Temperatura e umidade\n")
    if not leituras:
        print("Sem leituras no periodo. Registrar a falta de registro como pendencia para o RT.")
        return
    desvios = []
    for r in leituras:
        fx = faixas.get(r["local"].lower())
        if not fx:
            desvios.append((r, "local sem faixa configurada")); continue
        t, u = num(r["temperatura"]), num(r.get("umidade", ""))
        if t is not None and (t < num(fx["min"]) or t > num(fx["max"])):
            desvios.append((r, f"temperatura {t} fora de {fx['min']}-{fx['max']}"))
        if u is not None and fx.get("umidade_max") and u > num(fx["umidade_max"]):
            desvios.append((r, f"umidade {u}% acima de {fx['umidade_max']}%"))
    print(f"Leituras analisadas: {len(leituras)}. Desvios: {len(desvios)}.\n")
    for r, motivo in desvios:
        print(f"- {r['data_hora']} | {r['local']} | {motivo} -> registrar acao corretiva com o RT")


if __name__ == "__main__":
    main()
