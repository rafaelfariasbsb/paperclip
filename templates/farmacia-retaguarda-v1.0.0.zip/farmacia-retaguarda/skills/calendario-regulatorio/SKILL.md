---
name: calendario-regulatorio
description: "Prazos de licenças e documentos da drogaria (licença sanitária, CRF, alvará, AVCB, AFE, Farmácia Popular, CMED) com alertas 60/30/7 dias."
---

# Calendário regulatório

Rode `python3 scripts/prazos.py "$FARMACIA_DADOS/entrada"` para listar o que está vencido ou vencendo. Para cada linha que não estiver "ok", abra uma tarefa para o responsável indicado na planilha.

## Itens típicos da planilha-mestre (`documentos.csv`)
| Documento | Órgão | Periodicidade |
|---|---|---|
| Licença/alvará sanitário | Vigilância Sanitária municipal/estadual | conforme o município **[confirmar na implantação]** |
| Certidão de Regularidade Técnica | CRF da UF | conforme o CRF **[confirmar]** |
| Alvará de funcionamento | Prefeitura | conforme o município |
| AVCB / licença do Corpo de Bombeiros | CBM da UF | conforme a UF |
| AFE (Anvisa) | Anvisa | atualizar a cada mudança de RT, endereço ou atividade |
| Habilitação no Farmácia Popular | Ministério da Saúde | renovação periódica conforme portaria vigente (em 2026, Portaria GM/MS 12.091/2026, a cada 2 anos) **[conferir texto vigente]** |
| Dedetização e controle de pragas | empresa licenciada | conforme contrato/certificado |
| PGRSS (resíduos) | Vigilância Sanitária | manter atualizado (RDC 222/2018) |

## Datas fixas do ano
- **1º de março:** preparar simulação do reajuste de preços (CMED).
- **Fim de março / início de abril:** reajuste anual de preços de medicamentos pela CMED, na data definida pela resolução do ano (em 2026: a partir de 31/03, Resolução CMED nº 4/2026). Conferir o PMC novo no ERP.

## Regra
Data e periodicidade locais variam por UF e município. Na dúvida, marque **[confirmar com o órgão]** e não invente prazo.
