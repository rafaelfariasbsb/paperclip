#!/usr/bin/env python3
"""Documentos e licencas vencidos ou vencendo (alertas a 60/30/7 dias).
Le documentos.csv (planilha-mestre montada na implantacao).
Uso: python3 prazos.py <pasta_dados> [--hoje AAAA-MM-DD] [--alertas 60,30,7]
"""
import argparse, csv, os
from datetime import date


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--alertas", default="60,30,7")
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    marcos = sorted(int(x) for x in a.alertas.split(","))
    docs = ler(a.pasta, "documentos.csv")
    print(f"# Calendario regulatorio - {hoje}\n")
    if not docs:
        print("Planilha-mestre `documentos.csv` nao encontrada. Pedir ao agente de implantacao para monta-la.")
        return
    linhas = []
    for d in docs:
        try:
            dias = (date.fromisoformat(d["validade"]) - hoje).days
        except ValueError:
            linhas.append((9999, "SEM DATA", d)); continue
        if dias < 0:
            nivel = "VENCIDO"
        elif dias <= marcos[0]:
            nivel = f"URGENTE (<= {marcos[0]} dias)"
        elif dias <= marcos[1]:
            nivel = f"ATENCAO (<= {marcos[1]} dias)"
        elif dias <= marcos[2]:
            nivel = f"PLANEJAR (<= {marcos[2]} dias)"
        else:
            nivel = "ok"
        linhas.append((dias, nivel, d))
    print("| Documento | Orgao | Validade | Dias | Situacao | Responsavel |\n|---|---|---|---|---|---|")
    for dias, nivel, d in sorted(linhas, key=lambda x: x[0]):
        print(f"| {d['documento']} | {d['orgao']} | {d['validade']} | {dias if dias != 9999 else '-'} | {nivel} | {d['responsavel']} |")
    pend = [l for l in linhas if l[1] != "ok"]
    print(f"\nPendencias que exigem tarefa aberta: {len(pend)}")


if __name__ == "__main__":
    main()
