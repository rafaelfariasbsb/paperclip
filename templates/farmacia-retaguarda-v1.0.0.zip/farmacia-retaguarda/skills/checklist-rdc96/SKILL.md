---
name: checklist-rdc96
description: "Checklist de conformidade da RDC 96/2008 para qualquer post, oferta, status de WhatsApp ou material de divulgação de medicamentos e serviços."
---

# Checklist RDC 96/2008 (propaganda de medicamentos)

Preencha para **cada peça** e anexe ao rascunho. Se algum item der "NÃO OK", corrija antes de mandar para aprovação.

| # | Verificação | OK? |
|---|---|---|
| 1 | Não anuncia medicamento de venda sob prescrição (tarjado) nem controlado ao público | |
| 2 | Não usa imperativo para medicamento ("tome", "use", "experimente") | |
| 3 | Não promete cura, resultado garantido ou ausência de efeitos colaterais | |
| 4 | Oferta de medicamento mostra também o preço integral (não só o desconto) | |
| 5 | Medicamento não é prêmio, brinde, sorteio, troca ou pontos de fidelidade | |
| 6 | MIP traz a advertência obrigatória ("SE PERSISTIREM OS SINTOMAS, O MÉDICO DEVERÁ SER CONSULTADO" ou a vigente) | |
| 7 | Não usa depoimento de paciente nem imagem que sugira diagnóstico | |
| 8 | Não condiciona preço a CPF ou cadastro (LGPD) | |
| 9 | Serviço clínico divulgado consta da licença sanitária e do CNES da loja | |
| 10 | Conteúdo técnico revisado pelo farmacêutico `[RT]` | |

HPC e perfumaria seguem as regras gerais do Código de Defesa do Consumidor (preço claro, sem promessa enganosa).

Os artigos de referência estão na RDC 96/2008 (texto consolidado) **[conferir alterações posteriores]**. A venda remota e por marketplaces está em regulamentação pela Anvisa desde 2026 (Lei 15.357/2026). **[verificar norma vigente antes de campanhas digitais de medicamento]**
