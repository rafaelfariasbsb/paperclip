---
name: monitor-recall
description: "Cruzar recolhimentos, suspensões e apreensões publicados pela Anvisa com os lotes em estoque."
---

# Monitor de recall

1. Consulte as publicações oficiais de recolhimento, suspensão e apreensão de medicamentos e produtos (portal da Anvisa e Diário Oficial da União) desde a última verificação.
2. Compare produto e lote com `lotes.csv`.
3. Se houver lote afetado em estoque: abra tarefa urgente `[RT]` para segregar e bloquear a venda, com o link da publicação.
4. Se não houver: registre "sem lotes afetados" com a data da verificação.

Use apenas fontes oficiais e sempre informe o link. Se não conseguir acessar a fonte, diga isso. Não assuma que não houve recall.
