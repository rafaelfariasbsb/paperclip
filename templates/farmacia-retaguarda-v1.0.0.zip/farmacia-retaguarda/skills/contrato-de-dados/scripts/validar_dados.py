#!/usr/bin/env python3
"""Confere se os arquivos de entrada seguem o contrato de dados do template.
Uso: python3 validar_dados.py <pasta_de_dados>
Saida: relatorio em Markdown no stdout. Codigo de saida 1 se faltar arquivo obrigatorio.
"""
import csv, os, sys

CONTRATO = {
    # arquivo: (obrigatorio?, colunas obrigatorias, agente que usa)
    "produtos_estoque.csv": (True, ["sku", "descricao", "categoria", "estoque", "custo_unit", "preco_venda", "pmc",
                                     "embalagem_compra", "lead_time_dias", "fornecedor_preferencial", "controlado"], "comprador, precos"),
    "vendas_itens.csv": (True, ["data", "cupom", "sku", "quantidade", "valor_total", "forma_pagamento"], "todos"),
    "lotes.csv": (False, ["sku", "lote", "validade", "quantidade"], "comprador"),
    "pedidos_pendentes.csv": (False, ["sku", "quantidade_pendente"], "comprador"),
    "caixa_erp.csv": (False, ["data", "forma_pagamento", "valor"], "controller"),
    "extrato_recebimentos.csv": (False, ["data", "forma_pagamento", "valor_bruto", "taxa", "valor_liquido"], "controller"),
    "contas_pagar.csv": (False, ["vencimento", "fornecedor", "descricao", "valor", "status"], "controller"),
    "saldos.csv": (False, ["data", "conta", "saldo"], "controller"),
    "recebiveis_futuros.csv": (False, ["data_prevista", "origem", "valor"], "controller"),
    "documentos.csv": (False, ["documento", "orgao", "numero", "validade", "responsavel"], "sentinela"),
    "horario_funcionamento.csv": (False, ["dia_semana", "abre", "fecha"], "sentinela"),
    "escala.csv": (False, ["data", "inicio", "fim", "farmaceutico", "crf"], "sentinela"),
    "temperatura.csv": (False, ["data_hora", "local", "temperatura", "umidade"], "sentinela"),
    "faixas_temperatura.csv": (False, ["local", "min", "max", "umidade_max"], "sentinela"),
    "precos_concorrencia.csv": (False, ["sku", "concorrente", "preco", "data"], "precos"),
    "consentimentos.csv": (False, ["cliente_id", "opt_in_recompra", "data_consentimento", "canal", "descadastrado"], "relacionamento"),
    "duracao_tratamento.csv": (False, ["sku", "dias_por_embalagem"], "relacionamento"),
}


def main():
    pasta = sys.argv[1] if len(sys.argv) > 1 else "."
    faltando_obrig = False
    print(f"# Validacao do contrato de dados\n\nPasta: `{pasta}`\n")
    print("| Arquivo | Situacao | Linhas | Usado por | Observacao |\n|---|---|---|---|---|")
    for nome, (obrig, cols, uso) in CONTRATO.items():
        caminho = os.path.join(pasta, nome)
        if not os.path.exists(caminho):
            sit = "FALTA (obrigatorio)" if obrig else "ausente (opcional)"
            faltando_obrig |= obrig
            print(f"| {nome} | {sit} | - | {uso} | rotinas que dependem dele ficam desligadas |")
            continue
        with open(caminho, encoding="utf-8-sig", newline="") as f:
            amostra = f.read(4096)
            f.seek(0)
            sep = ";" if amostra.count(";") >= amostra.count(",") else ","
            leitor = csv.DictReader(f, delimiter=sep)
            cab = [c.strip().lower() for c in (leitor.fieldnames or [])]
            n = sum(1 for _ in leitor)
        falt = [c for c in cols if c not in cab]
        sit = "OK" if not falt else "COLUNAS FALTANDO"
        obs = ("faltam: " + ", ".join(falt)) if falt else (f"separador '{sep}'" + (" (preferir ';')" if sep != ";" else ""))
        if falt and obrig:
            faltando_obrig = True
        print(f"| {nome} | {sit} | {n} | {uso} | {obs} |")
    print("\nResultado:", "BLOQUEADO - corrigir arquivos obrigatorios" if faltando_obrig else "OK para rodar as rotinas")
    sys.exit(1 if faltando_obrig else 0)


if __name__ == "__main__":
    main()
