---
name: contrato-de-dados
description: "Formato dos arquivos de entrada (CSV do ERP, extratos e planilhas), o arquivo config-farmacia.md e o script de validação. Use antes de qualquer cálculo."
---

# Contrato de dados

Todos os agentes leem a pasta da variável `FARMACIA_DADOS`:

```
$FARMACIA_DADOS/
├── config-farmacia.md     # configuração, criada pelo agente de implantação
├── entrada/               # exportações do ERP e planilhas (atualizadas pela equipe)
└── saida/                 # relatórios e rascunhos gerados pelos agentes
```

## Formato
CSV em UTF-8, com cabeçalho na primeira linha. O separador preferido é `;`, mas os scripts também aceitam `,`. Números podem vir com vírgula decimal (`12,90`). Datas no formato `AAAA-MM-DD`.

| Arquivo | Obrigatório | Colunas |
|---|---|---|
| produtos_estoque.csv | sim | sku; descricao; categoria (GEN, REF, SIM, MIP, HPC, CTRL); estoque; custo_unit; preco_venda; pmc (0 se não tiver); embalagem_compra; lead_time_dias; fornecedor_preferencial; controlado (S/N) |
| vendas_itens.csv | sim | data; cupom; sku; quantidade; valor_total; forma_pagamento; cliente_id (opcional; só com opt-in) |
| lotes.csv | não | sku; lote; validade; quantidade |
| pedidos_pendentes.csv | não | sku; quantidade_pendente |
| caixa_erp.csv | não | data; forma_pagamento; valor |
| extrato_recebimentos.csv | não | data; forma_pagamento; valor_bruto; taxa; valor_liquido |
| contas_pagar.csv | não | vencimento; fornecedor; descricao; valor; status (ABERTO/PAGO) |
| saldos.csv / recebiveis_futuros.csv | não | data; conta; saldo / data_prevista; origem; valor |
| documentos.csv | não | documento; orgao; numero; validade; responsavel |
| horario_funcionamento.csv / escala.csv | não | dia_semana; abre; fecha / data; inicio; fim; farmaceutico; crf |
| temperatura.csv / faixas_temperatura.csv | não | data_hora; local; temperatura; umidade / local; min; max; umidade_max |
| precos_concorrencia.csv | não | sku; concorrente; preco; data |
| consentimentos.csv / duracao_tratamento.csv | não | cliente_id; opt_in_recompra; data_consentimento; canal; descadastrado / sku; dias_por_embalagem |

Se faltar um arquivo opcional, a rotina que depende dele avisa e não roda. **Nunca invente dado.**

## Validação
`python3 scripts/validar_dados.py "$FARMACIA_DADOS/entrada"` gera um relatório e devolve código 1 se faltar arquivo obrigatório.

## Modelo do config-farmacia.md
```
# Configuração da farmácia
- Nome fantasia:
- Cidade/UF:
- Horário de funcionamento:
- RT (nome/CRF, só exibição):            Substitutos:
- ERP:                                    Quem exporta:
- Farmácia Popular: sim/não               Serviços: pressão/glicemia/vacina/testes
- Delivery: sim/não                       WhatsApp: sim/não
- Distribuidoras e horário de corte:
- Limite de aprovação de compra (R$): todos (fase inicial)
- Margem mínima: 20%                      Cobertura-alvo: 10 dias        Segurança: 3 dias
- Janelas de vencido: 120/90/60           Alertas de documentos: 60/30/7
- RT acessa o Paperclip: sim/não
```

## Conectores por ERP
Cada ERP exporta com nomes de coluna diferentes. Um conector é um roteiro mais um script que converte a exportação do ERP para este contrato. Enquanto não houver conector, a equipe ajusta o cabeçalho no Excel antes de salvar.
