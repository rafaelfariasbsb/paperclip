#!/usr/bin/env python3
"""Curva ABC por faturamento, lista de contagem rotativa e estoque parado.
A = itens que somam ate 70% do faturamento; B = ate 90%; C = restante (parametrizavel).
Contagem rotativa: todos os A ate o limite + amostra de B/C, priorizando controlados e alto valor.
Parado: itens com estoque > 0 e sem venda ha mais de N dias (padrao 90).
Uso: python3 curva_abc.py <pasta_dados> [--hoje AAAA-MM-DD] [--dias 90] [--contagem 60] [--parado 90]
"""
import argparse, csv, os, random
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def brl(v):
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--dias", type=int, default=90)
    ap.add_argument("--contagem", type=int, default=60)
    ap.add_argument("--parado", type=int, default=90)
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    ini = (hoje - timedelta(days=a.dias)).isoformat()
    prods = {p["sku"]: p for p in ler(a.pasta, "produtos_estoque.csv")}
    fat, ultima = defaultdict(float), {}
    for r in ler(a.pasta, "vendas_itens.csv"):
        if r["data"] >= ini:
            fat[r["sku"]] += num(r["valor_total"])
        ultima[r["sku"]] = max(ultima.get(r["sku"], ""), r["data"])
    total = sum(fat.values()) or 1
    acum, classe = 0.0, {}
    for sku, v in sorted(fat.items(), key=lambda x: -x[1]):
        acum += v
        classe[sku] = "A" if acum / total <= 0.70 or not classe else ("B" if acum / total <= 0.90 else "C")
    for sku in prods:
        classe.setdefault(sku, "C")

    print(f"# Curva ABC e estoque - {hoje}\n")
    for c in "ABC":
        itens = [s for s in prods if classe[s] == c]
        v = sum(fat[s] for s in itens)
        print(f"- Classe {c}: {len(itens)} itens, {brl(v)} ({v / total:.0%} do faturamento em {a.dias} dias)")

    # contagem rotativa
    random.seed(hoje.toordinal())
    prioridade = sorted(prods, key=lambda s: (classe[s] != "A", prods[s]["controlado"].upper() != "S",
                                              -num(prods[s]["estoque"]) * num(prods[s]["custo_unit"])))
    lista = prioridade[: a.contagem]
    print(f"\n## Lista de contagem rotativa da semana ({len(lista)} itens)\n")
    print("Regra: se a divergencia (|fisico - sistema| / sistema) passar de 1% na amostra, pedir inventario completo.\n")
    print("| SKU | Produto | Classe | Estoque no sistema | Contado | Observacao |\n|---|---|---|---|---|---|")
    for s in lista:
        obs = "controlado - contagem com o RT" if prods[s]["controlado"].upper() == "S" else ""
        print(f"| {s} | {prods[s]['descricao']} | {classe[s]} | {prods[s]['estoque']} |  | {obs} |")

    # parado
    limite = (hoje - timedelta(days=a.parado)).isoformat()
    parados = [(s, p) for s, p in prods.items() if num(p["estoque"]) > 0 and ultima.get(s, "0000") < limite]
    print(f"\n## Estoque parado (sem venda ha mais de {a.parado} dias)\n")
    if not parados:
        print("Nenhum item.")
    tot = 0.0
    for s, p in parados:
        v = num(p["estoque"]) * num(p["custo_unit"]); tot += v
        print(f"- {s} {p['descricao']}: {p['estoque']} un, {brl(v)} a custo, ultima venda: {ultima.get(s, 'sem registro')}")
    if parados:
        print(f"\nTotal parado a custo: {brl(tot)}")


if __name__ == "__main__":
    main()
