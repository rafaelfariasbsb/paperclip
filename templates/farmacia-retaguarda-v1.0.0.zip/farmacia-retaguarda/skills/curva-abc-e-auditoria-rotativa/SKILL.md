---
name: curva-abc-e-auditoria-rotativa
description: "Curva ABC por faturamento, lista semanal de contagem rotativa (50–100 SKUs) e identificação de estoque parado acima de 90 dias."
---

# Curva ABC e auditoria rotativa

`python3 scripts/curva_abc.py "$FARMACIA_DADOS/entrada" --contagem 60 --parado 90`

- **Classes:** A até 70% do faturamento, B até 90%, C o restante.
- **Contagem rotativa:** 50 a 100 itens por semana, com prioridade para a curva A, controlados (contados com o RT) e itens de alto valor ou alto risco de furto. Se a divergência na amostra passar de 1%, peça inventário completo (referência publicada por fornecedor de ERP; **calibrar**).
- **Parado:** estoque sem venda há mais de 90 dias. Sugira ação ao dono: devolução negociada, remanejamento ou liquidação dentro da RDC 96.
