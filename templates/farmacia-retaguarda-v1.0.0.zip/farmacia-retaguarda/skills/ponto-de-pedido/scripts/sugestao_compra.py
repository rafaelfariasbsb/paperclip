#!/usr/bin/env python3
"""Sugestao de compra pelo ponto de pedido (RASCUNHO - nunca envia pedido).
Regra: VMD = vendas dos ultimos N dias / N
       ponto_de_pedido = VMD x lead_time + estoque_seguranca (VMD x dias_seguranca)
       maximo = VMD x (lead_time + cobertura_alvo)
       se estoque + pendente <= ponto_de_pedido -> comprar (maximo - estoque - pendente), arredondado pela embalagem
Controlados (controlado=S) so sao SINALIZADOS: a compra/ajuste e decisao do RT.
Uso: python3 sugestao_compra.py <pasta_dados> [--hoje AAAA-MM-DD] [--dias 30] [--seguranca 3] [--cobertura 10] [--csv saida.csv]
"""
import argparse, csv, math, os
from collections import defaultdict
from datetime import date, timedelta


def num(v):
    v = (v or "").strip().replace("R$", "").replace(" ", "")
    if "," in v:
        v = v.replace(".", "").replace(",", ".")
    return float(v) if v else 0.0


def ler(pasta, nome):
    p = os.path.join(pasta, nome)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig", newline="") as f:
        amostra = f.read(4096); f.seek(0)
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        return [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--hoje", default=date.today().isoformat())
    ap.add_argument("--dias", type=int, default=30)
    ap.add_argument("--seguranca", type=float, default=3)
    ap.add_argument("--cobertura", type=float, default=10)
    ap.add_argument("--csv")
    a = ap.parse_args()
    hoje = date.fromisoformat(a.hoje)
    ini = (hoje - timedelta(days=a.dias)).isoformat()

    vendido = defaultdict(float)
    for r in ler(a.pasta, "vendas_itens.csv"):
        if ini <= r["data"] < hoje.isoformat():
            vendido[r["sku"]] += num(r["quantidade"])
    pend = {r["sku"]: num(r["quantidade_pendente"]) for r in ler(a.pasta, "pedidos_pendentes.csv")}

    linhas, alertas_ctrl, total = [], [], 0.0
    for p in ler(a.pasta, "produtos_estoque.csv"):
        sku = p["sku"]
        vmd = vendido[sku] / a.dias
        if vmd <= 0:
            continue
        est, pen = num(p["estoque"]), pend.get(sku, 0)
        lead = num(p["lead_time_dias"]) or 1
        emb = max(1, int(num(p["embalagem_compra"]) or 1))
        pp = vmd * lead + vmd * a.seguranca
        maximo = vmd * (lead + a.cobertura)
        if est + pen > pp:
            continue
        if p["controlado"].upper() == "S":
            alertas_ctrl.append((sku, p["descricao"], est, round(pp, 1)))
            continue
        qtd = math.ceil(max(0, maximo - est - pen) / emb) * emb
        if qtd <= 0:
            continue
        custo = qtd * num(p["custo_unit"])
        total += custo
        linhas.append([p["fornecedor_preferencial"], sku, p["descricao"], round(vmd, 2), est, pen, round(pp, 1),
                       qtd, round(custo, 2), "RUPTURA" if est == 0 else ""])

    linhas.sort(key=lambda l: (l[0], l[9] != "RUPTURA", -l[8]))
    print(f"# Sugestao de compra (rascunho) - {hoje}\n")
    print(f"Parametros: historico {a.dias} dias, seguranca {a.seguranca} dias, cobertura-alvo {a.cobertura} dias.\n")
    print("> RASCUNHO. Nenhum pedido foi enviado. Aprovacao do dono obrigatoria.\n")
    print("| Fornecedor | SKU | Produto | VMD | Estoque | Pendente | Ponto de pedido | Comprar | Custo R$ | Alerta |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    for l in linhas:
        cel = [str(x).replace(".", ",") if isinstance(x, float) else str(x) for x in l]
        print("| " + " | ".join(cel) + " |")
    print(f"\n**Total estimado:** R$ {total:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    if alertas_ctrl:
        print("\n## Controlados abaixo do ponto de pedido (somente sinalizacao - decisao do RT)\n")
        for sku, d, est, pp in alertas_ctrl:
            print(f"- {sku} {d}: estoque {est}, ponto de pedido {pp}")
    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["fornecedor", "sku", "descricao", "vmd", "estoque", "pendente", "ponto_pedido", "comprar", "custo", "alerta"])
            w.writerows(linhas)


if __name__ == "__main__":
    main()
