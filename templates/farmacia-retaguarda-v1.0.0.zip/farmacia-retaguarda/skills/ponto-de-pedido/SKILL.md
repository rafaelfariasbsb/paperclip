---
name: ponto-de-pedido
description: "Cálculo da sugestão diária de compra por ponto de pedido, estoque de segurança e cobertura-alvo, por distribuidora."
---

# Ponto de pedido

```
VMD             = vendas dos últimos 30 dias ÷ 30
ponto de pedido = VMD × lead time + VMD × dias de segurança
máximo          = VMD × (lead time + cobertura-alvo)
comprar         = máximo − estoque − pendente   (arredondado para cima pela embalagem)
```

`python3 scripts/sugestao_compra.py "$FARMACIA_DADOS/entrada" --cobertura 10 --seguranca 3 --csv "$FARMACIA_DADOS/saida/pedido_AAAA-MM-DD.csv"`

## Regras
- A cobertura-alvo e a segurança vêm de `config-farmacia.md`. A referência publicada é revisar o estoque máximo acima de 10 dias de cobertura e ter cerca de 15 dias com reposição semanal (material da indústria). **Calibre com a farmácia.**
- Rupturas da curva A vêm no topo.
- Controlados só são **sinalizados** ao RT.
- A saída é **rascunho**. O pedido é enviado por uma pessoa depois da aprovação do dono.
