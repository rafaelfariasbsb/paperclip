---
name: lgpd-dados-saude
description: "Regras de LGPD para dados de clientes da farmácia: dado de saúde é sensível, opt-in específico, minimização, descadastro e proibição de condicionar desconto a CPF."
---

# LGPD na farmácia

- Histórico de compra de medicamento é **dado pessoal sensível**, porque revela informação de saúde.
- Só use dados de clientes com **consentimento específico registrado** em `consentimentos.csv` para a finalidade "recompra".
- **Minimização:** use o identificador do cliente e o produto. Não use diagnóstico nem receita.
- Toda mensagem deve oferecer uma forma fácil de sair da lista ("responda SAIR"). Registre o descadastro.
- **Nunca condicione preço ou desconto a CPF ou cadastro.** O preço promocional vale para todos. A ANPD e os Procons já atuaram nesse ponto. Em 2026, uma sentença de 1ª instância no Maranhão condenou uma rede em R$ 10 milhões por dano moral coletivo, com base sobretudo no Código de Defesa do Consumidor; cabe recurso.
- O consentimento para usar o histórico de compras deve ser **específico e destacado** (LGPD, art. 11, I), separado de qualquer desconto ou cadastro de fidelidade.
- O provedor de IA e o WhatsApp também tratam dados. É preciso contrato de operador e atenção à transferência internacional.
- Não envie dados de clientes a serviços externos sem contrato de operador. Isso inclui a IA usada pelos agentes: o dono deve conferir o contrato do provedor.
- Pedidos de titulares (acesso, correção, exclusão) vão para o dono `[DONO]`.

Isto não é parecer jurídico. Recomende ao dono validar a base legal com um advogado.
