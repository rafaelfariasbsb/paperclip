---
name: segregacao-monofasico-st
description: "Pré-conferência mensal para o contador da segregação de receitas com PIS/COFINS monofásico e ICMS-ST no Simples Nacional (PGDAS-D)."
---

# Pré-conferência monofásico e ICMS-ST

**Objetivo:** evitar que a farmácia pague em duplicidade tributos já recolhidos na indústria (PIS/COFINS monofásico) ou por substituição tributária (ICMS-ST). Esse é um erro recorrente no Simples Nacional.

## Rotina mensal (até o dia 5)
1. Some as vendas do mês por grupo de NCM, se o ERP exportar o NCM.
2. Compare com a segregação declarada no PGDAS-D do mês anterior (o contador envia o extrato).
3. Entregue ao contador um memorando com as diferenças encontradas, **como pergunta, não como conclusão**.

## Atenção
- A lista de NCMs monofásicos e as regras de ST variam e devem ser **confirmadas pelo contador**.
- A reforma tributária (LC 214/2025) muda o cenário: CBS a partir de 2027, IBS gradual, e a transição do ICMS até 2033. **[revisar a cada atualização do pacote]**
- O agente não retifica, não transmite e não decide.
