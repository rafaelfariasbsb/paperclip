# Farmácia – Retaguarda com IA (template Paperclip) · v1.0.0

Uma empresa pronta de agentes de IA para drogaria independente. Os agentes fazem o trabalho de planilha e calendário que o dono e o farmacêutico não têm tempo de fazer. **Quem decide é sempre um humano.**

## O que vem no pacote
- **8 agentes:**
  - gerente-geral;
  - implantação;
  - sentinela regulatória;
  - comprador e estoque;
  - controller financeiro;
  - analista de preços;
  - relacionamento com clientes;
  - marketing e conteúdo.
- **21 skills** com as regras do setor (RDC 44, SNGPC/SNCR, Farmácia Popular, RDC 96, LGPD, CMED, monofásico/ST) e **10 scripts de cálculo** em Python, sem dependências externas.
- **23 rotinas** (diárias, semanais, mensais e anuais) e 2 tarefas iniciais.
- **Dados de exemplo fictícios** (`assets/dados-exemplo/`) para demonstração.

## Instalação
1. Paperclip instalado (no Windows, use o instalador de um comando).
2. No Paperclip, abra **Configurações da empresa → Import** e envie o `.zip` deste pacote.
   - Deixe marcado **"Start imported agents and routines paused"**.
   - Escolha o tipo de agente (adapter). O pacote vem com `claude_local`.
3. Preencha `FARMACIA_DADOS` com a pasta de dados da farmácia, por exemplo `C:\Paperclip\farmacia`. Ela deve ter as subpastas `entrada` e `saida`.
4. Ative só o agente **Implantação** e a tarefa "Implantação: configurar a farmácia". Ele entrevista o dono, valida os dados e monta a planilha de documentos.
5. Com a implantação concluída, ative os demais agentes e rotinas. Comece por gerente-geral, sentinela, comprador e controller.

> **Importe pela tela, enviando o `.zip`.** A importação pela linha de comando (`paperclipai company import`) só leva arquivos `.md` e descarta os scripts `.py` das skills (testado na versão 2026.1117.0). Sem os scripts, os agentes não fazem os cálculos.

## Dados
A equipe da farmácia exporta os relatórios do ERP para `entrada/` no formato da skill `contrato-de-dados`. Para conferir, rode:
`python3 skills/contrato-de-dados/scripts/validar_dados.py <pasta>/entrada`

Para demonstrar sem dados reais, aponte `FARMACIA_DADOS` para uma pasta com `assets/dados-exemplo` copiado como `entrada`. Para regenerar os dados com a data de hoje:
`python3 assets/gerar_dados_exemplo.py <pasta>/entrada`

## Limites (importante para a venda)
- Não substitui o farmacêutico. Dispensação, avaliação de receita, indicação de medicamento, serviços clínicos e SNGPC/SNCR continuam com ele.
- Não envia, não paga, não publica e não altera o ERP. Entrega rascunhos para aprovação.
- Não guarda senhas nem credenciais.
- Usa dados de clientes só com consentimento específico (LGPD).
- **Custo:** os agentes usam IA paga pelo cliente (assinatura ou chave de API). Os orçamentos por agente vêm baixos (`budgetMonthlyCents`) e devem ser ajustados no Paperclip.
- Não é parecer jurídico, contábil ou sanitário. As regras marcadas **[conferir]** devem ser confirmadas na implantação.

## Atualizações
Veja `CHANGELOG.md`. A assinatura de atualizações traz as mudanças normativas (CMED anual, Anvisa, Farmácia Popular, reforma tributária) em novas versões do pacote.
