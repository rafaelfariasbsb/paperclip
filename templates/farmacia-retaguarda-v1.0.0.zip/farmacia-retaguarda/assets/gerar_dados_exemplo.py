#!/usr/bin/env python3
"""Gera dados FICTICIOS de uma drogaria para demonstracao e teste do template.
Todos os nomes, clientes e numeros sao inventados. Formato: CSV UTF-8, separador ';', decimal ','.
Uso: python3 gerar_dados_exemplo.py <pasta_saida> [AAAA-MM-DD hoje]
"""
import csv, os, random, sys
from datetime import date, datetime, timedelta

random.seed(42)
out = sys.argv[1]
hoje = date.fromisoformat(sys.argv[2]) if len(sys.argv) > 2 else date.today()
os.makedirs(out, exist_ok=True)

def br(v):  # decimal com virgula
    return f"{v:.2f}".replace(".", ",")

def w(nome, cab, linhas):
    with open(os.path.join(out, nome), "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f, delimiter=";")
        wr.writerow(cab)
        wr.writerows(linhas)

# --- catalogo ---------------------------------------------------------------
# (sku, descricao, categoria, custo, preco, pmc, embalagem, lead, fornecedor, controlado, venda_dia_media)
cat = [
    ("1001", "Losartana 50mg 30cp (generico)", "GEN", 4.10, 12.90, 31.50, 10, 1, "Distribuidora Alfa", "N", 9.0),
    ("1002", "Metformina 850mg 30cp (generico)", "GEN", 3.20, 9.90, 22.40, 10, 1, "Distribuidora Alfa", "N", 7.5),
    ("1003", "Atenolol 25mg 30cp (generico)", "GEN", 2.80, 8.50, 19.80, 10, 1, "Distribuidora Beta", "N", 4.0),
    ("1004", "Sinvastatina 20mg 30cp (generico)", "GEN", 5.40, 15.90, 38.70, 10, 2, "Distribuidora Beta", "N", 3.5),
    ("1005", "Omeprazol 20mg 28cp (generico)", "GEN", 3.90, 11.90, 29.10, 10, 1, "Distribuidora Alfa", "N", 6.0),
    ("1006", "Hidroclorotiazida 25mg 30cp (generico)", "GEN", 1.90, 6.90, 14.20, 10, 1, "Distribuidora Alfa", "N", 3.0),
    ("1007", "Anlodipino 5mg 30cp (generico)", "GEN", 3.10, 10.90, 24.60, 10, 2, "Distribuidora Beta", "N", 3.2),
    ("2001", "Marca Referencia Anti-hipertensivo 30cp", "REF", 58.00, 79.90, 82.30, 5, 2, "Distribuidora Beta", "N", 1.2),
    ("2002", "Marca Referencia Antidiabetico 60cp", "REF", 72.50, 99.90, 98.40, 5, 2, "Distribuidora Beta", "N", 0.8),
    ("3001", "Dipirona 500mg 10cp (similar)", "SIM", 2.10, 6.50, 9.80, 20, 1, "Distribuidora Alfa", "N", 6.5),
    ("4001", "Paracetamol 750mg 20cp (MIP)", "MIP", 4.30, 12.90, 15.60, 12, 1, "Distribuidora Alfa", "N", 5.0),
    ("4002", "Antigripal composto 20cp (MIP)", "MIP", 9.80, 24.90, 29.90, 12, 1, "Distribuidora Alfa", "N", 2.5),
    ("4003", "Soro fisiologico 500ml (MIP)", "MIP", 3.50, 8.90, 11.20, 12, 1, "Distribuidora Beta", "N", 2.0),
    ("5001", "Protetor solar FPS50 200ml", "HPC", 32.00, 69.90, 0, 6, 3, "Distribuidora Gama", "N", 0.7),
    ("5002", "Shampoo anticaspa 200ml", "HPC", 14.00, 32.90, 0, 6, 3, "Distribuidora Gama", "N", 0.6),
    ("5003", "Fralda infantil G 30un", "HPC", 38.00, 64.90, 0, 4, 2, "Distribuidora Gama", "N", 1.1),
    ("5004", "Hidratante corporal 400ml", "HPC", 18.00, 39.90, 0, 6, 3, "Distribuidora Gama", "N", 0.0),
    ("6001", "Clonazepam 2mg 30cp (controlado)", "CTRL", 6.20, 18.90, 24.10, 5, 2, "Distribuidora Beta", "S", 1.0),
    ("6002", "Amoxicilina 500mg 21cap (antimicrobiano)", "CTRL", 9.40, 24.90, 31.80, 5, 1, "Distribuidora Alfa", "S", 1.5),
]
# estoque proposital: alguns abaixo do ponto de pedido, um zerado, um parado
estoque_atual = {"1001": 6, "1002": 40, "1003": 0, "1004": 12, "1005": 55, "1006": 20, "1007": 9,
                 "2001": 6, "2002": 3, "3001": 90, "4001": 30, "4002": 4, "4003": 22,
                 "5001": 10, "5002": 8, "5003": 6, "5004": 14, "6001": 7, "6002": 10}
w("produtos_estoque.csv",
  ["sku", "descricao", "categoria", "estoque", "custo_unit", "preco_venda", "pmc",
   "embalagem_compra", "lead_time_dias", "fornecedor_preferencial", "controlado"],
  [[s, d, c, estoque_atual[s], br(cu), br(pv), br(pmc), emb, lt, forn, ctl]
   for s, d, c, cu, pv, pmc, emb, lt, forn, ctl, _ in cat])

# lotes / validade (inclui quase-vencidos e um vencido)
lotes = []
for s, *_ in cat:
    q = estoque_atual[s]
    if q == 0:
        continue
    lotes.append([s, f"L{s}A", (hoje + timedelta(days=random.randint(200, 700))).isoformat(), q])
lotes[3][2] = (hoje + timedelta(days=45)).isoformat()    # 60 dias
lotes[9][2] = (hoje + timedelta(days=85)).isoformat()    # 90 dias
lotes[13][2] = (hoje + timedelta(days=110)).isoformat()  # 120 dias
lotes[15][2] = (hoje - timedelta(days=3)).isoformat()    # vencido
w("lotes.csv", ["sku", "lote", "validade", "quantidade"], lotes)

# vendas dos ultimos 60 dias
clientes = [f"C{n:04d}" for n in range(1, 41)]
vendas, cupom = [], 50000
formas = ["CREDITO", "DEBITO", "PIX", "DINHEIRO"]
caixa = {}
for k in range(60, 0, -1):
    dia = hoje - timedelta(days=k)
    for s, d, c, cu, pv, pmc, emb, lt, forn, ctl, vmd in cat:
        if s == "5004":
            continue  # item parado
        qtd = max(0, round(random.gauss(vmd, vmd * 0.4))) if vmd else 0
        while qtd > 0:
            q = min(qtd, random.choice([1, 1, 1, 2]))
            qtd -= q
            cupom += 1
            fp = random.choice(formas)
            cli = random.choice(clientes) if c in ("GEN", "REF") and random.random() < 0.6 else ""
            vendas.append([dia.isoformat(), cupom, s, q, br(q * pv), fp, cli])
            caixa[(dia.isoformat(), fp)] = caixa.get((dia.isoformat(), fp), 0) + q * pv
w("vendas_itens.csv", ["data", "cupom", "sku", "quantidade", "valor_total", "forma_pagamento", "cliente_id"], vendas)

w("pedidos_pendentes.csv", ["sku", "quantidade_pendente"], [["1004", 10], ["2002", 5]])

# conciliacao: ERP x extrato da adquirente (ontem), com 1 divergencia
ontem = (hoje - timedelta(days=1)).isoformat()
w("caixa_erp.csv", ["data", "forma_pagamento", "valor"],
  [[d, fp, br(v)] for (d, fp), v in sorted(caixa.items()) if d >= (hoje - timedelta(days=7)).isoformat()])
ext = []
for (d, fp), v in sorted(caixa.items()):
    if d < (hoje - timedelta(days=7)).isoformat() or fp == "DINHEIRO":
        continue
    bruto = v - (37.80 if (d == ontem and fp == "CREDITO") else 0)
    taxa = {"CREDITO": 0.0299, "DEBITO": 0.0129, "PIX": 0.0}[fp]
    ext.append([d, fp, br(bruto), br(bruto * taxa), br(bruto * (1 - taxa))])
w("extrato_recebimentos.csv", ["data", "forma_pagamento", "valor_bruto", "taxa", "valor_liquido"], ext)

w("contas_pagar.csv", ["vencimento", "fornecedor", "descricao", "valor", "status"], [
    [(hoje + timedelta(days=3)).isoformat(), "Distribuidora Alfa", "Boleto NF 1234", br(4280.50), "ABERTO"],
    [(hoje + timedelta(days=6)).isoformat(), "Imobiliaria", "Aluguel", br(6500.00), "ABERTO"],
    [(hoje + timedelta(days=10)).isoformat(), "Distribuidora Beta", "Boleto NF 8891", br(5120.00), "ABERTO"],
    [(hoje + timedelta(days=12)).isoformat(), "Folha", "Salarios (total)", br(14800.00), "ABERTO"],
    [(hoje + timedelta(days=20)).isoformat(), "Receita Federal", "DAS Simples Nacional", br(3900.00), "ABERTO"],
    [(hoje + timedelta(days=25)).isoformat(), "Distribuidora Gama", "Boleto NF 552", br(2300.00), "ABERTO"],
])
w("saldos.csv", ["data", "conta", "saldo"], [[hoje.isoformat(), "Banco principal", br(18650.00)]])
w("recebiveis_futuros.csv", ["data_prevista", "origem", "valor"], [
    [(hoje + timedelta(days=2)).isoformat(), "Cartao credito", br(5200.00)],
    [(hoje + timedelta(days=9)).isoformat(), "Cartao credito", br(4800.00)],
    [(hoje + timedelta(days=16)).isoformat(), "PBM / convenios", br(1900.00)],
])

w("documentos.csv", ["documento", "orgao", "numero", "validade", "responsavel"], [
    ["Licenca sanitaria", "Vigilancia Sanitaria municipal", "LS-0001", (hoje + timedelta(days=25)).isoformat(), "Dono"],
    ["Certidao de Regularidade Tecnica", "CRF", "CRT-0002", (hoje + timedelta(days=55)).isoformat(), "RT"],
    ["Alvara de funcionamento", "Prefeitura", "ALV-0003", (hoje + timedelta(days=300)).isoformat(), "Dono"],
    ["AVCB / Licenca bombeiros", "Corpo de Bombeiros", "AVCB-0004", (hoje + timedelta(days=5)).isoformat(), "Dono"],
    ["Certificado de dedetizacao", "Empresa controladora de pragas", "DD-0005", (hoje - timedelta(days=2)).isoformat(), "Dono"],
    ["Habilitacao Farmacia Popular", "Ministerio da Saude", "FP-0006", (hoje + timedelta(days=400)).isoformat(), "Dono"],
])

w("horario_funcionamento.csv", ["dia_semana", "abre", "fecha"],
  [["seg", "07:00", "22:00"], ["ter", "07:00", "22:00"], ["qua", "07:00", "22:00"], ["qui", "07:00", "22:00"],
   ["sex", "07:00", "22:00"], ["sab", "08:00", "20:00"], ["dom", "", ""]])
esc = []
dias = ["seg", "ter", "qua", "qui", "sex", "sab", "dom"]
for k in range(0, 14):
    dia = hoje + timedelta(days=k)
    ds = dias[dia.weekday()]
    if ds == "dom":
        continue
    if ds == "sab":
        esc.append([dia.isoformat(), "08:00", "20:00", "Farmaceutica A", "CRF-XX 0000"])
        continue
    esc.append([dia.isoformat(), "07:00", "15:00", "Farmaceutica A", "CRF-XX 0000"])
    fim = "21:00" if k == 2 else "22:00"   # lacuna proposital de 1 hora
    esc.append([dia.isoformat(), "14:00", fim, "Farmaceutico B", "CRF-XX 0001"])
w("escala.csv", ["data", "inicio", "fim", "farmaceutico", "crf"], esc)

temps = []
for k in range(2, 0, -1):
    dia = hoje - timedelta(days=k)
    for h in (8, 13, 18):
        t_amb = round(random.uniform(21, 27), 1)
        if k == 1 and h == 13:
            t_amb = 31.4   # desvio proposital
        temps.append([f"{dia.isoformat()} {h:02d}:00", "Ambiente", str(t_amb).replace(".", ","), random.randint(45, 65)])
        t_gel = round(random.uniform(3, 7), 1)
        temps.append([f"{dia.isoformat()} {h:02d}:00", "Geladeira", str(t_gel).replace(".", ","), ""])
w("temperatura.csv", ["data_hora", "local", "temperatura", "umidade"], temps)
w("faixas_temperatura.csv", ["local", "min", "max", "umidade_max"], [["Ambiente", "15", "30", "70"], ["Geladeira", "2", "8", ""]])

w("precos_concorrencia.csv", ["sku", "concorrente", "preco", "data"], [
    ["1001", "Concorrente 1", br(10.90), hoje.isoformat()], ["1001", "Concorrente 2", br(11.50), hoje.isoformat()],
    ["1002", "Concorrente 1", br(9.90), hoje.isoformat()], ["1005", "Concorrente 1", br(9.50), hoje.isoformat()],
    ["1005", "Concorrente 2", br(10.20), hoje.isoformat()], ["4001", "Concorrente 1", br(13.90), hoje.isoformat()],
    ["2001", "Concorrente 1", br(76.00), hoje.isoformat()],
])

cons = []
for i, c in enumerate(clientes):
    opt = "S" if i % 3 != 0 else "N"
    desc = "S" if i == 4 else "N"
    cons.append([c, opt, (hoje - timedelta(days=200 - i)).isoformat() if opt == "S" else "", "balcao", desc])
w("consentimentos.csv", ["cliente_id", "opt_in_recompra", "data_consentimento", "canal", "descadastrado"], cons)
w("duracao_tratamento.csv", ["sku", "dias_por_embalagem"],
  [["1001", 30], ["1002", 30], ["1003", 30], ["1004", 30], ["1005", 28], ["1006", 30], ["1007", 30], ["2001", 30], ["2002", 30]])
print(f"Dados de exemplo gerados em {out} (hoje={hoje})")
