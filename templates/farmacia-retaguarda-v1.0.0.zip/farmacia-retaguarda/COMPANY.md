---
name: Farmácia – Retaguarda com IA
description: Escritório de retaguarda para drogaria independente — compras e estoque, conformidade sanitária, financeiro, preços, relacionamento com opt-in e marketing dentro da RDC 96. Agentes preparam; humanos decidem.
slug: farmacia-retaguarda
schema: agentcompanies/v1
version: 1.0.0
license: Proprietária — veja LICENSE.md
authors:
  - name: Rafael Farias
tags:
  - farmacia
  - drogaria
  - varejo
  - brasil
goals:
  - Zero pendência regulatória sem tarefa aberta (licenças, SNGPC, escala com farmacêutico em 100% do horário)
  - Curva A sempre disponível, com estoque parado e perdas por vencimento em queda
  - Dono sabe o caixa real todo dia e o lucro real todo mês
  - Preço competitivo nos genéricos que o cliente compara, sem nenhum preço acima do PMC
  - Recompra de clientes de uso contínuo crescendo, só com consentimento (LGPD)
---

# Farmácia – Retaguarda com IA

Esta empresa dá a uma drogaria independente a retaguarda que hoje só as grandes redes têm. Os agentes leem as exportações do sistema da farmácia (ERP), planilhas e extratos colocados numa pasta combinada. Eles calculam, conferem, alertam e escrevem rascunhos. **Quem decide é sempre um humano.**

## Quem é quem

- **Board (dono da farmácia):** aprova pedidos de compra, preços, pagamentos, comunicações externas, publicações e metas.
- **Farmacêutico responsável técnico (RT):** valida tudo o que envolve medicamento, receita, paciente, controlados ou conteúdo técnico. Se o RT não tiver acesso ao Paperclip, o dono repassa a ele as tarefas marcadas `[RT]`.
- **Contador:** decide qualquer questão fiscal. Os agentes só preparam a pré-conferência.

## Organograma

```
Dono (board)
 └── gerente-geral
       ├── implantacao               (configura a farmácia na 1ª semana)
       ├── sentinela-regulatoria
       ├── comprador-estoque
       ├── controller-financeiro
       │     └── analista-precos
       └── relacionamento-clientes
             └── marketing-conteudo
```

## A regra que nenhum agente quebra

Dispensação, avaliação de receita, indicação de medicamento, orientação de dose ou interação, serviços clínicos, SNGPC e SNCR com a credencial do RT: **tudo isso é ato do farmacêutico humano.** Todo agente carrega a skill `limites-farmaceutico-humano`. Quando um pedido passa da linha, o agente abre tarefa para o humano e para.

Os agentes também **não enviam** pedido a fornecedor, mensagem a cliente, post ou e-mail. **Não pagam** nada e **não alteram** preço ou estoque no ERP. Produzem rascunhos para aprovação.

## Dados

Os agentes leem a pasta definida em `FARMACIA_DADOS`. O formato dos arquivos está na skill `contrato-de-dados`. Dados de exemplo fictícios para demonstração ficam em `assets/dados-exemplo/`. Nenhuma credencial (gov.br, e-CNPJ, banco, ERP, SNGPC) entra no sistema.

## Atualizações

As normas mudam (Anvisa, reajuste anual da CMED, Farmácia Popular, reforma tributária até 2033). As regras ficam versionadas nas skills, e cada versão deste pacote traz a data da última revisão regulatória em `CHANGELOG.md`.
