# Licença de uso — Farmácia – Retaguarda com IA

Copyright (c) 2026 Rafael Farias. Todos os direitos reservados.

1. Esta licença permite instalar e usar o pacote em **um estabelecimento** (um CNPJ) do cliente que o adquiriu.
2. É proibido revender, redistribuir, sublicenciar ou publicar o pacote, no todo ou em parte, sem autorização por escrito.
3. O pacote é uma ferramenta de apoio à gestão. **Não substitui** o farmacêutico responsável técnico, o contador nem a assessoria jurídica. Não constitui parecer sanitário, fiscal ou jurídico.
4. O cliente é responsável:
   - pelas decisões tomadas a partir dos relatórios;
   - pelos dados que fornece;
   - pela base legal de tratamento de dados pessoais (LGPD);
   - pelos contratos com os provedores de IA que utilizar.
5. O pacote é fornecido "no estado em que se encontra". As atualizações regulatórias são oferecidas por assinatura separada.

*Modelo de licença: revise com um advogado antes de comercializar.*
