# Changelog

## 1.0.0 — 2026-11-24
- Primeira versão: 8 agentes, 21 skills, 10 scripts, 23 rotinas e dados de exemplo.
- Revisão regulatória feita em 24/11/2026. Destaques:
  - **SNGPC:** obrigatório de novo (RDC 973/2025, IN 360/2025).
  - **SNCR:** em operação desde 30/09/2026, com transição de RCE/RET até 03/03/2027.
  - **Lei 15.357/2026:** liberou marketplaces e entrega; a Anvisa ainda está regulamentando.
  - **Farmácia Popular:** novas regras pela Portaria GM/MS 12.091/2026.
  - **CMED 2026:** reajuste a partir de 31/03 (Resolução CMED nº 4/2026).
  - **LC 214/2025:** transição para CBS/IBS.
- Itens a conferir na implantação estão marcados **[conferir]** nas skills.
