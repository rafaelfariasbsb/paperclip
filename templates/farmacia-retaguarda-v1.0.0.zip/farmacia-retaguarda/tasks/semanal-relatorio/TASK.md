---
name: "Relatório semanal para o dono"
assignee: gerente-geral
recurring: true
---

Monte o relatório semanal da skill `relatorios-para-o-dono`: KPIs, as 5 ações principais, os riscos e as aprovações paradas há mais de 48h.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
