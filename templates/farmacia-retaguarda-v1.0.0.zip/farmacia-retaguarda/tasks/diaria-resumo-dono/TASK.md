---
name: "Resumo diário para o dono"
assignee: gerente-geral
recurring: true
---

Consolide os resultados do dia dos outros agentes no formato da skill `relatorios-para-o-dono`, em no máximo 10 linhas. Destaque as aprovações pendentes.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
