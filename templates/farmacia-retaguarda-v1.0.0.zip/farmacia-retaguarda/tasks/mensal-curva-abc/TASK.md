---
name: "Curva ABC, estoque parado e compras x orçamento"
assignee: comprador-estoque
recurring: true
---

Rode `python3 scripts/curva_abc.py "$FARMACIA_DADOS/entrada" --dias 90 --parado 90` e compare as compras do mês com o orçamento (CMV do mês anterior × crescimento previsto).

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
