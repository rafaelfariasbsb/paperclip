---
name: "Simulação do reajuste CMED e antecipação de compras"
assignee: analista-precos
recurring: true
---

Simule o impacto do reajuste anual da CMED por nível de concorrência. Com o comprador, proponha a antecipação de compras dos itens de maior giro. Entregue ao dono para aprovação.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
