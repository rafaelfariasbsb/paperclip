---
name: "[RT] Checklist de inspeção (rodízio) e novidades regulatórias"
assignee: sentinela-regulatoria
recurring: true
---

Escolha de 5 a 8 itens do rodízio da skill `checklist-inspecao-sanitaria` e envie ao RT para confirmar. Inclua um resumo das novidades regulatórias da semana, só com fontes oficiais e links.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
