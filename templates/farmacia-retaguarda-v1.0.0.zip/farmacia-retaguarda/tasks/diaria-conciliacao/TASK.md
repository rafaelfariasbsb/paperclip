---
name: "Conciliação de cartão, Pix e caixa"
assignee: controller-financeiro
recurring: true
---

Rode `python3 scripts/conciliar.py "$FARMACIA_DADOS/entrada"` (skill `conciliacao-recebiveis`). Liste as divergências e as taxas acima do contratado. Nunca contatar a adquirente nem antecipar recebíveis.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
