---
name: "Rascunhos de posts com checklist RDC 96"
assignee: marketing-conteudo
recurring: true
---

Produza de 3 a 5 rascunhos de post ou status, cada um com o checklist da skill `checklist-rdc96` preenchido. Peças que citam medicamento ou serviço clínico vão para o RT. **Não publique.**

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
