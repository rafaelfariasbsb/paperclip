---
name: "Prazos de licenças e documentos"
assignee: sentinela-regulatoria
recurring: true
---

Rode `python3 scripts/prazos.py "$FARMACIA_DADOS/entrada"` (skill `calendario-regulatorio`). Abra tarefa para cada documento vencido ou que vence em até 60 dias.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
