---
name: "Calendário editorial do próximo mês"
assignee: marketing-conteudo
recurring: true
---

Monte o calendário do mês seguinte com a skill `calendario-sazonal-saude` e os serviços de `config-farmacia.md`. Entregue ao dono para aprovação.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
