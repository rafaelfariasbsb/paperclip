---
name: "Orçamento do ano e transição tributária"
assignee: controller-financeiro
recurring: true
---

Prepare o rascunho do orçamento do ano seguinte e a lista de pontos da reforma tributária para revisar com o contador. Exemplos: CBS a partir de 2027 e split payment.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
