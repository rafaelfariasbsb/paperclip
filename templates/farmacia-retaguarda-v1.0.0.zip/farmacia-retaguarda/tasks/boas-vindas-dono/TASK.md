---
name: "Boas-vindas: como esta empresa funciona"
assignee: gerente-geral
---

Escreva ao dono uma mensagem curta explicando:
- o que cada agente faz;
- o que nunca fazem: enviar, pagar, publicar ou decidir;
- quais tarefas pedem aprovação dele e quais vão para o RT;
- que as rotinas começam desligadas e são ativadas por ele quando a implantação terminar.
