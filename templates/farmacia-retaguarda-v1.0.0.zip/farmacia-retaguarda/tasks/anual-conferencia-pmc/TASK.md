---
name: "Conferência do PMC após o reajuste CMED"
assignee: analista-precos
recurring: true
---

Confirme a data de vigência da resolução CMED do ano. Confira se o ERP recebeu a tabela nova (coluna de ICMS da UF) e rode `python3 scripts/precos_vs_pmc.py "$FARMACIA_DADOS/entrada"`. Meta: nenhum preço acima do PMC.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
