---
name: "Auditoria preventiva do Farmácia Popular"
assignee: sentinela-regulatoria
recurring: true
---

Só se a farmácia for credenciada (veja `config-farmacia.md`). Siga a skill `farmacia-popular-auditoria-preventiva`, com dados agregados por SKU e sem CPF. Envie o relatório ao RT e ao dono.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
