---
name: "Pré-conferência monofásico/ST para o contador"
assignee: controller-financeiro
recurring: true
---

Siga a skill `segregacao-monofasico-st` e entregue um memorando ao contador, com as diferenças como perguntas. Não retifique nem transmita nada.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
