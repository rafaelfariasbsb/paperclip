---
name: "Escala do próximo mês: farmacêutico em 100% do horário"
assignee: sentinela-regulatoria
recurring: true
---

Rode `python3 scripts/cobertura_escala.py "$FARMACIA_DADOS/entrada" --dias 40`. Cada lacuna vira tarefa [DONO] e [RT].

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
