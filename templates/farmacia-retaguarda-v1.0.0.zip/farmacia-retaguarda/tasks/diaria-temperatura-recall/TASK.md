---
name: "Temperatura, umidade e recalls"
assignee: sentinela-regulatoria
recurring: true
---

Rode `python3 scripts/temperatura.py "$FARMACIA_DADOS/entrada" --desde <ontem>` (skill `checklist-inspecao-sanitaria`) e siga a skill `monitor-recall` para cruzar publicações oficiais com `lotes.csv`. Abra tarefa [RT] para cada desvio ou lote afetado.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
