---
name: "DRE gerencial e KPIs do mês"
assignee: controller-financeiro
recurring: true
---

Rode `python3 scripts/kpis_vendas.py "$FARMACIA_DADOS/entrada" --de <1º dia do mês anterior> --ate <último dia>` e monte o DRE da skill `dre-gerencial-farmacia`, com ciclo financeiro e capital de giro. Entregue ao dono para validação.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
