---
name: "Contagem rotativa e quase-vencidos"
assignee: comprador-estoque
recurring: true
---

Rode `python3 scripts/curva_abc.py "$FARMACIA_DADOS/entrada" --contagem 60` e `python3 scripts/vencidos.py "$FARMACIA_DADOS/entrada"`. Entregue a lista de contagem para a equipe e as ações por lote para o dono aprovar.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
