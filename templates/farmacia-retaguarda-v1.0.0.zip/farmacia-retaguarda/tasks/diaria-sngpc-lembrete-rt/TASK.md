---
name: "[RT] Lembrete SNGPC e controlados"
assignee: sentinela-regulatoria
recurring: true
---

Siga a skill `sngpc-lembretes-rt`: dias desde o último arquivo 'Aceito' (se o ERP exportar) e divergências de estoque de controlados. Crie a tarefa para o RT. Nunca transmitir nem pedir credenciais.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
