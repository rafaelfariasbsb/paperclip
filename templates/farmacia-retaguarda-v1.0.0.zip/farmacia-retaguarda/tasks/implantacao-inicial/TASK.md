---
name: "Implantação: configurar a farmácia"
assignee: implantacao
---

Siga o passo a passo do agente de implantação: entrevista com o dono, `config-farmacia.md`, validação dos dados (`validar_dados.py`), planilha-mestre `documentos.csv` e relatório de implantação ao gerente-geral.
