---
name: "Fechamento do mês e pauta com o dono"
assignee: gerente-geral
recurring: true
---

Consolide os KPIs do mês de todos os agentes, proponha metas e parâmetros para o mês seguinte (sem aplicar) e monte a pauta da reunião com o dono.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
