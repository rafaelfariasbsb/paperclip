---
name: "Sugestão de compra do dia (rascunho)"
assignee: comprador-estoque
recurring: true
---

Rode `python3 scripts/sugestao_compra.py "$FARMACIA_DADOS/entrada" --csv "$FARMACIA_DADOS/saida/pedido_<data>.csv"` (skill `ponto-de-pedido`), com cobertura e segurança de `config-farmacia.md`. Entregue um rascunho por distribuidora, com as rupturas no topo. **Aprovação do dono obrigatória.** Controlados: só sinalizar ao RT.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
