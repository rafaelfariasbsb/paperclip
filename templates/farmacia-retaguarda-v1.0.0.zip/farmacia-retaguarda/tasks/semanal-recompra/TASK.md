---
name: "[RT] Lista de recompra (só opt-in)"
assignee: relacionamento-clientes
recurring: true
---

Rode `python3 scripts/recompra.py "$FARMACIA_DADOS/entrada"` (skill `recompra-uso-continuo`). Envie a lista e a mensagem-modelo neutra para validação do RT. **Não envie mensagens.**

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
