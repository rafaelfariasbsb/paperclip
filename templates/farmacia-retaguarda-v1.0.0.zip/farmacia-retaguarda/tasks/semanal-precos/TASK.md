---
name: "Preços: PMC, margem e concorrência"
assignee: analista-precos
recurring: true
---

Rode `python3 scripts/precos_vs_pmc.py "$FARMACIA_DADOS/entrada"` (skill `reajuste-cmed`). Preço acima do PMC vira tarefa urgente. As sugestões de preço são rascunhos para o dono aprovar, válidas para todos os clientes.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
