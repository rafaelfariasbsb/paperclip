---
name: "Fluxo de caixa projetado 30 dias"
assignee: controller-financeiro
recurring: true
---

Rode `python3 scripts/conciliar.py "$FARMACIA_DADOS/entrada" --horizonte 30` e destaque o menor saldo previsto e a data em que ele acontece. Se ficar negativo, abra tarefa [DONO] com as opções (renegociar prazo, adiar compra), sem decidir por ele.

Regras: carregue a skill `limites-farmaceutico-humano`. Se faltar arquivo de dados, informe qual e não invente números. Salve relatórios em `$FARMACIA_DADOS/saida/`.
